# Tarot Battle Prototype v0.9.4 Mobile

Godot 4.x용 모바일 세로형 프로토타입.

## v0.9.4 변경점

- 사용자 제공 토트 타로 뒷면 이미지를 실제 카드 뒷면으로 적용했다.
  - 비공개 상태의 상대 손패에만 사용한다.
  - 덱의 맨 위 카드에도 사용한다.
  - 전장에 공개된 상대 카드에는 사용하지 않는다.
- 모든 카드 표시 영역을 2:3 비율로 통일했다.
  - 손패 썸네일
  - 전장 공격/방어 카드
  - 선공 판정 공개 카드
  - 덱
  - 카드 이동 애니메이션
  - 드래그 잔상
- 덱은 카드 뒷면이 맨 위에 보이는 카드뭉치 형태로 표시한다.
- 카드 이동 애니메이션에서 비공개 카드는 실제 뒷면 이미지를 사용한다.
- 실제 앞면 이미지 교체 구조를 미리 넣었다.
  - `assets/cards/<card_id>.png` 파일이 존재하면 해당 카드의 앞면으로 자동 사용한다.
  - 예: `assets/cards/SMALL_SWORDS_2.png`, `assets/cards/ACE_WANDS.png`, `assets/cards/COURT_CUPS_KNIGHT.png`, `assets/cards/ATU_00.png`
  - 앞면 이미지가 없는 동안에는 현재의 텍스트 임시 카드가 같은 2:3 슬롯에 표시된다.

## 실행

1. Godot 4.x에서 `project.godot`을 연다.
2. F6 또는 F5로 실행한다.
3. PC 테스트 창은 스마트폰 세로 비율로 열린다.

## 현재 조작

- 손패 카드 탭: 카드 설명 확인 및 선택
- 손패 카드 드래그: 공격/추가제출/방어
- 전장 카드 탭: 카드 설명 확인, 방어 중에는 대상 선택
- 덱 탭: 선공 판정 시작 또는 공격 없이 1장 드로우 후 턴 종료

## 카드 이미지 규격

- 기준 비율: 2:3
- 현재 뒷면 원본: 1024×1536
- 실제 앞면도 2:3이면 해상도가 달라도 자동 축소되어 같은 슬롯에 들어간다.


## v0.9.4.1 web font fix
- Web export downloads NanumGothic at startup so Korean UI text renders correctly on mobile browsers.
