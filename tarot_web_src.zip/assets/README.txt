토트 타로 도트 카드 79장

구성: 아투 22장, 네 슈트의 숫자/에이스/코트 56장, 뒷면 1장.
크기: 각 PNG 480 x 750 px. 160 x 250 격자로 줄여 3배 최근접 확대했다.
파일명은 tarot_battle_proto_v0.9.1의 CardDatabase ID와 일치한다.
게임에서 축소/확대할 때 텍스처 필터를 Nearest로 지정하면 도트 가장자리가 유지된다.
숫자 카드의 하단에는 토트 타로 고유 명칭(Dominion 등)을 표기했다.

앞면 원본 도상: Aleister Crowley / Lady Frieda Harris, Book of Thoth 아카이브(각 출처는 manifest.json).
뒷면: 실물 카드 뒷면 사진의 구도를 정면 보정한 도트 변환. 출처: https://tarotlandet.se/products/thoth-tarot-engelsk
원본 카드의 저작권 또는 게임 배포 허락은 이 파일에 포함되지 않는다.
