extends PanelContainer

signal payload_dropped(data)

var accept_kinds: Array = ["HAND_CARD"]
var drop_enabled: bool = true

func _can_drop_data(_at_position: Vector2, data) -> bool:
    if not drop_enabled or not (data is Dictionary):
        return false
    return str(data.get("kind", "")) in accept_kinds

func _drop_data(_at_position: Vector2, data) -> void:
    if _can_drop_data(_at_position, data):
        payload_dropped.emit(data)
