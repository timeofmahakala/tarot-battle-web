extends Button

signal card_tapped

var drag_enabled: bool = false
var drag_payload: Dictionary = {}
var fixed_card_size: Vector2 = Vector2.ZERO
var accept_drop_kinds: Array = []
var drop_callback: Callable = Callable()

const DRAG_PREVIEW_SIZE := Vector2(72, 108)


const TAP_SLOP := 12.0
var _pointer_down: bool = false
var _pointer_start: Vector2 = Vector2.ZERO
var _pointer_moved: bool = false
var _last_tap_msec: int = -1000

func _emit_tap_once() -> void:
    var now: int = Time.get_ticks_msec()
    if now - _last_tap_msec < 180:
        return
    _last_tap_msec = now
    card_tapped.emit()

func _gui_input(event: InputEvent) -> void:
    if event is InputEventScreenTouch:
        if event.pressed:
            _pointer_down = true
            _pointer_start = event.position
            _pointer_moved = false
        else:
            if _pointer_down and not _pointer_moved and event.position.distance_to(_pointer_start) <= TAP_SLOP:
                _emit_tap_once()
            _pointer_down = false
    elif event is InputEventScreenDrag:
        if _pointer_down and event.position.distance_to(_pointer_start) > TAP_SLOP:
            _pointer_moved = true
    elif event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_LEFT:
        if event.pressed:
            _pointer_down = true
            _pointer_start = event.position
            _pointer_moved = false
        else:
            if _pointer_down and not _pointer_moved and event.position.distance_to(_pointer_start) <= TAP_SLOP:
                _emit_tap_once()
            _pointer_down = false
    elif event is InputEventMouseMotion:
        if _pointer_down and event.position.distance_to(_pointer_start) > TAP_SLOP:
            _pointer_moved = true

func _can_drop_data(_at_position: Vector2, data) -> bool:
    if not (data is Dictionary) or accept_drop_kinds.is_empty():
        return false
    return str(data.get("kind", "")) in accept_drop_kinds


func _drop_data(_at_position: Vector2, data) -> void:
    if _can_drop_data(_at_position, data) and drop_callback.is_valid():
        drop_callback.call(data)


func _get_minimum_size() -> Vector2:
    if fixed_card_size != Vector2.ZERO:
        return fixed_card_size
    return Vector2.ZERO

func _get_drag_data(_at_position: Vector2):
    if not drag_enabled or disabled or drag_payload.is_empty():
        return null

    # 손가락/커서 바로 위에 실제 카드 비율(2:3)의 반투명 잔상이 따라온다.
    var holder := Control.new()
    holder.custom_minimum_size = Vector2(1, 1)
    holder.mouse_filter = Control.MOUSE_FILTER_IGNORE

    var shadow := PanelContainer.new()
    shadow.position = Vector2(-33, -51)
    shadow.size = DRAG_PREVIEW_SIZE
    shadow.mouse_filter = Control.MOUSE_FILTER_IGNORE
    var shadow_style := StyleBoxFlat.new()
    shadow_style.bg_color = Color(0.0, 0.0, 0.0, 0.28)
    shadow_style.corner_radius_top_left = 5
    shadow_style.corner_radius_top_right = 5
    shadow_style.corner_radius_bottom_left = 5
    shadow_style.corner_radius_bottom_right = 5
    shadow.add_theme_stylebox_override("panel", shadow_style)
    holder.add_child(shadow)

    var preview := Button.new()
    preview.position = Vector2(-36, -54)
    preview.size = DRAG_PREVIEW_SIZE
    preview.custom_minimum_size = DRAG_PREVIEW_SIZE
    preview.mouse_filter = Control.MOUSE_FILTER_IGNORE
    preview.focus_mode = Control.FOCUS_NONE
    preview.modulate = Color(1.0, 1.0, 1.0, 0.90)
    preview.add_theme_font_size_override("font_size", 9)

    if icon != null:
        preview.icon = icon
        preview.expand_icon = true
        preview.text = ""
    else:
        preview.text = text

    var source_style := get_theme_stylebox("normal")
    if source_style != null:
        preview.add_theme_stylebox_override("normal", source_style.duplicate())
    var source_font_color := get_theme_color("font_color")
    preview.add_theme_color_override("font_color", source_font_color)
    holder.add_child(preview)

    set_drag_preview(holder)
    return drag_payload.duplicate(true)
