extends Button

var drag_enabled: bool = false
var drag_payload: Dictionary = {}

const DRAG_PREVIEW_SIZE := Vector2(72, 108)

func _get_drag_data(_at_position: Vector2):
    if not drag_enabled or disabled or drag_payload.is_empty():
        return null

    # 손가락/커서 바로 위에 실제 카드 비율(2:3)의 반투명 잔상이 따라온다.
    var holder := Control.new()
    holder.custom_minimum_size = Vector2(1, 1)
    holder.mouse_filter = Control.MOUSE_FILTER_IGNORE

    var shadow := PanelContainer.new()
    shadow.position = Vector2(-33, -51)
    shadow.size = DRAG_PREVIEW_SIZE
    shadow.mouse_filter = Control.MOUSE_FILTER_IGNORE
    var shadow_style := StyleBoxFlat.new()
    shadow_style.bg_color = Color(0.0, 0.0, 0.0, 0.28)
    shadow_style.corner_radius_top_left = 5
    shadow_style.corner_radius_top_right = 5
    shadow_style.corner_radius_bottom_left = 5
    shadow_style.corner_radius_bottom_right = 5
    shadow.add_theme_stylebox_override("panel", shadow_style)
    holder.add_child(shadow)

    var preview := Button.new()
    preview.position = Vector2(-36, -54)
    preview.size = DRAG_PREVIEW_SIZE
    preview.custom_minimum_size = DRAG_PREVIEW_SIZE
    preview.mouse_filter = Control.MOUSE_FILTER_IGNORE
    preview.focus_mode = Control.FOCUS_NONE
    preview.modulate = Color(1.0, 1.0, 1.0, 0.90)
    preview.add_theme_font_size_override("font_size", 9)

    if icon != null:
        preview.icon = icon
        preview.expand_icon = true
        preview.text = ""
    else:
        preview.text = text

    var source_style := get_theme_stylebox("normal")
    if source_style != null:
        preview.add_theme_stylebox_override("normal", source_style.duplicate())
    var source_font_color := get_theme_color("font_color")
    preview.add_theme_color_override("font_color", source_font_color)
    holder.add_child(preview)

    set_drag_preview(holder)
    return drag_payload.duplicate(true)
