extends Control

const CardDragButton = preload("res://scripts/CardDragButton.gd")
const BattleDropZone = preload("res://scripts/BattleDropZone.gd")
const CARD_BACK_TEXTURE: Texture2D = preload("res://assets/cards/BACK.png")
const BATTLEFIELD_BG_TEXTURE: Texture2D = preload("res://assets/ui/battlefield_bg.png")
const OBELISK_BLACK_TEXTURE: Texture2D = preload("res://assets/ui/obelisk_black.png")
const OBELISK_WHITE_TEXTURE: Texture2D = preload("res://assets/ui/obelisk_white.png")
# 카드 이미지는 모두 2:3 비율을 기준으로 한다.
# 실제 앞면 이미지를 assets/cards/<card_id>.png 로 넣으면 자동으로 사용된다.
const CARD_HAND_SIZE := Vector2(52, 81)
const CARD_FIELD_SIZE := Vector2(67, 105)
const CARD_INIT_SIZE := Vector2(92, 144)
const CARD_DECK_SIZE := Vector2(92, 144)
const CARD_FLYER_SIZE := Vector2(72, 108)

const SUIT_KO := {
    "Wands": "완드",
    "Cups": "컵",
    "Swords": "소드",
    "Disks": "디스크"
}
const SUIT_RANK := {
    "Wands": 4,
    "Cups": 3,
    "Swords": 2,
    "Disks": 1
}
const COURT_KO := {
    "Princess": "프린세스",
    "Prince": "프린스",
    "Queen": "퀸",
    "Knight": "나이트"
}
const COURT_RANK := {
    "Princess": 1,
    "Prince": 2,
    "Queen": 3,
    "Knight": 4
}
const TYPE_RANK := {
    "SMALL": 1,
    "ACE": 2,
    "COURT": 3,
    "ATU": 4
}
const ATTACK_SMALL_SUITS := ["Swords", "Wands"]
const ATTACK_ATU_EFFECTS := [
    "MAGUS", "EMPRESS", "EMPEROR", "HIEROPHANT",
    "ADJUSTMENT", "HERMIT", "FORTUNE", "HANGED_MAN",
    "DEATH", "DEVIL", "TOWER", "STAR", "MOON", "SUN",
    "AEON", "UNIVERSE"
]
const DEFENSE_ATU_EFFECTS := [
    "FOOL", "PRIESTESS", "EMPRESS", "EMPEROR",
    "LOVERS", "CHARIOT", "LUST"
]
const NULLIFY_ATU_EFFECTS := [
    "FOOL", "PRIESTESS", "EMPRESS", "EMPEROR", "CHARIOT", "LUST"
]

var deck: Array = []
var discard: Array = []
var excluded: Array = []
var hands: Array = [[], []]

var current_player: int = 0
var phase: String = "SETUP"
var initiative_winner: int = -1
var initiative_cards: Array = [null, null]
var game_over: bool = false

# 공격 구성 초안
var selected_attack_index: int = -1
var attack_base_id: String = ""
var attack_draft_ids: Array = []
# {family: "ANY"|"PHYSICAL"|"MAGICAL", mandatory: bool, source_id: String}
var attack_tokens: Array = []
# source card id -> "ACE" | "KNIGHT"
var condition_family: Dictionary = {}
# source card id -> Array[card_id]
var condition_ids: Dictionary = {}
var attack_art_id: String = ""
var attack_art_target_id: String = ""
var attack_append_mode: bool = false
var append_start_index: int = 0

# 확정된 공격 패키지
# entry = {card, defense, direct_draw, cannot_be_nullified, lovers_protected, nullified, resolved_draw}
var attack_package: Array = []
var used_attack_misc: Array = []
var art_target_index: int = -1

# 공격자 자신에게 적용되는 후처리 효과 큐
var post_effect_queue: Array = []

# 궁정 완성 순차 처리
var court_scan_index: int = 0
var court_completion_options: Array = []

# 일반 방어 초안. key=공격 슬롯 / value=방어 카드 id
var selected_defense_target: int = 0
var defense_draft: Dictionary = {}

# 방어 아투 초안.
# {card_id, effect_id, target_hint, targets}
var defense_atu_choices: Array = []
# 제출된 방어 아투.
# {card, effect_id, targets, cancelled}
var defense_atu_used: Array = []

# 공격자의 어저스트먼트 선택지 2 등 반응으로 사용된 카드
var reaction_cards: Array = []

# 포춘 / 허미트 / 데빌 상태
var extra_turns: Array = [0, 0]
var hermit_skip_pending: Array = [false, false]
var hermit_chain_pending: Array = [false, false]
var hermit_chain_remaining: Array = [0, 0]
var defense_blocked: Array = [false, false]
var devil_locked_ids: Array = [[], []]

# 특수 선택 단계
var star_self_id: String = ""

# 에온 리사이클 / 비동기 드로우
var recycle_count: int = 0
var shared_pentacles: int = 0
var player_pentacles: Array = [999, 999]
var pentacle_contributions: Array = [0, 0]
var last_pentacle_award: int = 0
var pentacle_finalized: bool = false
var aeon_reinserted: bool = false
var recycle_votes: Array = [null, null]
var recycle_voter: int = 0
var pending_draw_player: int = -1
var pending_draw_remaining: int = 0
var pending_draw_callback: Callable = Callable()

var status_label: Label
var deck_label: Label
var pentacle_label: Label
var phase_label: Label
var attack_label: Label
var battle_title_label: Label
var card_description_label: Label
var card_modal_overlay: Control
var card_modal_panel: PanelContainer
var card_modal_image: TextureRect
var card_modal_name_label: Label
var card_modal_meta_label: Label
var card_modal_rules_label: Label
var hand_labels: Array = []
var player_pentacle_labels: Array = []
var hand_boxes: Array = []
var action_box: HBoxContainer
var secondary_action_box: HBoxContainer
var action_hint_label: Label
var log_box: RichTextLabel
var hand_panels: Array = []
var battlefield_box: HBoxContainer
var battlefield_drop_zone
var defense_package_panel
var defense_atu_box: HBoxContainer
var deck_pile_button: Button
var discard_pile_button: Button
var aeon_status_label: Label
var pentacle_pile_button: Button
var zone_dialog: AcceptDialog
var animation_layer: Control
var aeon_message_overlay: Control
var aeon_message_label: Label
var public_hand_flags: Array = [false, false]
var sun_reveal_owner: int = -1
var sun_reveal_armed: bool = false
var reveal_confirm_callback: Callable = Callable()
var draw_animation_sequence: int = 0
var center_deck_action_button: Button
var deck_draw_origin_override: Vector2 = Vector2(-1, -1)
var deck_draw_origin_uses: int = 0

# P2 규칙 검증용 봇. P1은 사용자 조작, P2는 자동 진행한다.
var bot_enabled: bool = true
var bot_player: int = 1
var bot_action_pending: bool = false


func _ready() -> void:
    _build_ui()
    _new_game()


func _build_ui() -> void:
    var background := ColorRect.new()
    background.color = Color(0.035, 0.041, 0.055, 1.0)
    background.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    background.mouse_filter = Control.MOUSE_FILTER_IGNORE
    add_child(background)

    var margin := MarginContainer.new()
    margin.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    margin.add_theme_constant_override("margin_left", 8)
    margin.add_theme_constant_override("margin_right", 8)
    margin.add_theme_constant_override("margin_top", 8)
    margin.add_theme_constant_override("margin_bottom", 10)
    add_child(margin)

    # 스마트폰 세로형: 화면 전체가 하나의 세로 테이블이며 필요한 부분만 세로 스크롤한다.
    var page_scroll := ScrollContainer.new()
    page_scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
    page_scroll.vertical_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
    page_scroll.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    page_scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
    margin.add_child(page_scroll)

    var root := VBoxContainer.new()
    root.add_theme_constant_override("separation", 4)
    root.custom_minimum_size.x = 690
    root.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    page_scroll.add_child(root)

    var title_row := HBoxContainer.new()
    title_row.custom_minimum_size.y = 32
    title_row.add_theme_constant_override("separation", 8)
    root.add_child(title_row)
    var title := Label.new()
    title.text = "TAROT BATTLE  v0.9.11"
    title.add_theme_font_size_override("font_size", 21)
    title.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    title_row.add_child(title)
    phase_label = Label.new()
    phase_label.add_theme_font_size_override("font_size", 13)
    phase_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
    title_row.add_child(phase_label)

    # 상태/힌트 문자열은 내부 로직에서 계속 갱신하지만 화면에는 별도 정보 패널을 두지 않는다.
    status_label = Label.new()
    status_label.visible = false
    action_hint_label = Label.new()
    action_hint_label.visible = false

    hand_labels = [null, null]
    player_pentacle_labels = [null, null]
    hand_boxes = [null, null]
    hand_panels = [null, null]

    # 모바일 세로형 테이블: 상대 → 고정 전장(덱/묘지/공동 펜타클 포함) → 나.
    _create_player_hand_panel(root, 1, "상대")

    var battle_panel = BattleDropZone.new()
    battle_panel.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    battle_panel.custom_minimum_size.y = 500
    battle_panel.drop_enabled = true
    battle_panel.payload_dropped_at.connect(_on_battlefield_drop_at)
    root.add_child(battle_panel)
    battlefield_drop_zone = battle_panel

    var battle_v := VBoxContainer.new()
    battle_v.add_theme_constant_override("separation", 5)
    battle_v.size_flags_vertical = Control.SIZE_EXPAND_FILL
    battle_panel.add_child(battle_v)

    battle_title_label = Label.new()
    battle_title_label.text = "제1 에온"
    battle_title_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    battle_title_label.add_theme_font_size_override("font_size", 17)
    battle_v.add_child(battle_title_label)

    attack_label = Label.new()
    attack_label.text = "공격 패키지가 이곳에 표시된다."
    attack_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    attack_label.custom_minimum_size.y = 32
    attack_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    attack_label.add_theme_font_size_override("font_size", 12)
    attack_label.add_theme_color_override("font_color", Color(0.76, 0.81, 0.90, 1.0))
    battle_v.add_child(attack_label)

    var board_row := HBoxContainer.new()
    board_row.custom_minimum_size.y = 404
    board_row.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    board_row.size_flags_vertical = Control.SIZE_EXPAND_FILL
    board_row.add_theme_constant_override("separation", 2)
    battle_v.add_child(board_row)

    # 왼쪽: 검은 기둥 프레임 위에 덱을 올린다.
    var left_zone := Control.new()
    left_zone.custom_minimum_size = Vector2(112, 404)
    left_zone.size_flags_vertical = Control.SIZE_EXPAND_FILL
    board_row.add_child(left_zone)
    var left_obelisk := TextureRect.new()
    left_obelisk.texture = OBELISK_BLACK_TEXTURE
    left_obelisk.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    left_obelisk.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
    left_obelisk.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
    left_obelisk.texture_filter = CanvasItem.TEXTURE_FILTER_LINEAR
    left_obelisk.mouse_filter = Control.MOUSE_FILTER_IGNORE
    left_zone.add_child(left_obelisk)
    var left_overlay := MarginContainer.new()
    left_overlay.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    left_overlay.add_theme_constant_override("margin_left", 8)
    left_overlay.add_theme_constant_override("margin_right", 8)
    left_overlay.add_theme_constant_override("margin_top", 18)
    left_overlay.add_theme_constant_override("margin_bottom", 22)
    left_zone.add_child(left_overlay)
    var left_v := VBoxContainer.new()
    left_v.alignment = BoxContainer.ALIGNMENT_CENTER
    left_v.add_theme_constant_override("separation", 6)
    left_overlay.add_child(left_v)
    var left_spacer_top := Control.new()
    left_spacer_top.custom_minimum_size = Vector2(0, 64)
    left_v.add_child(left_spacer_top)
    deck_label = Label.new()
    deck_label.text = "덱 78장"
    deck_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    deck_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    deck_label.add_theme_font_size_override("font_size", 12)
    deck_label.add_theme_color_override("font_color", Color(0.96, 0.96, 0.96, 1.0))
    left_v.add_child(deck_label)
    deck_pile_button = _create_zone_button("덱", "DECK")
    deck_pile_button.custom_minimum_size = CARD_DECK_SIZE
    left_v.add_child(deck_pile_button)
    var left_spacer_bottom := Control.new()
    left_spacer_bottom.size_flags_vertical = Control.SIZE_EXPAND_FILL
    left_v.add_child(left_spacer_bottom)

    # 가운데: 세로 전장용 배경을 깔고 그 위에 실제 전투 필드를 렌더링한다.
    var battle_scroll := ScrollContainer.new()
    battle_scroll.mouse_filter = Control.MOUSE_FILTER_IGNORE
    battle_scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_AUTO
    battle_scroll.vertical_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
    battle_scroll.custom_minimum_size = Vector2(398, 404)
    battle_scroll.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    battle_scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
    board_row.add_child(battle_scroll)
    var battlefield_frame := PanelContainer.new()
    battlefield_frame.custom_minimum_size = Vector2(398, 400)
    battlefield_frame.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    battlefield_frame.size_flags_vertical = Control.SIZE_EXPAND_FILL
    battlefield_frame.add_theme_stylebox_override("panel", _make_box_style(Color(0.02, 0.017, 0.012, 0.60), Color(0.52, 0.40, 0.25, 0.88), 1, 9))
    battle_scroll.add_child(battlefield_frame)
    var battlefield_bg := TextureRect.new()
    battlefield_bg.texture = BATTLEFIELD_BG_TEXTURE
    battlefield_bg.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    battlefield_bg.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
    battlefield_bg.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_COVERED
    battlefield_bg.texture_filter = CanvasItem.TEXTURE_FILTER_LINEAR
    battlefield_bg.mouse_filter = Control.MOUSE_FILTER_IGNORE
    battlefield_frame.add_child(battlefield_bg)
    var battlefield_shade := ColorRect.new()
    battlefield_shade.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    battlefield_shade.color = Color(0.08, 0.05, 0.03, 0.24)
    battlefield_shade.mouse_filter = Control.MOUSE_FILTER_IGNORE
    battlefield_frame.add_child(battlefield_shade)
    battlefield_box = HBoxContainer.new()
    battlefield_box.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    battlefield_box.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    battlefield_box.size_flags_vertical = Control.SIZE_EXPAND_FILL
    battlefield_box.custom_minimum_size = Vector2(398, 400)
    battlefield_box.alignment = BoxContainer.ALIGNMENT_CENTER
    battlefield_box.add_theme_constant_override("separation", 8)
    battlefield_box.mouse_filter = Control.MOUSE_FILTER_IGNORE
    battlefield_frame.add_child(battlefield_box)

    # 오른쪽: 흰 기둥 프레임 위에 묘지와 공동 펜타클을 올린다.
    var right_zone := Control.new()
    right_zone.custom_minimum_size = Vector2(112, 404)
    right_zone.size_flags_vertical = Control.SIZE_EXPAND_FILL
    board_row.add_child(right_zone)
    var right_obelisk := TextureRect.new()
    right_obelisk.texture = OBELISK_WHITE_TEXTURE
    right_obelisk.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    right_obelisk.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
    right_obelisk.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
    right_obelisk.texture_filter = CanvasItem.TEXTURE_FILTER_LINEAR
    right_obelisk.mouse_filter = Control.MOUSE_FILTER_IGNORE
    right_zone.add_child(right_obelisk)
    var right_overlay := MarginContainer.new()
    right_overlay.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    right_overlay.add_theme_constant_override("margin_left", 8)
    right_overlay.add_theme_constant_override("margin_right", 8)
    right_overlay.add_theme_constant_override("margin_top", 24)
    right_overlay.add_theme_constant_override("margin_bottom", 18)
    right_zone.add_child(right_overlay)
    var right_v := VBoxContainer.new()
    right_v.alignment = BoxContainer.ALIGNMENT_CENTER
    right_v.add_theme_constant_override("separation", 8)
    right_overlay.add_child(right_v)
    var right_spacer_top := Control.new()
    right_spacer_top.custom_minimum_size = Vector2(0, 40)
    right_v.add_child(right_spacer_top)
    discard_pile_button = _create_zone_button("묘지", "DISCARD")
    discard_pile_button.custom_minimum_size = Vector2(96, 116)
    right_v.add_child(discard_pile_button)
    pentacle_pile_button = Button.new()
    pentacle_pile_button.text = "0펜타클"
    pentacle_pile_button.disabled = false
    pentacle_pile_button.custom_minimum_size = Vector2(96, 74)
    pentacle_pile_button.add_theme_font_size_override("font_size", 13)
    pentacle_pile_button.add_theme_color_override("font_color", Color(1.0, 0.87, 0.38, 1.0))
    pentacle_pile_button.add_theme_stylebox_override("normal", _make_box_style(Color(0.18, 0.15, 0.08, 0.92), Color(0.88, 0.66, 0.16, 1.0), 2, 9))
    pentacle_pile_button.add_theme_stylebox_override("hover", _make_box_style(Color(0.25, 0.19, 0.08, 0.96), Color(1.0, 0.78, 0.22, 1.0), 2, 9))
    pentacle_pile_button.add_theme_stylebox_override("pressed", _make_box_style(Color(0.14, 0.11, 0.04, 0.96), Color(0.88, 0.66, 0.16, 1.0), 2, 9))
    pentacle_pile_button.pressed.connect(_show_pentacle_dialog)
    right_v.add_child(pentacle_pile_button)
    var right_spacer_bottom := Control.new()
    right_spacer_bottom.size_flags_vertical = Control.SIZE_EXPAND_FILL
    right_v.add_child(right_spacer_bottom)
    aeon_status_label = Label.new()
    aeon_status_label.visible = false
    aeon_status_label.custom_minimum_size = Vector2.ZERO
    right_v.add_child(aeon_status_label)

    # 방어 아투도 별도 칸을 만들지 않고 실제 전장 안에 직접 표시한다.
    defense_package_panel = null
    defense_atu_box = HBoxContainer.new()

    var primary_panel := PanelContainer.new()
    primary_panel.custom_minimum_size.y = 72
    primary_panel.clip_contents = true
    primary_panel.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    root.add_child(primary_panel)
    var primary_v := VBoxContainer.new()
    primary_v.add_theme_constant_override("separation", 4)
    primary_panel.add_child(primary_v)
    var primary_title := Label.new()
    primary_title.text = "현재 선택지"
    primary_title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    primary_title.add_theme_font_size_override("font_size", 14)
    primary_v.add_child(primary_title)
    var action_scroll := ScrollContainer.new()
    action_scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_AUTO
    action_scroll.vertical_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
    action_scroll.custom_minimum_size.y = 42
    action_scroll.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    primary_v.add_child(action_scroll)
    var action_center := CenterContainer.new()
    action_center.custom_minimum_size.x = 680
    action_center.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    action_scroll.add_child(action_center)
    action_box = HBoxContainer.new()
    action_box.alignment = BoxContainer.ALIGNMENT_CENTER
    action_box.add_theme_constant_override("separation", 7)
    action_center.add_child(action_box)

    # 카드 설명은 고정 영역 대신 카드 클릭 시 상세 팝업으로 표시한다.
    card_description_label = null

    _create_player_hand_panel(root, 0, "나")
    _build_card_detail_modal()
    _build_aeon_message_overlay()

    # 무공격 드로우는 덱 더미 자체가 행동 버튼 역할을 한다.
    secondary_action_box = HBoxContainer.new()

    # 진행 기록은 모바일 화면에서 숨긴다. 내부 로그는 디버그용으로만 유지한다.
    log_box = RichTextLabel.new()
    log_box.visible = false

    zone_dialog = AcceptDialog.new()
    zone_dialog.title = "카드 영역"
    zone_dialog.min_size = Vector2i(640, 900)
    add_child(zone_dialog)

    animation_layer = Control.new()
    animation_layer.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    animation_layer.mouse_filter = Control.MOUSE_FILTER_IGNORE
    add_child(animation_layer)

func _create_player_hand_panel(parent: VBoxContainer, player: int, table_position: String) -> void:
    var panel := BattleDropZone.new()
    panel.accept_kinds = ["BATTLE_CARD"]
    panel.drop_enabled = true
    panel.payload_dropped.connect(_on_hand_return_drop.bind(player))
    panel.custom_minimum_size.y = 224 if player == 0 else 88
    panel.clip_contents = true
    parent.add_child(panel)
    hand_panels[player] = panel
    var pv := VBoxContainer.new()
    pv.add_theme_constant_override("separation", 4)
    panel.add_child(pv)
    var header := HBoxContainer.new()
    header.add_theme_constant_override("separation", 8)
    pv.add_child(header)
    var label := Label.new()
    label.add_theme_font_size_override("font_size", 16)
    label.text = "%s — P%d" % [table_position, player + 1]
    label.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    header.add_child(label)
    hand_labels[player] = label
    var coin_label := Label.new()
    coin_label.text = "◆ 999"
    coin_label.add_theme_font_size_override("font_size", 15)
    coin_label.add_theme_color_override("font_color", Color(1.0, 0.84, 0.34, 1.0))
    coin_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
    header.add_child(coin_label)
    player_pentacle_labels[player] = coin_label
    var layers := VBoxContainer.new()
    layers.add_theme_constant_override("separation", 4)
    layers.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    pv.add_child(layers)
    hand_boxes[player] = layers

func _create_zone_button(label: String, zone_id: String) -> Button:
    var b := Button.new()
    b.text = "%s\n[더미]" % label
    b.custom_minimum_size = Vector2(150, 76)
    b.add_theme_font_size_override("font_size", 13)
    b.focus_mode = Control.FOCUS_NONE
    if zone_id == "DECK":
        b.pressed.connect(_on_deck_pile_pressed)
    else:
        b.pressed.connect(_show_zone_dialog.bind(zone_id))
    b.add_theme_stylebox_override("normal", _make_box_style(Color(0.10, 0.12, 0.16, 1.0), Color(0.40, 0.45, 0.54, 1.0), 2, 8))
    b.add_theme_stylebox_override("hover", _make_box_style(Color(0.14, 0.17, 0.22, 1.0), Color(0.62, 0.70, 0.82, 1.0), 2, 8))
    return b

func _show_pentacle_dialog() -> void:
    if zone_dialog == null:
        return
    zone_dialog.title = "공동 펜타클"
    zone_dialog.dialog_text = "현재 %d 펜타클\n\nP1 기여: %d\nP2 기여: %d" % [shared_pentacles, int(pentacle_contributions[0]), int(pentacle_contributions[1])]
    zone_dialog.popup_centered(Vector2i(500, 360))


func _show_zone_dialog(zone_id: String) -> void:
    if zone_dialog == null:
        return
    match zone_id:
        "DECK":
            zone_dialog.title = "덱"
            zone_dialog.dialog_text = "덱: %d장\n\n덱의 카드 순서와 내용은 비공개이다." % deck.size()
        "DISCARD":
            zone_dialog.title = "묘지 — %d장" % discard.size()
            zone_dialog.dialog_text = _zone_card_list_text(discard, "묘지가 비어 있다.")
    zone_dialog.popup_centered(Vector2i(560, 500))


func _zone_card_list_text(cards: Array, empty_text: String) -> String:
    if cards.is_empty():
        return empty_text
    var lines: Array = []
    for i in range(cards.size()):
        lines.append("%02d. %s" % [i + 1, _card_name(cards[i])])
    return _join_strings(lines, "\n")

func _new_game() -> void:
    _hide_card_detail_modal()
    deck.clear()
    discard.clear()
    excluded.clear()
    hands = [[], []]
    attack_package.clear()
    used_attack_misc.clear()
    post_effect_queue.clear()
    defense_draft.clear()
    defense_atu_choices.clear()
    defense_atu_used.clear()
    reaction_cards.clear()
    court_completion_options.clear()
    attack_draft_ids.clear()
    attack_tokens.clear()
    condition_family.clear()
    condition_ids.clear()

    current_player = 0
    phase = "SETUP"
    initiative_winner = -1
    initiative_cards = [null, null]
    selected_attack_index = -1
    attack_base_id = ""
    attack_art_id = ""
    attack_art_target_id = ""
    attack_append_mode = false
    append_start_index = 0
    art_target_index = -1
    selected_defense_target = 0
    court_scan_index = 0
    extra_turns = [0, 0]
    hermit_skip_pending = [false, false]
    hermit_chain_pending = [false, false]
    hermit_chain_remaining = [0, 0]
    defense_blocked = [false, false]
    devil_locked_ids = [[], []]
    star_self_id = ""
    recycle_count = 0
    shared_pentacles = 0
    player_pentacles = [999, 999]
    pentacle_contributions = [0, 0]
    last_pentacle_award = 0
    pentacle_finalized = false
    aeon_reinserted = false
    recycle_votes = [null, null]
    recycle_voter = 0
    pending_draw_player = -1
    pending_draw_remaining = 0
    pending_draw_callback = Callable()
    public_hand_flags = [false, false]
    sun_reveal_owner = -1
    sun_reveal_armed = false
    reveal_confirm_callback = Callable()
    draw_animation_sequence = 0
    deck_draw_origin_override = Vector2(-1, -1)
    deck_draw_origin_uses = 0
    bot_action_pending = false
    game_over = false
    log_box.text = ""

    deck = CardDatabase.make_v04_deck()
    deck.shuffle()

    # 새 게임은 양쪽 손패 0장에서 시작한다. 덱 버튼을 눌러 선공 판정용 1장씩을 실제로 드로우한다.
    phase = "INITIATIVE_READY"
    _log("제1 에온 개시.")
    _log("선공 판정 준비: 덱에서 각 플레이어가 1장씩 공개 드로우한다.")
    _refresh_ui()

func _resume_recycle_after_transition() -> void:
    _rebuild_deck_from_discard()
    if deck.is_empty():
        _end_game(1 - pending_draw_player, "리사이클 후에도 드로우 가능한 카드가 없다.")
        return
    _log("제%d 에온 개시." % (recycle_count + 1))
    phase = "DRAW_RESOLUTION"
    _continue_pending_draw()


func _on_deck_pile_pressed() -> void:
    if game_over:
        return
    if phase == "INITIATIVE_READY":
        _begin_initiative_draw()
        return
    if phase == "ACTION" and (not bot_enabled or current_player != bot_player):
        _draw_and_end_turn()
        return


func _begin_initiative_draw() -> void:
    if phase != "INITIATIVE_READY" or game_over:
        return
    phase = "INITIATIVE_DRAW"
    status_label.text = "선공 판정: P1과 P2가 덱에서 1장씩 드로우한다."
    _refresh_ui()

    initiative_cards[0] = _draw_raw()
    if initiative_cards[0] == null:
        return
    hands[0].append(initiative_cards[0])
    _animate_draw_to_hand(0, initiative_cards[0], 0)
    _log("선공 판정: P1이 1장을 공개 드로우했다.")
    _refresh_ui()
    await get_tree().create_timer(0.42).timeout

    initiative_cards[1] = _draw_raw()
    if initiative_cards[1] == null:
        return
    hands[1].append(initiative_cards[1])
    _animate_draw_to_hand(1, initiative_cards[1], 1)
    _log("선공 판정: P2가 1장을 공개 드로우했다.")
    _refresh_ui()
    await get_tree().create_timer(0.52).timeout

    initiative_winner = _compare_initiative(initiative_cards[0], initiative_cards[1])
    phase = "INITIATIVE_CHOICE"
    _log("선공 판정: P1 %s / P2 %s" % [_card_name(initiative_cards[0]), _card_name(initiative_cards[1])])
    _log("P%d가 선공/후공 선택권을 얻었다." % (initiative_winner + 1))
    _refresh_ui()


func _deal_opening_hands_and_start(first_player: int) -> void:
    if game_over:
        return
    phase = "OPENING_DEAL"
    status_label.text = "선후공 결정 완료. 시작 손패를 5장까지 배분한다."
    _refresh_ui()

    var seq: int = 0
    for _round in range(4):
        for p in range(2):
            var card: Variant = _draw_raw()
            if card == null:
                _end_game(1 - p, "시작 손패를 배분할 카드가 부족하다.")
                return
            hands[p].append(card)
            _animate_draw_to_hand(p, card, seq)
            seq += 1
            _refresh_ui()
            await get_tree().create_timer(0.13).timeout

    _log("시작 손패 배분 완료: 각 플레이어 5장.")
    await get_tree().create_timer(0.25).timeout
    _start_turn(first_player)


func _draw_raw() -> Variant:
    if deck.is_empty():
        return null
    return deck.pop_back()

func _draw_cards(player: int, count: int) -> bool:
    # v0.3 호환용. v0.4의 실제 드로우는 _request_draw를 사용한다.
    _request_draw(player, count, Callable())
    return not game_over


func _request_draw(player: int, count: int, callback: Callable = Callable()) -> void:
    if game_over:
        return
    pending_draw_player = player
    pending_draw_remaining = maxi(count, 0)
    pending_draw_callback = callback
    draw_animation_sequence = 0
    phase = "DRAW_RESOLUTION"
    _continue_pending_draw()


func _continue_pending_draw() -> void:
    if game_over or pending_draw_player < 0:
        return

    while pending_draw_remaining > 0:
        if deck.is_empty():
            if not _begin_recycle_for_pending_draw():
                return
            if phase == "RECYCLE_DECISION" or game_over:
                return

        var card: Variant = _draw_raw()
        if card == null:
            _end_game(1 - pending_draw_player, "드로우 가능한 카드가 없어 게임을 종료했다.")
            return

        _animate_draw_to_hand(pending_draw_player, card, draw_animation_sequence)
        draw_animation_sequence += 1
        hands[pending_draw_player].append(card)
        pending_draw_remaining -= 1
        _log("P%d가 1장 드로우했다. (손패 %d장)" % [pending_draw_player + 1, hands[pending_draw_player].size()])

        if aeon_reinserted and str(card.get("effect_id", "")) == "AEON":
            _end_game(pending_draw_player, "재투입된 에온을 드로우하여 종국 승리가 발생했다.")
            return

        if hands[pending_draw_player].size() >= 21:
            _end_game(1 - pending_draw_player, "P%d의 손패가 21장 이상이 되어 파산했다." % (pending_draw_player + 1))
            return

    var callback: Callable = pending_draw_callback
    pending_draw_player = -1
    pending_draw_remaining = 0
    pending_draw_callback = Callable()
    if callback.is_valid():
        callback.call()
    elif not game_over:
        _refresh_ui()


func _begin_recycle_for_pending_draw() -> bool:
    recycle_count += 1
    var ended_aeon: int = recycle_count
    var next_aeon: int = recycle_count + 1
    _log("제%d 에온 종료: 덱이 소진되어 제%d 에온으로 전환한다." % [ended_aeon, next_aeon])
    _apply_recycle_pentacles()

    if recycle_count == 1:
        if _exclude_aeon_for_first_recycle():
            return false
        phase = "AEON_TRANSITION"
        status_label.text = "에온이 제외된다."
        _refresh_ui()
        _show_aeon_message("한 주기가 끝났습니다. 시대의 주인은 아직 왕좌에 안지 않았을 뿐이지만, 사람들은 그 부재를 죽음과 쉽게 혼동합니다.", Callable(self, "_resume_recycle_after_transition"))
        return false

    if not _excluded_contains_aeon():
        _rebuild_deck_from_discard()
        if deck.is_empty():
            _end_game(1 - pending_draw_player, "리사이클 후에도 드로우 가능한 카드가 없다.")
            return false
        _log("제%d 에온 개시." % next_aeon)
        return true

    recycle_votes = [null, null]
    recycle_voter = 0
    phase = "RECYCLE_DECISION"
    status_label.text = "제%d 에온 전환: P1부터 에온 재투입 여부를 선택한다." % next_aeon
    _refresh_ui()
    return false


func _contribute_pentacles(player: int, amount: int, reason: String) -> int:
    if amount <= 0:
        return 0
    var available: int = int(player_pentacles[player])
    var paid: int = mini(amount, available)
    player_pentacles[player] = available - paid
    shared_pentacles += paid
    pentacle_contributions[player] = int(pentacle_contributions[player]) + paid
    if paid > 0:
        _animate_pentacle_transfer(player, paid)
    _log("%s: P%d가 펜타클 %d개를 공동 더미에 냈다. (P%d %d / 공동 %d)" % [reason, player + 1, paid, player + 1, int(player_pentacles[player]), shared_pentacles])
    if paid < amount:
        _log("P%d의 보유 펜타클이 부족하여 요구량 %d개 중 %d개만 냈다." % [player + 1, amount, paid])
    return paid


func _apply_recycle_pentacles() -> void:
    var per_player: int = recycle_count
    _contribute_pentacles(0, per_player, "제%d 에온 종료" % recycle_count)
    _contribute_pentacles(1, per_player, "제%d 에온 종료" % recycle_count)


func _exclude_aeon_for_first_recycle() -> bool:
    for i in range(discard.size() - 1, -1, -1):
        if str(discard[i].get("effect_id", "")) == "AEON":
            var aeon_from_discard = discard.pop_at(i)
            _animate_card_transfer(discard_pile_button, aeon_status_label, aeon_from_discard, 0, true, "에온 종료")
            excluded.append(aeon_from_discard)
            _log("제1 에온 종료: 묘지의 에온을 게임에서 제외했다.")
            break

    for p in range(2):
        for i in range(hands[p].size() - 1, -1, -1):
            if str(hands[p][i].get("effect_id", "")) == "AEON":
                var aeon_from_hand = hands[p].pop_at(i)
                _animate_card_transfer(hand_panels[p], aeon_status_label, aeon_from_hand, 0, true, "에온 종료")
                excluded.append(aeon_from_hand)
                _log("제1 에온 종료: P%d 손패의 에온을 게임에서 제외했다." % (p + 1))
                if hands[p].is_empty():
                    _end_game(p, "제1 에온 종료 시 마지막 손패였던 에온이 제외되어 손패가 0장이 되었다.")
                    return true
                break
    return false


func _excluded_contains_aeon() -> bool:
    for card in excluded:
        if str(card.get("effect_id", "")) == "AEON":
            return true
    return false


func _take_aeon_from_excluded() -> Variant:
    for i in range(excluded.size()):
        if str(excluded[i].get("effect_id", "")) == "AEON":
            return excluded.pop_at(i)
    return null


func _submit_recycle_vote(player: int, reinsert: bool) -> void:
    if phase != "RECYCLE_DECISION" or player != recycle_voter:
        return
    recycle_votes[player] = reinsert
    _log("P%d: 에온을 새 덱에 %s." % [player + 1, "재투입한다" if reinsert else "재투입하지 않는다"])

    if player == 0:
        recycle_voter = 1
        status_label.text = "제%d 에온 전환: P2가 에온 재투입 여부를 선택한다." % (recycle_count + 1)
        _refresh_ui()
        return

    var should_reinsert: bool = bool(recycle_votes[0]) or bool(recycle_votes[1])
    if should_reinsert:
        var aeon: Variant = _take_aeon_from_excluded()
        if aeon != null:
            _animate_card_transfer(aeon_status_label, deck_pile_button, aeon, 0, true, "재투입")
            discard.append(aeon)
            aeon_reinserted = true
            _log("한 명 이상이 재투입을 선택하여 에온을 새 덱에 포함한다.")
    else:
        _log("두 플레이어가 모두 비재투입에 합의하여 에온은 제외 상태를 유지한다.")

    phase = "AEON_TRANSITION"
    status_label.text = "에온 전환을 정리 중이다."
    _refresh_ui()
    if should_reinsert:
        _show_aeon_message("때가 되었다. 그대의 주인을 맞이하라.", Callable(self, "_resume_recycle_after_transition"))
    else:
        _show_aeon_message("아직 사람들은 시대를 받아들일 준비가 되지 않았습니다. 그러나 이 유예는 영원할 수 없습니다.", Callable(self, "_resume_recycle_after_transition"))


func _rebuild_deck_from_discard() -> void:
    if not discard.is_empty():
        _animate_stack_transfer(discard_pile_button, deck_pile_button, discard.size(), "셔플")
    deck = discard.duplicate()
    discard.clear()
    deck.shuffle()
    _log("묘지를 셔플하여 새 덱 %d장을 만들었다." % deck.size())

func _compare_initiative(a, b) -> int:
    var type_a: int = int(TYPE_RANK.get(str(a.get("type", "SMALL")), 0))
    var type_b: int = int(TYPE_RANK.get(str(b.get("type", "SMALL")), 0))
    if type_a != type_b:
        return 0 if type_a > type_b else 1

    var card_type: String = str(a.get("type", "SMALL"))
    match card_type:
        "ATU":
            var atu_a: int = int(a.get("atu_number", 0))
            var atu_b: int = int(b.get("atu_number", 0))
            if atu_a != atu_b:
                return 0 if atu_a > atu_b else 1
        "COURT":
            var rank_a: int = int(COURT_RANK.get(str(a.get("court_rank", "Princess")), 0))
            var rank_b: int = int(COURT_RANK.get(str(b.get("court_rank", "Princess")), 0))
            if rank_a != rank_b:
                return 0 if rank_a > rank_b else 1
        "SMALL":
            var num_a: int = int(a.get("number", 0))
            var num_b: int = int(b.get("number", 0))
            if num_a != num_b:
                return 0 if num_a > num_b else 1

    var suit_a: int = int(SUIT_RANK.get(str(a.get("suit", "Disks")), 0))
    var suit_b: int = int(SUIT_RANK.get(str(b.get("suit", "Disks")), 0))
    return 0 if suit_a > suit_b else 1


func _confirm_bot_initiative_choice() -> void:
    if phase != "INITIATIVE_CHOICE" or not bot_enabled or initiative_winner != bot_player:
        return
    var choose_first: bool = false
    for card in hands[bot_player]:
        if _can_start_attack_with(bot_player, card):
            choose_first = true
            break
    _log("P2 BOT가 %s을 선택했다." % ("선공" if choose_first else "후공"))
    _choose_first(bot_player, choose_first)


func _choose_first(chooser: int, choose_first: bool) -> void:
    if phase != "INITIATIVE_CHOICE" or chooser != initiative_winner:
        return
    var first_player: int = chooser if choose_first else 1 - chooser
    _log("P%d가 %s을 선택했다. P%d부터 시작한다." % [chooser + 1, "선공" if choose_first else "후공", first_player + 1])
    _deal_opening_hands_and_start(first_player)


func _start_turn(player: int) -> void:
    if game_over:
        return
    current_player = player
    # 공개 효과는 기본적으로 턴 단위로 유지된다. 단, 썬 공개는 지정된 다음 자신의 턴 종료까지 지속된다.
    public_hand_flags = [false, false]
    if sun_reveal_owner >= 0:
        public_hand_flags = [true, true]
        if player == sun_reveal_owner:
            sun_reveal_armed = true

    # 데빌 공개 카드의 사용 금지는 다음 자신의 턴이 도착하는 순간 해제된다.
    devil_locked_ids[player].clear()

    # 허미트 사용 후 가장 먼저 돌아오는 자신의 턴은 완전히 스킵한다.
    if bool(hermit_skip_pending[player]):
        hermit_skip_pending[player] = false
        hermit_chain_pending[player] = true
        _log("허미트: P%d의 다음 자신의 턴을 스킵한다." % (player + 1))
        _mark_turn_finished(player)
        _start_turn(1 - player)
        return

    # 스킵 뒤 다시 돌아온 첫 실제 자기 턴부터 완전한 턴 3회를 연속 수행한다.
    if bool(hermit_chain_pending[player]):
        hermit_chain_pending[player] = false
        hermit_chain_remaining[player] = 3
        _log("허미트: P%d의 3연속 턴을 시작한다." % (player + 1))

    phase = "ACTION"
    selected_attack_index = -1
    var hermit_suffix: String = ""
    if int(hermit_chain_remaining[player]) > 0:
        var ordinal: int = 4 - int(hermit_chain_remaining[player])
        hermit_suffix = " 허미트 연속 턴 %d/3." % ordinal
    status_label.text = "P%d의 턴이다.%s" % [player + 1, hermit_suffix]
    _refresh_ui()


func _mark_turn_finished(player: int) -> void:
    var other: int = 1 - player
    # 허미트의 방어권 박탈은 사용 직후 시작되는 다음 상대 턴 한 번만 유지된다.
    if bool(defense_blocked[other]):
        defense_blocked[other] = false
        _log("허미트: P%d의 방어권 박탈이 종료되었다." % (other + 1))


func _finish_turn(player: int) -> void:
    _mark_turn_finished(player)

    if sun_reveal_owner == player and sun_reveal_armed:
        sun_reveal_owner = -1
        sun_reveal_armed = false
        public_hand_flags = [false, false]
        _log("썬 공개 효과가 종료되었다.")

    # 허미트의 연속 턴은 각각 독립된 완전한 턴이다.
    if int(hermit_chain_remaining[player]) > 0:
        hermit_chain_remaining[player] = int(hermit_chain_remaining[player]) - 1
        if int(hermit_chain_remaining[player]) > 0:
            _log("허미트: P%d의 다음 연속 턴을 시작한다. (%d회 남음)" % [player + 1, int(hermit_chain_remaining[player])])
            _start_turn(player)
            return


    # 포춘 추가 턴은 허미트 연속 턴과 별도로 누적된다.
    if int(extra_turns[player]) > 0:
        extra_turns[player] = int(extra_turns[player]) - 1
        _log("포춘으로 P%d의 추가 턴을 시작한다." % (player + 1))
        _start_turn(player)
    else:
        _start_turn(1 - player)


func _finish_action_draw(player: int) -> void:
    if game_over:
        return
    _finish_turn(player)

func _on_hand_card_pressed(player: int, index: int) -> void:
    if game_over:
        return
    if index < 0 or index >= hands[player].size():
        return

    var clicked_card = hands[player][index]
    _show_card_description(clicked_card)

    if phase == "ACTION":
        if player != current_player:
            return
        var card = hands[player][index]
        if not _can_start_attack_with(player, card):
            status_label.text = "%s은 현재 기본 공격으로 사용할 수 없거나 조건이 부족하다." % _card_name(card)
            return
        selected_attack_index = index
        status_label.text = "P%d: %s 선택." % [player + 1, _card_name(card)]
        _refresh_ui()
        return

    if phase == "ATTACK_BUILD":
        if player != current_player:
            return
        _handle_attack_build_card_click(index)
        return

    if phase == "HANGED_PICK":
        if player != current_player:
            return
        _resolve_hanged_pick(index)
        return

    if phase == "STAR_PICK_SELF":
        if player != current_player:
            return
        star_self_id = str(hands[player][index]["id"])
        phase = "STAR_PICK_OPP"
        status_label.text = "스타: 교환할 상대 카드 1장을 선택한다."
        _refresh_ui()
        return

    if phase == "STAR_PICK_OPP":
        if player != 1 - current_player:
            return
        _resolve_star_exchange(index)
        return

    if phase == "SUN_EXTRA":
        if player != current_player:
            return
        var sun_card = hands[player][index]
        if not _can_be_added_as_attack_card(player, sun_card):
            return
        _start_attack_draft(str(sun_card["id"]), true)
        return

    if phase == "DEFENSE":
        var defender: int = 1 - current_player
        if player != defender:
            return
        if bool(defense_blocked[defender]):
            status_label.text = "허미트 효과로 이번 턴에는 방어할 수 없다."
            return
        if attack_package.is_empty():
            return

        var defense_card = hands[player][index]
        if _is_card_locked_for_player(defender, str(defense_card.get("id", ""))):
            status_label.text = "데빌로 공개된 카드는 다음 자신의 턴이 올 때까지 사용할 수 없다."
            return
        var defense_type: String = str(defense_card.get("type", ""))
        var effect_id: String = str(defense_card.get("effect_id", ""))

        if defense_type == "ATU" and effect_id in DEFENSE_ATU_EFFECTS:
            _toggle_defense_atu(defense_card)
            return

        var target_index: int = clampi(selected_defense_target, 0, attack_package.size() - 1)
        var attack_card = attack_package[target_index]["card"]

        if _defense_card_used_elsewhere(str(defense_card["id"]), target_index):
            status_label.text = "그 카드는 이미 다른 공격에 배정되어 있다."
            return

        if _target_is_covered_by_selected_nullifier(target_index):
            status_label.text = "이미 무효 아투가 적용되는 공격에는 일반 방어를 함께 낼 수 없다."
            return

        if not _can_defend(attack_card, defense_card):
            status_label.text = "%s로는 %s을 방어할 수 없다." % [_card_name(defense_card), _card_name(attack_card)]
            return

        defense_draft[target_index] = str(defense_card["id"])
        _recompute_defense_atu_choices()
        status_label.text = "%s → %s 일반 방어 배정." % [_card_name(defense_card), _card_name(attack_card)]
        _refresh_ui()

func _find_hand_index_by_id(player: int, card_id: String) -> int:
    if player < 0 or player >= hands.size():
        return -1
    for i in range(hands[player].size()):
        if str(hands[player][i].get("id", "")) == card_id:
            return i
    return -1


func _find_first_compatible_defense_target(defense_card) -> int:
    if phase != "DEFENSE" or defense_card == null:
        return -1
    var card_id: String = str(defense_card.get("id", ""))
    for target_index in range(attack_package.size()):
        if _defense_card_used_elsewhere(card_id, target_index):
            continue
        if _target_is_covered_by_selected_nullifier(target_index):
            continue
        var entry: Dictionary = attack_package[target_index]
        var attack_card = entry.get("card", null)
        if attack_card != null and _can_defend(attack_card, defense_card):
            return target_index
    return -1


func _pick_defense_target_from_drop(defense_card, at_position: Vector2) -> int:
    if phase != "DEFENSE" or defense_card == null:
        return -1

    var compatible: Array = []
    var card_id: String = str(defense_card.get("id", ""))
    for target_index in range(attack_package.size()):
        if _defense_card_used_elsewhere(card_id, target_index):
            continue
        if _target_is_covered_by_selected_nullifier(target_index):
            continue
        var attack_card = attack_package[target_index].get("card", null)
        if attack_card != null and _can_defend(attack_card, defense_card):
            compatible.append(target_index)

    if compatible.is_empty():
        return -1
    if compatible.size() == 1:
        return int(compatible[0])

    # 둘 이상의 공격을 방어할 수 있을 때는 전장의 좌/우 위치로 대상을 정한다.
    var field_rect: Rect2 = battlefield_box.get_global_rect()
    var global_x: float = battlefield_drop_zone.get_global_rect().position.x + at_position.x
    var ratio: float = clampf((global_x - field_rect.position.x) / maxf(field_rect.size.x, 1.0), 0.0, 0.9999)
    var normal_targets: Array = []
    for i in range(attack_package.size()):
        if _is_normal_attack_card(attack_package[i].get("card", null)):
            normal_targets.append(i)
    if normal_targets.is_empty():
        return int(compatible[0])

    var visual_slot: int = clampi(int(floor(ratio * float(normal_targets.size()))), 0, normal_targets.size() - 1)
    var preferred: int = int(normal_targets[visual_slot])
    if preferred in compatible:
        return preferred

    # 해당 위치의 공격을 못 막는 카드라면 가장 가까운 합법 대상을 사용한다.
    var preferred_pos: int = normal_targets.find(preferred)
    var best_target: int = int(compatible[0])
    var best_distance: int = 99999
    for candidate in compatible:
        var candidate_pos: int = normal_targets.find(int(candidate))
        var distance: int = abs(candidate_pos - preferred_pos) if candidate_pos >= 0 and preferred_pos >= 0 else 9999
        if distance < best_distance:
            best_distance = distance
            best_target = int(candidate)
    return best_target


func _on_battlefield_drop_at(data, at_position: Vector2) -> void:
    if game_over or not (data is Dictionary):
        return

    if phase != "DEFENSE":
        _on_battlefield_drop(data)
        return

    var defender: int = 1 - current_player
    var player: int = int(data.get("player", -1))
    if player != defender:
        return
    var card_id: String = str(data.get("card_id", ""))
    var index: int = _find_hand_index_by_id(player, card_id)
    if index < 0:
        return

    var dropped_card = hands[player][index]
    var effect_id: String = str(dropped_card.get("effect_id", ""))
    if str(dropped_card.get("type", "")) == "ATU" and effect_id in DEFENSE_ATU_EFFECTS:
        _on_hand_card_pressed(player, index)
        return

    var target_index: int = _pick_defense_target_from_drop(dropped_card, at_position)
    if target_index >= 0:
        selected_defense_target = target_index
        _on_hand_card_pressed(player, index)


func _on_battlefield_drop(data) -> void:
    if game_over or not (data is Dictionary):
        return
    var player: int = int(data.get("player", -1))
    var card_id: String = str(data.get("card_id", ""))
    var index: int = _find_hand_index_by_id(player, card_id)
    if index < 0:
        return

    if phase == "ACTION" and player == current_player:
        _on_hand_card_pressed(player, index)
        if selected_attack_index == index:
            _begin_attack_build()
        return

    if phase in ["ATTACK_BUILD", "SUN_EXTRA"]:
        _on_hand_card_pressed(player, index)
        return

    if phase == "DEFENSE":
        var defender: int = 1 - current_player
        if player != defender:
            return
        var dropped_card = hands[player][index]
        var effect_id: String = str(dropped_card.get("effect_id", ""))
        if str(dropped_card.get("type", "")) == "ATU" and effect_id in DEFENSE_ATU_EFFECTS:
            _on_hand_card_pressed(player, index)
            return
        var compatible_target: int = _find_first_compatible_defense_target(dropped_card)
        if compatible_target >= 0:
            selected_defense_target = compatible_target
            _on_hand_card_pressed(player, index)


func _on_defense_package_drop(data) -> void:
    if phase != "DEFENSE" or game_over or not (data is Dictionary):
        return
    var defender: int = 1 - current_player
    if int(data.get("player", -1)) != defender:
        return
    # 방어 패키지 전체에 드롭하면 현재 선택된 공격 슬롯에 일반 방어를,
    # 방어 아투라면 패키지 전체에 바로 추가한다.
    _on_battlefield_drop(data)


func _on_attack_lane_drop(data, target_index: int) -> void:
    if phase != "DEFENSE" or game_over or not (data is Dictionary):
        return
    var defender: int = 1 - current_player
    var player: int = int(data.get("player", -1))
    if player != defender:
        return
    var card_id: String = str(data.get("card_id", ""))
    var index: int = _find_hand_index_by_id(player, card_id)
    if index < 0:
        return
    selected_defense_target = clampi(target_index, 0, maxi(attack_package.size() - 1, 0))
    _on_hand_card_pressed(player, index)


func _on_hand_return_drop(data, hand_player: int) -> void:
    if game_over or not (data is Dictionary):
        return
    if str(data.get("kind", "")) != "BATTLE_CARD":
        return
    var owner: int = int(data.get("player", -1))
    if owner != hand_player:
        return
    var location: String = str(data.get("location", ""))
    var card_id: String = str(data.get("card_id", ""))

    if phase == "ATTACK_BUILD" and hand_player == current_player and location == "ATTACK_DRAFT":
        _on_attack_draft_battlefield_card_pressed(card_id)
        return

    if phase == "DEFENSE" and hand_player == 1 - current_player:
        if location == "DEFENSE_DRAFT":
            var target_index: int = int(data.get("target_index", -1))
            if defense_draft.has(target_index) and str(defense_draft[target_index]) == card_id:
                defense_draft.erase(target_index)
                _recompute_defense_atu_choices()
                _refresh_ui()
            return
        if location == "DEFENSE_ATU" and _defense_atu_contains_card(card_id):
            var card := _find_card_in_hand_by_id(hand_player, card_id)
            if card != null:
                _toggle_defense_atu(card)
            return


func _begin_attack_build() -> void:
    if phase != "ACTION" or selected_attack_index < 0:
        return
    if selected_attack_index >= hands[current_player].size():
        selected_attack_index = -1
        return
    var base_card = hands[current_player][selected_attack_index]
    _start_attack_draft(str(base_card["id"]), false)

func _handle_attack_build_card_click(index: int) -> void:
    if phase != "ATTACK_BUILD" or index < 0 or index >= hands[current_player].size():
        return
    var card = hands[current_player][index]
    var card_id: String = str(card["id"])

    var condition_source: String = _unresolved_condition_source_id()
    if condition_source != "":
        if _toggle_condition_card(condition_source, card):
            _refresh_ui()
        return

    if str(card.get("effect_id", "")) == "ART":
        if attack_art_id == card_id:
            attack_art_id = ""
            attack_art_target_id = ""
            status_label.text = "아트 선택을 취소했다."
        elif _available_small_attack_ids().is_empty():
            status_label.text = "아트는 공격 패키지 안의 스몰카드가 있어야 사용할 수 있다."
        else:
            attack_art_id = card_id
            attack_art_target_id = str(_available_small_attack_ids()[0])
            status_label.text = "아트를 선택했다. 증폭 대상을 지정할 수 있다."
        _refresh_ui()
        return

    if card_id in attack_draft_ids:
        return
    if card_id == attack_art_id:
        return

    var token_index: int = _find_compatible_attack_token(card)
    if token_index < 0:
        return
    if not _can_be_added_as_attack_card(current_player, card):
        return

    attack_tokens.remove_at(token_index)
    attack_draft_ids.append(card_id)
    _register_condition_source(card)
    _grant_attack_tokens(card)
    status_label.text = _attack_build_status()
    _refresh_ui()

func _on_attack_draft_battlefield_card_pressed(card_id: String) -> void:
    if phase != "ATTACK_BUILD" or not (card_id in attack_draft_ids):
        return
    var card: Variant = _find_card_in_hand_by_id(current_player, card_id)
    if card == null or str(card.get("type", "")) == "ATU":
        return

    attack_draft_ids.erase(card_id)

    if attack_art_target_id == card_id:
        var remaining_small: Array = _available_small_attack_ids()
        if remaining_small.is_empty():
            attack_art_id = ""
            attack_art_target_id = ""
        else:
            attack_art_target_id = str(remaining_small[0])

    if card_id == attack_base_id:
        if attack_draft_ids.is_empty():
            _cancel_attack_build()
            return
        attack_base_id = str(attack_draft_ids[0])

    _rebuild_attack_tokens_from_draft()
    status_label.text = "%s을 공격 패키지에서 제외했다. %s" % [_card_name(card), _attack_build_status()]
    _refresh_ui()


func _rebuild_attack_tokens_from_draft() -> void:
    attack_tokens.clear()
    for card_id in attack_draft_ids:
        var card: Variant = _find_card_in_hand_by_id(current_player, str(card_id))
        if card == null:
            continue
        if str(card_id) != attack_base_id:
            var token_index: int = _find_compatible_attack_token(card)
            if token_index >= 0:
                attack_tokens.remove_at(token_index)
        _grant_attack_tokens(card)


func _cancel_attack_build() -> void:
    if phase != "ATTACK_BUILD":
        return
    if attack_append_mode:
        attack_draft_ids.clear()
        attack_tokens.clear()
        condition_family.clear()
        condition_ids.clear()
        attack_art_id = ""
        attack_art_target_id = ""
        attack_base_id = ""
        attack_append_mode = false
        phase = "SUN_EXTRA"
        status_label.text = "썬: 추가로 낼 카드 1장을 선택하거나 생략한다."
        _refresh_ui()
        return

    phase = "ACTION"
    _reset_attack_draft()
    status_label.text = "공격 구성을 취소했다."
    _refresh_ui()

func _attack_build_ready() -> bool:
    if attack_draft_ids.is_empty():
        return false
    if _unresolved_condition_source_id() != "":
        return false
    for token in attack_tokens:
        if bool(token.get("mandatory", false)):
            return false
    if attack_art_id != "" and attack_art_target_id == "":
        return false
    return true

func _submit_attack_package() -> void:
    if phase != "ATTACK_BUILD" or not _attack_build_ready():
        return

    var was_append: bool = attack_append_mode
    var start_index: int = attack_package.size() if was_append else 0
    if not was_append:
        attack_package.clear()
        used_attack_misc.clear()
        defense_draft.clear()
        defense_atu_choices.clear()
        defense_atu_used.clear()
        reaction_cards.clear()
        post_effect_queue.clear()
        art_target_index = -1

    var submitted_names: Array = []
    var submitted_ids: Array = attack_draft_ids.duplicate()
    var local_art_target_id: String = attack_art_target_id
    var local_art_id: String = attack_art_id
    var local_conditions: Dictionary = condition_ids.duplicate(true)

    for card_id in submitted_ids:
        var removed: Variant = _remove_card_by_id(current_player, str(card_id))
        if removed == null:
            continue
        attack_package.append(_make_attack_entry(removed))
        _animate_card_transfer(hand_panels[current_player], battlefield_box, removed, submitted_names.size(), true, "공격")
        submitted_names.append(_card_name(removed))

    if local_art_id != "":
        var art_card: Variant = _remove_card_by_id(current_player, local_art_id)
        if art_card != null:
            used_attack_misc.append(art_card)
            _animate_card_transfer(hand_panels[current_player], battlefield_box, art_card, submitted_names.size(), true, "효과")
            submitted_names.append(_card_name(art_card))
            for i in range(attack_package.size()):
                if str(attack_package[i]["card"].get("id", "")) == local_art_target_id:
                    art_target_index = i
                    break

    # 유니버스 비용은 유니버스 제출 뒤 손패에서 실제로 제거한다.
    for source_id in submitted_ids:
        var source_entry: Variant = _find_attack_entry_by_card_id(str(source_id))
        if source_entry == null:
            continue
        var source_card = source_entry["card"]
        var effect_id: String = str(source_card.get("effect_id", ""))
        if effect_id == "UNIVERSE":
            var costs: Array = local_conditions.get(str(source_id), [])
            for cost_id in costs:
                var cost_card: Variant = _remove_card_by_id(current_player, str(cost_id))
                if cost_card != null:
                    _animate_card_transfer(hand_panels[current_player], discard_pile_button, cost_card, 0, true, "비용")
                    discard.append(cost_card)
                    _log("유니버스 비용: %s을 묘지로 보냈다." % _card_name(cost_card))
        elif effect_id == "DEVIL":
            var locks: Array = local_conditions.get(str(source_id), [])
            for lock_id in locks:
                if not (str(lock_id) in devil_locked_ids[current_player]):
                    devil_locked_ids[current_player].append(str(lock_id))
            if not locks.is_empty():
                _log("데빌 조건 공개 및 잠금: %s" % _names_for_hand_ids(current_player, locks))
        elif effect_id == "HIEROPHANT":
            var reveals: Array = local_conditions.get(str(source_id), [])
            if not reveals.is_empty():
                _log("하이에로펀트 조건 공개: %s" % _names_for_hand_ids(current_player, reveals))

    _log("P%d %s: %s" % [current_player + 1, "추가 제출" if was_append else "공격 패키지 제출", _join_strings(submitted_names, ", ")])

    _reset_attack_draft()
    # 패키지 제출 및 유니버스 비용 지불로 0장이 되면 후속 효과보다 즉시 승리한다.
    if hands[current_player].is_empty():
        _end_game(current_player, "P%d가 공격 카드 제출 또는 유니버스 비용 지불로 손패가 0장이 되었다." % (current_player + 1))
        return

    var new_effects: Array = _post_effects_for_range(start_index, attack_package.size())
    if was_append:
        post_effect_queue = new_effects + post_effect_queue
    else:
        post_effect_queue = new_effects

    attack_append_mode = false
    court_scan_index = start_index
    _advance_court_completion()

func _make_attack_entry(card, direct_draw: int = -1) -> Dictionary:
    var effect_id: String = str(card.get("effect_id", ""))
    var resolved_direct: int = direct_draw
    if resolved_direct < 0:
        match effect_id:
            "HIEROPHANT": resolved_direct = 5
            "DEVIL": resolved_direct = 7
            "UNIVERSE": resolved_direct = 12
            _: resolved_direct = 0
    return {
        "card": card,
        "defense": null,
        "direct_draw": resolved_direct,
        "cannot_be_nullified": effect_id == "DEVIL" or effect_id == "UNIVERSE",
        "lovers_protected": effect_id == "UNIVERSE",
        "nullified": false,
        "resolved_draw": 0
    }

func _advance_court_completion() -> void:
    court_completion_options.clear()

    while court_scan_index < attack_package.size():
        var entry: Dictionary = attack_package[court_scan_index]
        var card = entry["card"]
        if str(card.get("type", "")) == "COURT":
            court_completion_options = _find_court_completion_options(current_player, card)
            if not court_completion_options.is_empty():
                phase = "COURT_COMPLETION"
                status_label.text = "%s의 궁정 완성이 가능하다." % _card_name(card)
                _refresh_ui()
                return
        court_scan_index += 1

    _process_next_post_effect()


func _start_attack_draft(base_id: String, append_mode: bool) -> void:
    var base_card: Variant = _find_card_in_hand_by_id(current_player, base_id)
    if base_card == null:
        return
    if str(base_card.get("effect_id", "")) == "MOON" and discard.is_empty():
        status_label.text = "문은 묘지에 카드가 1장 이상 있을 때만 사용할 수 있다."
        _refresh_ui()
        return
    attack_base_id = base_id
    attack_draft_ids = [base_id]
    attack_tokens.clear()
    condition_family.clear()
    condition_ids.clear()
    attack_art_id = ""
    attack_art_target_id = ""
    attack_append_mode = append_mode
    append_start_index = attack_package.size()

    _register_condition_source(base_card)
    _grant_attack_tokens(base_card)
    phase = "ATTACK_BUILD"
    status_label.text = _attack_build_status()
    _refresh_ui()


func _reset_attack_draft() -> void:
    selected_attack_index = -1
    attack_base_id = ""
    attack_draft_ids.clear()
    attack_tokens.clear()
    condition_family.clear()
    condition_ids.clear()
    attack_art_id = ""
    attack_art_target_id = ""
    attack_append_mode = false
    append_start_index = 0


func _grant_attack_tokens(card) -> void:
    var source_id: String = str(card.get("id", ""))
    match str(card.get("effect_id", "")):
        "MAGUS":
            attack_tokens.append({"family": "MAGICAL", "mandatory": true, "source_id": source_id})
            attack_tokens.append({"family": "MAGICAL", "mandatory": true, "source_id": source_id})
        "EMPRESS":
            attack_tokens.append({"family": "MAGICAL", "mandatory": true, "source_id": source_id})
        "EMPEROR":
            attack_tokens.append({"family": "PHYSICAL", "mandatory": true, "source_id": source_id})
        "TOWER":
            attack_tokens.append({"family": "PHYSICAL", "mandatory": true, "source_id": source_id})
            attack_tokens.append({"family": "PHYSICAL", "mandatory": true, "source_id": source_id})
        "AEON":
            attack_tokens.append({"family": "PHYSICAL", "mandatory": true, "source_id": source_id})
            attack_tokens.append({"family": "MAGICAL", "mandatory": true, "source_id": source_id})
        "FORTUNE":
            # 포춘은 사용한 현재 턴 안에서 유효 공격 카드 1장을 추가로 낼 수 있다.
            # 동시에 후처리에서 추가 턴 1회도 예약한다.
            attack_tokens.append({"family": "ANY", "mandatory": false, "source_id": source_id})


func _register_condition_source(card) -> void:
    var effect_id: String = str(card.get("effect_id", ""))
    if effect_id in ["HIEROPHANT", "DEVIL", "UNIVERSE"]:
        var source_id: String = str(card["id"])
        condition_ids[source_id] = []
        if effect_id == "HIEROPHANT":
            condition_family[source_id] = "ANY"
        else:
            condition_family[source_id] = ""


func _unresolved_condition_source_id() -> String:
    for source_id in attack_draft_ids:
        var card: Variant = _find_card_anywhere_for_draft(str(source_id))
        if card == null:
            continue
        var effect_id: String = str(card.get("effect_id", ""))
        if not (effect_id in ["HIEROPHANT", "DEVIL", "UNIVERSE"]):
            continue
        var required: int = _condition_required_count(effect_id)
        var selected: Array = condition_ids.get(str(source_id), [])
        if effect_id != "HIEROPHANT" and str(condition_family.get(str(source_id), "")) == "":
            return str(source_id)
        if selected.size() != required:
            return str(source_id)
    return ""


func _condition_required_count(effect_id: String) -> int:
    match effect_id:
        "HIEROPHANT": return 1
        "DEVIL": return 2
        "UNIVERSE": return 3
        _: return 0


func _set_condition_family(source_id: String, family: String) -> void:
    if phase != "ATTACK_BUILD" or not (family in ["ACE", "KNIGHT"]):
        return
    var source: String = _unresolved_condition_source_id()
    if source != source_id:
        return
    condition_family[source_id] = family
    condition_ids[source_id] = []
    status_label.text = _attack_build_status()
    _refresh_ui()


func _toggle_condition_card(source_id: String, card) -> bool:
    var source_card: Variant = _find_card_anywhere_for_draft(source_id)
    if source_card == null:
        return false
    var effect_id: String = str(source_card.get("effect_id", ""))
    var family: String = str(condition_family.get(source_id, ""))
    if effect_id != "HIEROPHANT" and family == "":
        return false
    if not _card_matches_condition_family(card, family):
        return false

    var card_id: String = str(card["id"])
    if card_id == source_id:
        return false
    if effect_id in ["DEVIL", "UNIVERSE"] and card_id in attack_draft_ids:
        return false
    if effect_id == "UNIVERSE" and card_id == attack_art_id:
        return false
    if effect_id in ["DEVIL", "UNIVERSE"] and _condition_card_reserved_elsewhere(source_id, card_id):
        return false

    var selected: Array = condition_ids.get(source_id, [])
    if card_id in selected:
        selected.erase(card_id)
    else:
        if selected.size() >= _condition_required_count(effect_id):
            selected.pop_front()
        selected.append(card_id)
    condition_ids[source_id] = selected
    status_label.text = _attack_build_status()
    return true

func _card_matches_condition_family(card, family: String) -> bool:
    if card == null:
        return false
    var card_type: String = str(card.get("type", ""))
    var effect_id: String = str(card.get("effect_id", ""))
    if family == "ANY":
        return card_type == "ACE" or (card_type == "COURT" and str(card.get("court_rank", "")) == "Knight") or effect_id == "FOOL"
    if family == "ACE":
        return card_type == "ACE" or effect_id == "FOOL"
    if family == "KNIGHT":
        return (card_type == "COURT" and str(card.get("court_rank", "")) == "Knight") or effect_id == "FOOL"
    return false


func _find_compatible_attack_token(card) -> int:
    if card == null:
        return -1
    var family: String = CardDatabase.physical_or_magical(card)
    for i in range(attack_tokens.size()):
        var token_family: String = str(attack_tokens[i].get("family", "ANY"))
        if token_family != "ANY" and token_family == family:
            return i
    for i in range(attack_tokens.size()):
        if str(attack_tokens[i].get("family", "ANY")) == "ANY":
            return i
    return -1


func _can_be_added_as_attack_card(player: int, card) -> bool:
    if card == null:
        return false
    var card_id: String = str(card.get("id", ""))
    if _is_card_locked_for_player(player, card_id) or _card_reserved_by_condition(card_id):
        return false
    var card_type: String = str(card.get("type", ""))
    if card_type == "SMALL":
        return str(card.get("suit", "")) in ATTACK_SMALL_SUITS
    if card_type == "ACE" or card_type == "COURT":
        return true
    if card_type != "ATU":
        return false
    var effect_id: String = str(card.get("effect_id", ""))
    if effect_id == "ART" or not (effect_id in ATTACK_ATU_EFFECTS):
        return false
    if effect_id == "MOON" and discard.is_empty():
        return false
    if effect_id == "HIEROPHANT":
        return _has_condition_family_count(player, "ANY", 1, card_id)
    if effect_id == "DEVIL":
        return _count_available_condition_for_build("ACE", card_id) >= 2 or _count_available_condition_for_build("KNIGHT", card_id) >= 2
    if effect_id == "UNIVERSE":
        return _count_available_condition_for_build("ACE", card_id) >= 3 or _count_available_condition_for_build("KNIGHT", card_id) >= 3
    if effect_id == "MAGUS":
        return _count_available_elemental_for_build("MAGICAL", card_id) >= 2
    if effect_id == "EMPRESS":
        return _count_available_elemental_for_build("MAGICAL", card_id) >= 1
    if effect_id == "EMPEROR":
        return _count_available_elemental_for_build("PHYSICAL", card_id) >= 1
    if effect_id == "TOWER":
        return _count_available_elemental_for_build("PHYSICAL", card_id) >= 2
    if effect_id == "AEON":
        return _count_available_elemental_for_build("PHYSICAL", card_id) >= 1 and _count_available_elemental_for_build("MAGICAL", card_id) >= 1
    return true

func _condition_card_reserved_elsewhere(source_id: String, card_id: String) -> bool:
    for other_source in condition_ids.keys():
        if str(other_source) == source_id:
            continue
        var source: Variant = _find_card_anywhere_for_draft(str(other_source))
        if source == null:
            continue
        var effect_id: String = str(source.get("effect_id", ""))
        if effect_id in ["DEVIL", "UNIVERSE"] and card_id in condition_ids.get(str(other_source), []):
            return true
    return false


func _count_available_elemental_for_build(family: String, excluded_id: String = "") -> int:
    var count: int = 0
    for card in hands[current_player]:
        var card_id: String = str(card.get("id", ""))
        if card_id == excluded_id or card_id in attack_draft_ids or card_id == attack_art_id:
            continue
        if _is_card_locked_for_player(current_player, card_id) or _card_reserved_by_condition(card_id):
            continue
        if _is_elemental_attack_card(card) and CardDatabase.physical_or_magical(card) == family:
            count += 1
    return count


func _count_available_condition_for_build(family: String, excluded_id: String = "") -> int:
    var count: int = 0
    for card in hands[current_player]:
        var card_id: String = str(card.get("id", ""))
        if card_id == excluded_id or card_id in attack_draft_ids or _card_reserved_by_condition(card_id):
            continue
        if _card_matches_condition_family(card, family):
            count += 1
    return count


func _card_reserved_by_condition(card_id: String) -> bool:
    for source_id in condition_ids.keys():
        var source: Variant = _find_card_anywhere_for_draft(str(source_id))
        if source == null:
            continue
        var effect_id: String = str(source.get("effect_id", ""))
        if effect_id in ["DEVIL", "UNIVERSE"]:
            var ids: Array = condition_ids.get(str(source_id), [])
            if card_id in ids:
                return true
    return false


func _has_condition_family_count(player: int, family: String, count: int, excluded_id: String = "") -> bool:
    var n: int = 0
    for card in hands[player]:
        if str(card.get("id", "")) == excluded_id:
            continue
        if _card_matches_condition_family(card, family):
            n += 1
    return n >= count


func _is_card_locked_for_player(player: int, card_id: String) -> bool:
    return card_id in devil_locked_ids[player]


func _available_small_attack_ids() -> Array:
    var ids: Array = []
    for entry in attack_package:
        if str(entry["card"].get("type", "")) == "SMALL":
            ids.append(str(entry["card"]["id"]))
    for card_id in attack_draft_ids:
        var card: Variant = _find_card_in_hand_by_id(current_player, str(card_id))
        if card != null and str(card.get("type", "")) == "SMALL":
            ids.append(str(card_id))
    return ids


func _select_art_target(card_id: String) -> void:
    if phase != "ATTACK_BUILD" or attack_art_id == "":
        return
    if card_id in _available_small_attack_ids():
        attack_art_target_id = card_id
        status_label.text = "아트 대상: %s — 방어 정산 후 남은 드로우 수를 2배로 한다." % _card_name_by_id_for_build(card_id)
        _refresh_ui()


func _find_card_anywhere_for_draft(card_id: String) -> Variant:
    var in_hand: Variant = _find_card_in_hand_by_id(current_player, card_id)
    if in_hand != null:
        return in_hand
    for entry in attack_package:
        if str(entry["card"].get("id", "")) == card_id:
            return entry["card"]
    return null


func _find_attack_entry_by_card_id(card_id: String) -> Variant:
    for entry in attack_package:
        if str(entry["card"].get("id", "")) == card_id:
            return entry
    return null


func _card_name_by_id_for_build(card_id: String) -> String:
    var card: Variant = _find_card_anywhere_for_draft(card_id)
    return _card_name(card)


func _names_for_hand_ids(player: int, ids: Array) -> String:
    var names: Array = []
    for card_id in ids:
        var card: Variant = _find_card_in_hand_by_id(player, str(card_id))
        if card != null:
            names.append(_card_name(card))
    return _join_strings(names, ", ")


func _attack_build_status() -> String:
    var source_id: String = _unresolved_condition_source_id()
    if source_id != "":
        var source: Variant = _find_card_anywhere_for_draft(source_id)
        var effect_id: String = str(source.get("effect_id", "")) if source != null else ""
        var family: String = str(condition_family.get(source_id, ""))
        var selected: Array = condition_ids.get(source_id, [])
        if effect_id in ["DEVIL", "UNIVERSE"] and family == "":
            return "%s: 에이스 계열 또는 나이트 계열을 먼저 선택한다." % _card_name(source)
        return "%s 조건 카드 선택: %d/%d" % [_card_name(source), selected.size(), _condition_required_count(effect_id)]

    var mandatory: int = 0
    var optional: int = 0
    for token in attack_tokens:
        if bool(token.get("mandatory", false)):
            mandatory += 1
        else:
            optional += 1
    if mandatory > 0:
        return "추가 공격 카드가 %d장 더 필요하다. (선택 추가권 %d장)" % [mandatory, optional]
    if optional > 0:
        return "공격 패키지 구성 완료. 추가로 최대 %d장 더 낼 수 있다." % optional
    return "공격 패키지 구성이 완료되었다."


func _post_effects_for_range(start_index: int, end_index: int) -> Array:
    var result: Array = []
    for i in range(start_index, end_index):
        var effect_id: String = str(attack_package[i]["card"].get("effect_id", ""))
        if effect_id in ["ADJUSTMENT", "HERMIT", "FORTUNE", "HANGED_MAN", "DEATH", "MOON", "STAR", "SUN"]:
            result.append({"effect_id": effect_id, "index": i})
    return result


func _process_next_post_effect() -> void:
    if game_over:
        return
    if post_effect_queue.is_empty():
        _begin_defense()
        return

    var effect: Dictionary = post_effect_queue.pop_front()
    var effect_id: String = str(effect.get("effect_id", ""))
    match effect_id:
        "ADJUSTMENT":
            _log("어저스트먼트 선택지 1: 상대 손패를 공개한다. 확인 완료를 눌러야 다음 단계로 넘어간다.")
            _handle_opponent_hand_reveal(current_player, 1 - current_player, _begin_adjustment_reveal_wait)
        "HERMIT":
            hermit_skip_pending[current_player] = true
            defense_blocked[current_player] = true
            _log("허미트: P%d는 다음 상대 턴에 방어할 수 없고, 다음 자신의 턴을 스킵한 뒤 자기 턴 3회를 연속 수행한다." % (current_player + 1))
            _process_next_post_effect()
        "FORTUNE":
            extra_turns[current_player] = int(extra_turns[current_player]) + 1
            _log("포춘: 현재 공격 패키지에 카드 1장을 추가로 낼 수 있으며, 현재 턴 종료 뒤 P%d가 한 턴을 추가로 수행한다." % (current_player + 1))
            _process_next_post_effect()
        "HANGED_MAN":
            phase = "HANGED_PICK"
            status_label.text = "행맨: 손패에서 묘지로 보낼 카드 1장을 선택한다."
            _refresh_ui()
        "DEATH":
            _resolve_death_effect()
        "MOON":
            if discard.is_empty():
                _log("문: 묘지가 비어 있어 회수할 카드가 없다.")
                _process_next_post_effect()
            else:
                phase = "MOON_PICK"
                status_label.text = "문: 묘지에서 손패로 되돌릴 카드 1장을 선택한다."
                _refresh_ui()
        "STAR":
            public_hand_flags = [true, true]
            _log("스타: 양 플레이어의 손패를 공개한다.")
            _log("P1: %s" % _hand_text(0))
            _log("P2: %s" % _hand_text(1))
            _handle_opponent_hand_reveal(current_player, 1 - current_player, _begin_star_exchange_after_reveal)
        "SUN":
            public_hand_flags = [true, true]
            sun_reveal_owner = current_player
            sun_reveal_armed = false
            _log("썬: 양 플레이어의 손패를 공개한다. 공개는 사용자의 다음 턴 종료까지 유지된다.")
            _log("P1: %s" % _hand_text(0))
            _log("P2: %s" % _hand_text(1))
            _handle_opponent_hand_reveal(current_player, 1 - current_player, _begin_sun_extra_after_reveal)
        _:
            _process_next_post_effect()


func _handle_opponent_hand_reveal(revealer: int, target: int, callback: Callable) -> void:
    public_hand_flags[target] = true
    _log("P%d 손패 공개: %s" % [target + 1, _hand_text(target)])
    _refresh_ui()
    var moon_id: String = ""
    for card in hands[target]:
        if str(card.get("effect_id", "")) == "MOON":
            moon_id = str(card["id"])
            break
    if moon_id == "":
        if callback.is_valid():
            callback.call()
        return

    var moon: Variant = _remove_card_by_id(target, moon_id)
    if moon == null:
        if callback.is_valid():
            callback.call()
        return
    _animate_card_transfer(hand_panels[target], hand_panels[revealer], moon, 0, true, "문 공개")
    hands[revealer].append(moon)
    _log("문 공개 효과: %s이 P%d의 손패로 이동했다." % [_card_name(moon), revealer + 1])

    if hands[target].is_empty():
        _end_game(target, "문 공개 효과로 P%d의 마지막 손패가 이동하여 손패가 0장이 되었다." % (target + 1))
        return
    if hands[revealer].size() >= 21:
        _end_game(target, "문이 이동한 순간 P%d의 손패가 21장 이상이 되어 파산했다." % (revealer + 1))
        return

    _log("문 공개 효과: 공개 효과 사용자인 P%d가 6장 드로우한다." % (revealer + 1))
    _request_draw(revealer, 6, callback)


func _begin_adjustment_reveal_wait() -> void:
    if game_over:
        return
    phase = "REVEAL_CONFIRM"
    reveal_confirm_callback = Callable(self, "_process_next_post_effect")
    status_label.text = "어저스트먼트: 상대 손패 확인이 끝났다면 확인 완료를 눌러 다음 단계로 진행한다."
    _refresh_ui()


func _confirm_revealed_hand() -> void:
    if phase != "REVEAL_CONFIRM":
        return
    if sun_reveal_owner < 0:
        public_hand_flags = [false, false]
    else:
        public_hand_flags[1 - current_player] = true
        public_hand_flags[current_player] = true
    var callback: Callable = reveal_confirm_callback
    reveal_confirm_callback = Callable()
    if callback.is_valid():
        callback.call()


func _resolve_death_effect() -> void:
    var count: int = hands[current_player].size()
    if count <= 0:
        _process_next_post_effect()
        return
    var death_cards: Array = hands[current_player].duplicate()
    for i in range(death_cards.size()):
        var card = death_cards[i]
        _animate_card_transfer(hand_panels[current_player], discard_pile_button, card, i, true, "데스")
        discard.append(card)
    hands[current_player].clear()
    _log("데스: 남은 손패 %d장을 모두 버렸다. 이 중간 0장 상태는 승리로 판정하지 않는다." % count)
    _request_draw(current_player, count, _process_next_post_effect)


func _resolve_hanged_pick(index: int) -> void:
    if phase != "HANGED_PICK" or index < 0 or index >= hands[current_player].size():
        return
    var card = hands[current_player].pop_at(index)
    _animate_card_transfer(hand_panels[current_player], discard_pile_button, card, 0, true, "행맨")
    discard.append(card)
    _log("행맨: %s을 묘지로 보냈다." % _card_name(card))
    if hands[current_player].is_empty():
        _end_game(current_player, "행맨 효과로 손패가 0장이 되어 즉시 승리했다.")
        return
    _process_next_post_effect()


func _resolve_moon_pick(discard_index: int) -> void:
    if phase != "MOON_PICK" or discard_index < 0 or discard_index >= discard.size():
        return
    var card = discard.pop_at(discard_index)
    _animate_card_transfer(discard_pile_button, hand_panels[current_player], card, 0, true, "문 회수")
    hands[current_player].append(card)
    _log("문: 묘지의 %s을 손패로 되돌렸다." % _card_name(card))
    _process_next_post_effect()


func _begin_star_exchange_after_reveal() -> void:
    if game_over:
        return
    phase = "STAR_PICK_SELF"
    star_self_id = ""
    status_label.text = "스타: 교환할 자신의 손패 1장을 선택한다."
    _refresh_ui()


func _resolve_star_exchange(opponent_index: int) -> void:
    if phase != "STAR_PICK_OPP" or opponent_index < 0 or opponent_index >= hands[1 - current_player].size():
        return
    var my_card: Variant = _remove_card_by_id(current_player, star_self_id)
    if my_card == null:
        _begin_star_exchange_after_reveal()
        return
    var other_card = hands[1 - current_player].pop_at(opponent_index)
    _animate_card_transfer(hand_panels[current_player], hand_panels[1 - current_player], my_card, 0, true, "스타")
    _animate_card_transfer(hand_panels[1 - current_player], hand_panels[current_player], other_card, 1, true, "스타")
    hands[current_player].append(other_card)
    hands[1 - current_player].append(my_card)
    _log("스타 교환: P%d의 %s ↔ P%d의 %s" % [current_player + 1, _card_name(my_card), (1 - current_player) + 1, _card_name(other_card)])
    star_self_id = ""
    _process_next_post_effect()


func _begin_sun_extra_after_reveal() -> void:
    if game_over:
        return
    phase = "SUN_EXTRA"
    status_label.text = "썬: 유효 공격 카드 1장을 추가로 낼 수 있다. 생략도 가능하다."
    _refresh_ui()


func _skip_sun_extra() -> void:
    if phase != "SUN_EXTRA":
        return
    _log("썬의 추가 사용권을 사용하지 않았다.")
    _process_next_post_effect()

func _find_court_completion_options(player: int, attack_card) -> Array:
    var options: Array = []
    var attack_id: String = str(attack_card["id"])
    var attack_suit: String = str(attack_card["suit"])
    var attack_rank: String = str(attack_card["court_rank"])

    var rank_ids: Array = []
    for suit in CardDatabase.SUITS:
        var card_id: String = "COURT_%s_%s" % [str(suit).to_upper(), attack_rank.to_upper()]
        if card_id != attack_id:
            rank_ids.append(card_id)
    if _hand_contains_ids(player, rank_ids):
        options.append({
            "kind": "RANK",
            "label": "직위 완성 — %s 4원소" % COURT_KO[attack_rank],
            "discard_ids": rank_ids
        })

    var suit_ids: Array = []
    for rank_data in CardDatabase.COURT_RANKS:
        var rank_name: String = str(rank_data["name"])
        var card_id: String = "COURT_%s_%s" % [attack_suit.to_upper(), rank_name.to_upper()]
        if card_id != attack_id:
            suit_ids.append(card_id)
    if _hand_contains_ids(player, suit_ids):
        options.append({
            "kind": "SUIT",
            "label": "원소 궁정 완성 — %s 궁정" % SUIT_KO[attack_suit],
            "discard_ids": suit_ids
        })

    return options


func _hand_contains_ids(player: int, ids: Array) -> bool:
    for needed_id in ids:
        if _is_card_locked_for_player(player, str(needed_id)):
            return false
        var found: bool = false
        for card in hands[player]:
            if str(card["id"]) == str(needed_id):
                found = true
                break
        if not found:
            return false
    return true

func _declare_court_completion(option_index: int) -> void:
    if phase != "COURT_COMPLETION":
        return
    if option_index < 0 or option_index >= court_completion_options.size():
        return

    var option: Dictionary = court_completion_options[option_index]
    var discard_ids: Array = option["discard_ids"]
    var removed_cards: Array = []

    for card_id in discard_ids:
        var removed = _remove_card_by_id(current_player, str(card_id))
        if removed != null:
            removed_cards.append(removed)

    for i in range(removed_cards.size()):
        var card = removed_cards[i]
        _animate_card_transfer(hand_panels[current_player], discard_pile_button, card, i, true, "궁정 완성")
        discard.append(card)

    _log("P%d 궁정 완성 선언: %s" % [current_player + 1, str(option["label"])])
    _log("완성 구성 카드 3장을 묘지로 보냈다.")
    court_completion_options.clear()

    if hands[current_player].is_empty():
        _end_game(current_player, "P%d가 궁정 완성으로 손패가 0장이 되어 즉시 승리했다." % (current_player + 1))
        return

    court_scan_index += 1
    _advance_court_completion()


func _skip_court_completion() -> void:
    if phase != "COURT_COMPLETION":
        return
    var card_name: String = _card_name(attack_package[court_scan_index]["card"])
    _log("P%d가 %s의 궁정 완성을 선언하지 않았다." % [current_player + 1, card_name])
    court_completion_options.clear()
    court_scan_index += 1
    _advance_court_completion()


func _begin_defense() -> void:
    var has_attack_output: bool = false
    for i in range(attack_package.size()):
        if _calculate_entry_draw(attack_package[i], null) > 0:
            has_attack_output = true
            break
    if not has_attack_output:
        _log("방어자가 대응할 공격 정산이 없어 방어 단계를 생략한다.")
        _cleanup_and_pass_turn()
        return

    var defender: int = 1 - current_player
    phase = "DEFENSE"
    defense_draft.clear()
    defense_atu_choices.clear()
    selected_defense_target = _first_normal_attack_target_index()

    if bool(defense_blocked[defender]):
        _log("허미트: P%d는 이번 턴 방어권이 없어 공격 패키지를 무방어로 받는다." % (defender + 1))
        status_label.text = "P%d는 허미트 효과로 이번 턴 방어할 수 없다." % (defender + 1)
        _confirm_defense_package()
        return

    status_label.text = "P%d의 방어 차례. 일반 방어와 방어 아투를 구성한 뒤 한 번에 제출한다." % (defender + 1)
    _refresh_ui()

func _is_normal_attack_card(card) -> bool:
    if card == null:
        return false
    return str(card.get("type", "")) in ["SMALL", "ACE", "COURT"]


func _first_normal_attack_target_index() -> int:
    for i in range(attack_package.size()):
        if _is_normal_attack_card(attack_package[i].get("card", null)):
            return i
    return 0


func _select_defense_target(index: int) -> void:
    if phase != "DEFENSE":
        return
    if index < 0 or index >= attack_package.size():
        return
    if not _is_normal_attack_card(attack_package[index].get("card", null)):
        return
    selected_defense_target = index
    status_label.text = "방어 대상: %s" % _card_name(attack_package[index]["card"])
    _refresh_ui()


func _clear_target_defense(index: int) -> void:
    if phase != "DEFENSE":
        return
    defense_draft.erase(index)
    _recompute_defense_atu_choices()
    _refresh_ui()


func _defense_card_used_elsewhere(card_id: String, target_index: int) -> bool:
    for key in defense_draft.keys():
        var slot: int = int(key)
        if slot != target_index and str(defense_draft[key]) == card_id:
            return true
    return false


func _toggle_defense_atu(card) -> void:
    var card_id: String = str(card["id"])
    for i in range(defense_atu_choices.size()):
        if str(defense_atu_choices[i]["card_id"]) == card_id:
            defense_atu_choices.remove_at(i)
            _recompute_defense_atu_choices()
            status_label.text = "%s 방어 아투 선택을 취소했다." % _card_name(card)
            _refresh_ui()
            return

    if not _can_add_defense_atu(card):
        status_label.text = "%s은 현재 막을 수 있는 유효 공격이 없어 사용할 수 없다." % _card_name(card)
        return

    defense_atu_choices.append({
        "card_id": card_id,
        "effect_id": str(card.get("effect_id", "")),
        "target_hint": selected_defense_target,
        "targets": []
    })
    _recompute_defense_atu_choices()
    status_label.text = "%s을 방어 패키지에 추가했다." % _card_name(card)
    _refresh_ui()


func _clear_defense_atu() -> void:
    if phase != "DEFENSE":
        return
    defense_atu_choices.clear()
    status_label.text = "방어 아투 선택을 모두 취소했다."
    _refresh_ui()


func _recompute_defense_atu_choices() -> void:
    var old_choices: Array = defense_atu_choices.duplicate(true)
    defense_atu_choices.clear()
    var nullified: Dictionary = {}
    var lovers_selected: bool = false

    for old_choice in old_choices:
        var card_id: String = str(old_choice.get("card_id", ""))
        var card = _find_card_in_hand_by_id(1 - current_player, card_id)
        if card == null:
            continue

        var effect_id: String = str(old_choice.get("effect_id", ""))
        var target_hint: int = int(old_choice.get("target_hint", 0))

        if effect_id == "LOVERS":
            if lovers_selected:
                continue
            if _preview_reducible_draw_after_nullifiers(nullified) <= 0:
                continue
            lovers_selected = true
            defense_atu_choices.append({
                "card_id": card_id,
                "effect_id": effect_id,
                "target_hint": target_hint,
                "targets": []
            })
            continue

        var targets: Array = _targets_for_nullifier(effect_id, target_hint, nullified)
        if targets.is_empty():
            continue

        defense_atu_choices.append({
            "card_id": card_id,
            "effect_id": effect_id,
            "target_hint": target_hint,
            "targets": targets
        })
        for target in targets:
            nullified[int(target)] = true


func _can_add_defense_atu(card) -> bool:
    var defender: int = 1 - current_player
    if bool(defense_blocked[defender]):
        return false
    if str(card.get("type", "")) != "ATU":
        return false
    var effect_id: String = str(card.get("effect_id", ""))
    if not (effect_id in DEFENSE_ATU_EFFECTS):
        return false

    var card_id: String = str(card["id"])
    if _is_card_locked_for_player(defender, card_id):
        return false
    for choice in defense_atu_choices:
        if str(choice["card_id"]) == card_id:
            return true

    var nullified: Dictionary = _current_preview_nullified_set()
    if effect_id == "LOVERS":
        for choice in defense_atu_choices:
            if str(choice["effect_id"]) == "LOVERS":
                return false
        return _preview_reducible_draw_after_nullifiers(nullified) > 0

    if _nullifier_conflicts_with_general_defense(effect_id, selected_defense_target):
        return false

    var targets: Array = _targets_for_nullifier(effect_id, selected_defense_target, nullified)
    return not targets.is_empty()

func _target_is_covered_by_selected_nullifier(target_index: int) -> bool:
    for choice in defense_atu_choices:
        if not (str(choice.get("effect_id", "")) in NULLIFY_ATU_EFFECTS):
            continue
        for target in choice.get("targets", []):
            if int(target) == target_index:
                return true
    return false


func _natural_targets_for_nullifier(effect_id: String, target_hint: int) -> Array:
    var targets: Array = []

    if effect_id == "EMPRESS" or effect_id == "EMPEROR":
        if target_hint < 0 or target_hint >= attack_package.size():
            return targets
        if bool(attack_package[target_hint].get("cannot_be_nullified", false)):
            return targets
        var attack_card = attack_package[target_hint]["card"]
        var family: String = CardDatabase.physical_or_magical(attack_card)
        if effect_id == "EMPRESS" and family == "MAGICAL":
            targets.append(target_hint)
        elif effect_id == "EMPEROR" and family == "PHYSICAL":
            targets.append(target_hint)
        return targets

    for i in range(attack_package.size()):
        if bool(attack_package[i].get("cannot_be_nullified", false)):
            continue
        var attack_card = attack_package[i]["card"]
        var card_type: String = str(attack_card.get("type", ""))
        var family: String = CardDatabase.physical_or_magical(attack_card)

        match effect_id:
            "FOOL":
                targets.append(i)
            "PRIESTESS":
                if family == "MAGICAL":
                    targets.append(i)
            "LUST":
                if family == "PHYSICAL":
                    targets.append(i)
            "CHARIOT":
                if card_type == "SMALL" or card_type == "COURT":
                    targets.append(i)

    return targets

func _nullifier_conflicts_with_general_defense(effect_id: String, target_hint: int) -> bool:
    if not (effect_id in NULLIFY_ATU_EFFECTS):
        return false
    for target in _natural_targets_for_nullifier(effect_id, target_hint):
        if defense_draft.has(int(target)):
            return true
    return false


func _current_preview_nullified_set() -> Dictionary:
    var result: Dictionary = {}
    for choice in defense_atu_choices:
        if str(choice.get("effect_id", "")) in NULLIFY_ATU_EFFECTS:
            for target in choice.get("targets", []):
                result[int(target)] = true
    return result


func _targets_for_nullifier(effect_id: String, target_hint: int, already_nullified: Dictionary) -> Array:
    var targets: Array = []

    if effect_id == "EMPRESS" or effect_id == "EMPEROR":
        if target_hint < 0 or target_hint >= attack_package.size():
            return targets
        if already_nullified.has(target_hint) or bool(attack_package[target_hint].get("cannot_be_nullified", false)):
            return targets
        if _preview_entry_draw(target_hint) <= 0:
            return targets
        var family: String = CardDatabase.physical_or_magical(attack_package[target_hint]["card"])
        if effect_id == "EMPRESS" and family == "MAGICAL":
            targets.append(target_hint)
        elif effect_id == "EMPEROR" and family == "PHYSICAL":
            targets.append(target_hint)
        return targets

    for i in range(attack_package.size()):
        if already_nullified.has(i) or bool(attack_package[i].get("cannot_be_nullified", false)):
            continue
        if _preview_entry_draw(i) <= 0:
            continue

        var attack_card = attack_package[i]["card"]
        var card_type: String = str(attack_card.get("type", ""))
        var family: String = CardDatabase.physical_or_magical(attack_card)

        match effect_id:
            "FOOL":
                targets.append(i)
            "PRIESTESS":
                if family == "MAGICAL":
                    targets.append(i)
            "LUST":
                if family == "PHYSICAL":
                    targets.append(i)
            "CHARIOT":
                if card_type == "SMALL" or card_type == "COURT":
                    targets.append(i)

    return targets

func _preview_entry_draw(index: int) -> int:
    if index < 0 or index >= attack_package.size():
        return 0
    var entry: Dictionary = attack_package[index]
    var defense_card = null
    if defense_draft.has(index):
        defense_card = _find_card_in_hand_by_id(1 - current_player, str(defense_draft[index]))
    return _calculate_entry_draw(entry, defense_card)


func _preview_total_draw_after_nullifiers(nullified: Dictionary) -> int:
    var total: int = 0
    for i in range(attack_package.size()):
        if nullified.has(i):
            continue
        total += _preview_entry_draw(i)
    return total


func _preview_reducible_draw_after_nullifiers(nullified: Dictionary) -> int:
    var total: int = 0
    for i in range(attack_package.size()):
        if nullified.has(i) or bool(attack_package[i].get("lovers_protected", false)):
            continue
        total += _preview_entry_draw(i)
    return total


func _confirm_defense_package() -> void:
    if phase != "DEFENSE":
        return

    var defender: int = 1 - current_player

    # 일반 방어 제출
    for slot_key in defense_draft.keys():
        var slot: int = int(slot_key)
        var card_id: String = str(defense_draft[slot_key])
        var defense_card = _remove_card_by_id(defender, card_id)
        if defense_card != null:
            _animate_card_transfer(hand_panels[defender], battlefield_box, defense_card, slot, true, "방어")
            attack_package[slot]["defense"] = defense_card
            _log("P%d 일반 방어: %s → %s" % [defender + 1, _card_name(defense_card), _card_name(attack_package[slot]["card"])])
            # 동일 방어 펜타클은 정산 결과가 아니라 방어 제출 자체로 성립한다.
            # 따라서 마지막 손패 방어로 즉시 승리하더라도 이 시점에 먼저 처리한다.
            _apply_matching_defense_pentacle(attack_package[slot])

    # 방어 아투 제출. targets는 제출 시점의 적용 대상을 그대로 고정한다.
    defense_atu_used.clear()
    for choice in defense_atu_choices:
        var atu_card = _remove_card_by_id(defender, str(choice["card_id"]))
        if atu_card != null:
            _animate_card_transfer(hand_panels[defender], battlefield_box, atu_card, defense_atu_used.size(), true, "아투 방어")
            defense_atu_used.append({
                "card": atu_card,
                "effect_id": str(choice["effect_id"]),
                "targets": choice["targets"].duplicate(),
                "cancelled": false
            })
            _log("P%d 방어 아투 제출: %s" % [defender + 1, _card_name(atu_card)])

    if defense_draft.is_empty() and defense_atu_used.is_empty():
        _log("P%d가 방어하지 않았다." % (defender + 1))

    defense_draft.clear()
    defense_atu_choices.clear()

    # 방어 패키지 제출 직후 손패 0장이면 정산보다 먼저 승리한다.
    if hands[defender].is_empty():
        _end_game(defender, "P%d가 방어 패키지를 제출하여 손패가 0장이 되었다." % (defender + 1))
        return

    # 상대가 무엇으로 막았는지 확인할 시간을 둔 뒤 정산으로 넘어간다.
    phase = "DEFENSE_REVEAL"
    status_label.text = "P%d의 방어 패키지가 제출되었다. 중앙 전장에서 대응 관계를 확인한다." % (defender + 1)
    _refresh_ui()
    _auto_continue_defense_reveal()


func _auto_continue_defense_reveal() -> void:
    await get_tree().create_timer(1.5).timeout
    if phase == "DEFENSE_REVEAL" and not game_over:
        _continue_after_defense_reveal()


func _continue_after_defense_reveal() -> void:
    if phase != "DEFENSE_REVEAL" or game_over:
        return
    if _has_uncancelled_nullifier() and _find_adjustment_in_hand(current_player) != null:
        phase = "ADJUSTMENT_RESPONSE"
        status_label.text = "P%d는 어저스트먼트 선택지 2로 무효 아투 하나를 취소할 수 있다." % (current_player + 1)
        _refresh_ui()
        return
    _resolve_attack_package()


func _has_uncancelled_nullifier() -> bool:
    for used in defense_atu_used:
        if str(used.get("effect_id", "")) in NULLIFY_ATU_EFFECTS and not bool(used.get("cancelled", false)):
            return true
    return false


func _find_adjustment_in_hand(player: int) -> Variant:
    for card in hands[player]:
        if str(card.get("effect_id", "")) == "ADJUSTMENT" and not _is_card_locked_for_player(player, str(card.get("id", ""))):
            return card
    return null

func _use_adjustment_response(nullifier_index: int) -> void:
    if phase != "ADJUSTMENT_RESPONSE":
        return
    if nullifier_index < 0 or nullifier_index >= defense_atu_used.size():
        return
    var target: Dictionary = defense_atu_used[nullifier_index]
    if not (str(target.get("effect_id", "")) in NULLIFY_ATU_EFFECTS):
        return
    if bool(target.get("cancelled", false)):
        return

    var adjustment: Variant = _find_adjustment_in_hand(current_player)
    if adjustment == null:
        _resolve_attack_package()
        return

    var removed: Variant = _remove_card_by_id(current_player, str(adjustment["id"]))
    if removed != null:
        reaction_cards.append(removed)
        defense_atu_used[nullifier_index]["cancelled"] = true
        _log("P%d 어저스트먼트 선택지 2: %s의 무효 효과를 취소했다." % [current_player + 1, _card_name(target["card"])])

    if hands[current_player].is_empty():
        _end_game(current_player, "P%d가 어저스트먼트 반응을 사용하여 손패가 0장이 되었다." % (current_player + 1))
        return

    _resolve_attack_package()


func _skip_adjustment_response() -> void:
    if phase != "ADJUSTMENT_RESPONSE":
        return
    _log("P%d가 어저스트먼트 반응을 사용하지 않았다." % (current_player + 1))
    _resolve_attack_package()


func _resolve_attack_package() -> void:
    var defender: int = 1 - current_player
    var reducible_draw: int = 0
    var universe_draw: int = 0
    var final_nullified: Dictionary = {}

    for used in defense_atu_used:
        if bool(used.get("cancelled", false)):
            continue
        var effect_id: String = str(used.get("effect_id", ""))
        if effect_id in NULLIFY_ATU_EFFECTS:
            for target in used.get("targets", []):
                final_nullified[int(target)] = true

    for i in range(attack_package.size()):
        var entry: Dictionary = attack_package[i]
        var raw_draw: int = _calculate_entry_draw(entry, entry["defense"])
        var draw_count: int = 0 if final_nullified.has(i) else raw_draw

        if i == art_target_index and draw_count > 0:
            var before_art: int = draw_count
            draw_count *= 2
            _log("아트: %s의 남은 드로우 %d장 → %d장" % [_card_name(entry["card"]), before_art, draw_count])

        attack_package[i]["nullified"] = final_nullified.has(i)
        attack_package[i]["resolved_draw"] = draw_count

        if bool(entry.get("lovers_protected", false)):
            universe_draw += draw_count
        else:
            reducible_draw += draw_count

        if final_nullified.has(i):
            _log("정산: %s → 방어 아투로 무효" % _card_name(entry["card"]))
        elif entry["defense"] == null:
            _log("정산: %s 무방어 → %d장" % [_card_name(entry["card"]), draw_count])
        else:
            _log("정산: %s vs %s → %d장" % [_card_name(entry["card"]), _card_name(entry["defense"]), draw_count])

    if _lovers_was_used() and reducible_draw > 0:
        var before_lovers: int = reducible_draw
        reducible_draw = ceili(float(reducible_draw) / 2.0)
        _log("러버즈: 유니버스 외 드로우 %d장 → %d장" % [before_lovers, reducible_draw])

    var total_draw: int = reducible_draw + universe_draw
    if universe_draw > 0:
        _log("유니버스 보호 드로우: %d장 (러버즈 감소 불가)" % universe_draw)

    if total_draw > 0:
        _log("최종 정산: P%d가 총 %d장 드로우한다." % [defender + 1, total_draw])
        _request_draw(defender, total_draw, _show_resolution_review)
    else:
        _log("최종 정산: 드로우 없음.")
        _show_resolution_review()

func _show_resolution_review() -> void:
    if game_over:
        return
    phase = "RESOLUTION_REVIEW"
    status_label.text = "정산이 완료되었다."
    _refresh_ui()
    _auto_continue_resolution_review()


func _auto_continue_resolution_review() -> void:
    await get_tree().create_timer(3.0).timeout
    if phase == "RESOLUTION_REVIEW" and not game_over:
        _continue_after_resolution_review()


func _continue_after_resolution_review() -> void:
    if phase != "RESOLUTION_REVIEW" or game_over:
        return
    _cleanup_and_pass_turn()


func _apply_matching_defense_pentacle(entry: Dictionary) -> void:
    var attacker = entry.get("card", null)
    var defender = entry.get("defense", null)
    if attacker == null or defender == null:
        return

    var attack_type: String = str(attacker.get("type", ""))
    var defense_type: String = str(defender.get("type", ""))
    var matched: bool = false
    var reason: String = "동일 방어"

    if attack_type == "SMALL" and defense_type == "SMALL":
        matched = int(attacker.get("number", -1)) == int(defender.get("number", -2))
        reason = "동일 숫자 스몰 방어"
    elif attack_type == "ACE" and defense_type == "ACE":
        matched = true
        reason = "에이스 대 에이스 방어"
    elif attack_type == "COURT" and defense_type == "COURT":
        matched = str(attacker.get("court_rank", "")) == str(defender.get("court_rank", ""))
        reason = "동일 직위 코트 방어"

    if matched:
        _contribute_pentacles(current_player, 1, reason)


func _lovers_was_used() -> bool:
    for used in defense_atu_used:
        if str(used.get("effect_id", "")) == "LOVERS":
            return true
    return false


func _calculate_entry_draw(entry: Dictionary, defender) -> int:
    var attacker = entry.get("card", null)
    if attacker == null:
        return 0

    var attack_type: String = str(attacker.get("type", ""))

    if attack_type == "ATU":
        return int(entry.get("direct_draw", 0))

    if attack_type == "SMALL":
        var attack_value: int = int(attacker.get("number", 0))
        if defender == null:
            return attack_value

        var defense_type: String = str(defender.get("type", ""))
        if defense_type == "ACE":
            return maxi(attack_value - 1, 0)
        if defense_type == "SMALL":
            var defense_value: int = int(defender.get("number", 0))
            return maxi(attack_value - defense_value, 0)
        return attack_value

    if attack_type == "ACE":
        if defender == null:
            return int(attacker.get("hit_draw", 7))
        return 0

    if attack_type == "COURT":
        var court_attack: int = int(attacker.get("value", 0))
        if defender == null:
            return court_attack
        var court_defense: int = int(defender.get("value", 0))
        return maxi(court_attack - court_defense, 0)

    return 0


func _cleanup_and_pass_turn() -> void:
    if game_over:
        return
    var cleanup_sequence: int = 0
    for entry in attack_package:
        if entry["card"] != null:
            var used_card = entry["card"]
            if str(used_card.get("effect_id", "")) == "AEON" and recycle_count >= 1 and not aeon_reinserted and not _excluded_contains_aeon():
                _animate_card_transfer(battlefield_box, aeon_status_label, used_card, cleanup_sequence, true, "제외")
                excluded.append(used_card)
                _log("제1 에온 종료 당시 사용 영역에 있던 에온을 해결 후 게임에서 제외했다.")
            else:
                _animate_card_transfer(battlefield_box, discard_pile_button, used_card, cleanup_sequence, true, "묘지")
                discard.append(used_card)
            cleanup_sequence += 1
        if entry["defense"] != null:
            _animate_card_transfer(battlefield_box, discard_pile_button, entry["defense"], cleanup_sequence, true, "묘지")
            discard.append(entry["defense"])
            cleanup_sequence += 1

    for card in used_attack_misc:
        _animate_card_transfer(battlefield_box, discard_pile_button, card, cleanup_sequence, true, "묘지")
        discard.append(card)
        cleanup_sequence += 1

    for used in defense_atu_used:
        if used.get("card", null) != null:
            _animate_card_transfer(battlefield_box, discard_pile_button, used["card"], cleanup_sequence, true, "묘지")
            discard.append(used["card"])
            cleanup_sequence += 1

    for card in reaction_cards:
        _animate_card_transfer(battlefield_box, discard_pile_button, card, cleanup_sequence, true, "묘지")
        discard.append(card)
        cleanup_sequence += 1

    attack_package.clear()
    used_attack_misc.clear()
    post_effect_queue.clear()
    defense_draft.clear()
    defense_atu_choices.clear()
    defense_atu_used.clear()
    reaction_cards.clear()
    court_completion_options.clear()
    art_target_index = -1
    selected_defense_target = 0
    court_scan_index = 0
    _reset_attack_draft()

    var finished_player: int = current_player
    _finish_turn(finished_player)

func _draw_and_end_turn() -> void:
    if phase != "ACTION" or game_over:
        return
    var player: int = current_player
    selected_attack_index = -1
    _log("P%d가 공격 대신 1장 드로우했다." % (player + 1))
    _request_draw(player, 1, _finish_action_draw.bind(player))

func _can_start_attack_with(player: int, card) -> bool:
    if card == null:
        return false
    var card_id: String = str(card.get("id", ""))
    if _is_card_locked_for_player(player, card_id):
        return false

    var card_type: String = str(card.get("type", ""))
    if card_type == "SMALL":
        return str(card.get("suit", "")) in ATTACK_SMALL_SUITS
    if card_type == "ACE" or card_type == "COURT":
        return true
    if card_type != "ATU":
        return false

    var effect_id: String = str(card.get("effect_id", ""))
    if effect_id == "ART" or not (effect_id in ATTACK_ATU_EFFECTS):
        return false
    if effect_id == "MOON" and discard.is_empty():
        return false
    if effect_id == "HIEROPHANT":
        return _has_condition_family_count(player, "ANY", 1, card_id)
    if effect_id == "DEVIL":
        return _has_condition_family_count(player, "ACE", 2, card_id) or _has_condition_family_count(player, "KNIGHT", 2, card_id)
    if effect_id == "UNIVERSE":
        return _has_condition_family_count(player, "ACE", 3, card_id) or _has_condition_family_count(player, "KNIGHT", 3, card_id)
    if effect_id == "MAGUS":
        return _count_extra_candidates(player, "MAGICAL", card_id) >= 2
    if effect_id == "EMPRESS":
        return _count_extra_candidates(player, "MAGICAL", card_id) >= 1
    if effect_id == "EMPEROR":
        return _count_extra_candidates(player, "PHYSICAL", card_id) >= 1
    if effect_id == "TOWER":
        return _count_extra_candidates(player, "PHYSICAL", card_id) >= 2
    if effect_id == "AEON":
        return _count_extra_candidates(player, "PHYSICAL", card_id) >= 1 and _count_extra_candidates(player, "MAGICAL", card_id) >= 1
    return true

func _count_extra_candidates(player: int, family: String, excluded_id: String = "") -> int:
    var count: int = 0
    for card in hands[player]:
        if str(card.get("id", "")) == excluded_id:
            continue
        if _is_elemental_attack_card(card) and CardDatabase.physical_or_magical(card) == family and not _is_card_locked_for_player(player, str(card.get("id", ""))):
            count += 1
    return count

func _count_hierophant_condition_cards(player: int) -> int:
    var count: int = 0
    for card in hands[player]:
        if _card_matches_condition_family(card, "ANY"):
            count += 1
    return count

func _is_hierophant_condition_card(card) -> bool:
    return _card_matches_condition_family(card, "ANY")

func _is_elemental_attack_card(card) -> bool:
    if card == null:
        return false
    var card_type: String = str(card.get("type", ""))
    if card_type == "SMALL":
        return str(card.get("suit", "")) in ATTACK_SMALL_SUITS
    return card_type == "ACE" or card_type == "COURT"


func _required_extra_count(effect_id: String) -> int:
    match effect_id:
        "MAGUS": return 2
        "EMPRESS": return 1
        "EMPEROR": return 1
        "TOWER": return 2
        "AEON": return 2
        _: return 0

func _is_eligible_extra_for_effect(effect_id: String, card) -> bool:
    if not _is_elemental_attack_card(card):
        return false
    var family: String = CardDatabase.physical_or_magical(card)
    match effect_id:
        "MAGUS", "EMPRESS": return family == "MAGICAL"
        "EMPEROR", "TOWER": return family == "PHYSICAL"
        "AEON": return family == "PHYSICAL" or family == "MAGICAL"
        _: return false

func _attack_build_instruction(base_card) -> String:
    return _attack_build_status()

func _can_defend(attacker, defender) -> bool:
    if attacker == null or defender == null:
        return false

    var attack_type: String = str(attacker.get("type", ""))
    var defense_type: String = str(defender.get("type", ""))

    if attack_type == "ATU":
        return false

    if attack_type == "COURT":
        return defense_type == "COURT"

    if attack_type == "ACE":
        if defense_type == "ACE":
            return true
        if defense_type != "SMALL":
            return false
        return _is_corresponding_ace_small(attacker, defender)

    if attack_type == "SMALL":
        if defense_type == "ACE":
            return _is_corresponding_small_ace(attacker, defender)
        if defense_type != "SMALL":
            return false

        var attack_number: int = int(attacker.get("number", 0))
        var defense_number: int = int(defender.get("number", 0))
        if attack_number == defense_number:
            return true

        var attack_suit: String = str(attacker.get("suit", ""))
        var defense_suit: String = str(defender.get("suit", ""))
        if attack_suit == "Swords" and defense_suit == "Disks":
            return true
        if attack_suit == "Wands" and defense_suit == "Cups":
            return true

    return false


func _is_corresponding_small_ace(small_card, ace_card) -> bool:
    var small_suit: String = str(small_card.get("suit", ""))
    var ace_suit: String = str(ace_card.get("suit", ""))
    match small_suit:
        "Swords": return ace_suit == "Disks"
        "Wands": return ace_suit == "Cups"
        _: return false


func _is_corresponding_ace_small(ace_card, small_card) -> bool:
    var ace_suit: String = str(ace_card.get("suit", ""))
    var small_suit: String = str(small_card.get("suit", ""))
    match ace_suit:
        "Swords": return small_suit == "Disks"
        "Disks": return small_suit == "Swords"
        "Wands": return small_suit == "Cups"
        "Cups": return small_suit == "Wands"
        _: return false


func _remove_card_by_id(player: int, card_id: String) -> Variant:
    for i in range(hands[player].size()):
        if str(hands[player][i]["id"]) == card_id:
            return hands[player].pop_at(i)
    return null


func _find_card_in_hand_by_id(player: int, card_id: String) -> Variant:
    for card in hands[player]:
        if str(card["id"]) == card_id:
            return card
    return null


func _suit_color(suit: String) -> Color:
    match suit:
        "Wands": return Color(0.48, 0.20, 0.14, 1.0)
        "Cups": return Color(0.13, 0.31, 0.50, 1.0)
        "Swords": return Color(0.30, 0.27, 0.50, 1.0)
        "Disks": return Color(0.27, 0.40, 0.20, 1.0)
        _: return Color(0.22, 0.23, 0.28, 1.0)


func _atu_color() -> Color:
    return Color(0.30, 0.20, 0.38, 1.0)


func _card_base_color(card) -> Color:
    if card == null:
        return Color(0.22, 0.23, 0.28, 1.0)
    if str(card.get("type", "")) == "ATU":
        return _atu_color()
    return _suit_color(str(card.get("suit", "")))


func _make_box_style(bg: Color, border: Color, width: int = 1, radius: int = 6, tight: bool = false) -> StyleBoxFlat:
    var style := StyleBoxFlat.new()
    style.bg_color = bg
    style.border_color = border
    style.set_border_width_all(width)
    style.corner_radius_top_left = radius
    style.corner_radius_top_right = radius
    style.corner_radius_bottom_left = radius
    style.corner_radius_bottom_right = radius
    var margin_h: float = 1.0 if tight else 9.0
    var margin_v: float = 1.0 if tight else 7.0
    style.content_margin_left = margin_h
    style.content_margin_right = margin_h
    style.content_margin_top = margin_v
    style.content_margin_bottom = margin_v
    return style


func _apply_card_button_style(button: Button, card, state: String) -> void:
    var base: Color = _card_base_color(card)
    var bg: Color = base
    var border: Color = base.lightened(0.34)
    var border_width: int = 1
    var alpha: float = 1.0

    match state:
        "playable":
            border = Color(0.72, 0.88, 1.0, 1.0)
            border_width = 2
        "selected":
            border = Color(1.0, 0.79, 0.30, 1.0)
            border_width = 3
            bg = base.lightened(0.08)
        "submitted":
            border = Color(0.38, 0.94, 0.66, 1.0)
            border_width = 3
            bg = base.lightened(0.05)
        "locked":
            border = Color(0.90, 0.38, 0.38, 1.0)
            border_width = 2
            bg = base.darkened(0.22)
            alpha = 0.76
        "unavailable":
            border = Color(0.36, 0.37, 0.42, 1.0)
            bg = base.darkened(0.34)
            alpha = 0.58
        _:
            pass

    button.modulate = Color(1.0, 1.0, 1.0, alpha)
    button.add_theme_color_override("font_color", Color(0.97, 0.97, 0.98, 1.0))
    button.add_theme_color_override("font_hover_color", Color.WHITE)
    button.add_theme_color_override("font_pressed_color", Color.WHITE)
    button.add_theme_color_override("font_disabled_color", Color(0.72, 0.73, 0.77, 1.0))
    button.add_theme_stylebox_override("normal", _make_box_style(bg, border, border_width, 7, true))
    button.add_theme_stylebox_override("hover", _make_box_style(bg.lightened(0.10), border.lightened(0.08), maxi(border_width, 2), 7, true))
    button.add_theme_stylebox_override("pressed", _make_box_style(bg.darkened(0.08), border, maxi(border_width, 2), 7, true))
    button.add_theme_stylebox_override("disabled", _make_box_style(bg.darkened(0.14), border.darkened(0.18), 1, 7, true))


func _apply_deck_card_style(button: Button, kind: String = "neutral") -> void:
    var bg := Color(0.055, 0.06, 0.075, 1.0)
    var border := Color(0.64, 0.48, 0.12, 1.0)
    var width := 1
    if kind == "primary":
        border = Color(0.40, 0.74, 1.0, 1.0)
        width = 2
    elif kind == "draw":
        border = Color(0.68, 0.70, 0.78, 1.0)
        width = 2
    button.add_theme_stylebox_override("normal", _make_box_style(bg, border, width, 4, true))
    button.add_theme_stylebox_override("hover", _make_box_style(bg.lightened(0.06), border.lightened(0.08), maxi(width, 2), 4, true))
    button.add_theme_stylebox_override("pressed", _make_box_style(bg.darkened(0.05), border, maxi(width, 2), 4, true))
    button.add_theme_stylebox_override("disabled", _make_box_style(bg.darkened(0.10), border.darkened(0.18), 1, 4, true))


func _apply_action_button_style(button: Button, kind: String = "secondary") -> void:
    var bg := Color(0.18, 0.20, 0.25, 1.0)
    var border := Color(0.40, 0.43, 0.50, 1.0)
    match kind:
        "primary":
            bg = Color(0.16, 0.34, 0.50, 1.0)
            border = Color(0.40, 0.74, 1.0, 1.0)
        "confirm":
            bg = Color(0.16, 0.38, 0.28, 1.0)
            border = Color(0.38, 0.90, 0.62, 1.0)
        "selected":
            bg = Color(0.40, 0.31, 0.12, 1.0)
            border = Color(1.0, 0.78, 0.26, 1.0)
        "danger":
            bg = Color(0.40, 0.18, 0.18, 1.0)
            border = Color(0.92, 0.42, 0.42, 1.0)
        "draw":
            bg = Color(0.23, 0.24, 0.28, 1.0)
            border = Color(0.56, 0.58, 0.64, 1.0)
    button.add_theme_color_override("font_color", Color(0.98, 0.98, 0.99, 1.0))
    button.add_theme_color_override("font_hover_color", Color.WHITE)
    button.add_theme_stylebox_override("normal", _make_box_style(bg, border, 2, 7))
    button.add_theme_stylebox_override("hover", _make_box_style(bg.lightened(0.09), border.lightened(0.08), 2, 7))
    button.add_theme_stylebox_override("pressed", _make_box_style(bg.darkened(0.08), border, 2, 7))
    button.add_theme_stylebox_override("disabled", _make_box_style(bg.darkened(0.20), border.darkened(0.24), 1, 7))


func _apply_hand_panel_style(panel: PanelContainer, active: bool) -> void:
    var bg := Color(0.085, 0.09, 0.115, 0.96)
    var border := Color(0.24, 0.25, 0.31, 1.0)
    var width := 1
    if active:
        border = Color(0.50, 0.72, 0.95, 1.0)
        width = 2
    panel.add_theme_stylebox_override("panel", _make_box_style(bg, border, width, 7))


func _card_type_tag(card) -> String:
    if card == null:
        return "[카드]"
    var card_type: String = str(card.get("type", ""))
    if card_type == "ATU":
        return "[아투 %02d]" % int(card.get("atu_number", 0))
    var suit_name: String = str(SUIT_KO.get(str(card.get("suit", "")), ""))
    match card_type:
        "SMALL": return "[%s · 스몰]" % suit_name
        "ACE": return "[%s · 에이스]" % suit_name
        "COURT": return "[%s · 코트]" % suit_name
        _: return "[카드]"


func _card_button_text(card) -> String:
    return "%s\n%s" % [_card_type_tag(card), _card_name(card)]


func _add_legend_chip(parent: HBoxContainer, text: String, base: Color) -> void:
    var chip := Button.new()
    chip.text = text
    chip.disabled = true
    chip.focus_mode = Control.FOCUS_NONE
    chip.mouse_filter = Control.MOUSE_FILTER_IGNORE
    chip.add_theme_color_override("font_disabled_color", Color(0.94, 0.94, 0.96, 1.0))
    chip.add_theme_stylebox_override("disabled", _make_box_style(base.darkened(0.08), base.lightened(0.30), 1, 5))
    parent.add_child(chip)


func _add_state_legend_chip(parent: HBoxContainer, text: String, state: String) -> void:
    var chip := Button.new()
    chip.text = text
    chip.disabled = true
    chip.focus_mode = Control.FOCUS_NONE
    chip.mouse_filter = Control.MOUSE_FILTER_IGNORE
    var sample := {"type": "SMALL", "suit": "Swords"}
    _apply_card_button_style(chip, sample, state)
    chip.modulate = Color(1.0, 1.0, 1.0, 1.0)
    chip.add_theme_color_override("font_disabled_color", Color(0.94, 0.94, 0.96, 1.0))
    parent.add_child(chip)


func _card_name(card) -> String:
    if card == null:
        return "없음"

    var card_type: String = str(card.get("type", ""))
    var suit: String = str(card.get("suit", ""))

    match card_type:
        "SMALL":
            return "%s %d" % [SUIT_KO[suit], int(card.get("number", 0))]
        "ACE":
            return "%s 에이스" % SUIT_KO[suit]
        "COURT":
            return "%s %s" % [SUIT_KO[suit], COURT_KO[str(card.get("court_rank", "Princess"))]]
        "ATU":
            return str(card.get("name", "아투"))
        _:
            return str(card.get("id", "카드"))


func _card_rules_text(card) -> String:
    if card == null:
        return ""
    var card_type: String = str(card.get("type", ""))
    match card_type:
        "ATU":
            var description: String = CardDatabase.atu_description(str(card.get("effect_id", "")))
            if str(card.get("effect_id", "")) == "MOON":
                description += " 묘지가 비어 있으면 사용할 수 없다."
            return description
        "SMALL":
            var suit: String = str(card.get("suit", ""))
            if suit == "Swords":
                return "물리공격 스몰카드. 숫자 %d만큼 드로우를 발생시키며 디스크로 방어한다. 같은 숫자 스몰은 원소와 무관하게 방어 가능하다." % int(card.get("number", 0))
            if suit == "Wands":
                return "마법공격 스몰카드. 숫자 %d만큼 드로우를 발생시키며 컵으로 방어한다. 같은 숫자 스몰은 원소와 무관하게 방어 가능하다." % int(card.get("number", 0))
            if suit == "Disks":
                return "물리방어 스몰카드. 소드 공격을 방어하며 방어값은 %d이다. 같은 숫자 스몰 공격도 원소와 무관하게 방어 가능하다." % int(card.get("number", 0))
            return "마법방어 스몰카드. 완드 공격을 방어하며 방어값은 %d이다. 같은 숫자 스몰 공격도 원소와 무관하게 방어 가능하다." % int(card.get("number", 0))
        "ACE":
            return "에이스. 공격/방어 비교값은 1이다. 공격이 막히지 않고 명중했을 때만 상대에게 7장 드로우를 발생시킨다."
        "COURT":
            return "코트카드. 코트카드로만 방어한다. 이 카드의 전투값은 %d이다. 궁정 완성 조건을 만족하면 나머지 구성 카드 3장을 묘지로 보낼 수 있다." % int(card.get("value", 0))
        _:
            return "설명 없음"


func _card_meta_text(card) -> String:
    if card == null:
        return ""
    var card_type: String = str(card.get("type", ""))
    var suit: String = str(card.get("suit", ""))
    match card_type:
        "ATU":
            return "아투"
        "SMALL":
            return "%s · 스몰 · %d" % [SUIT_KO.get(suit, suit), int(card.get("number", 0))]
        "ACE":
            return "%s · 에이스 · 비교값 1" % SUIT_KO.get(suit, suit)
        "COURT":
            return "%s · %s · 전투값 %d" % [SUIT_KO.get(suit, suit), COURT_KO.get(str(card.get("court_rank", "")), str(card.get("court_rank", ""))), int(card.get("value", 0))]
        _:
            return card_type


func _show_card_description(card) -> void:
    if card == null or card_modal_overlay == null:
        return
    card_modal_image.texture = _card_front_texture(card)
    card_modal_name_label.text = _card_name(card)
    card_modal_meta_label.text = _card_meta_text(card)
    card_modal_rules_label.text = _card_rules_text(card)
    card_modal_overlay.visible = true
    card_modal_overlay.move_to_front()


func _hide_card_detail_modal() -> void:
    if card_modal_overlay != null:
        card_modal_overlay.visible = false


func _on_card_modal_backdrop_input(event: InputEvent) -> void:
    if event is InputEventMouseButton and not event.pressed:
        _hide_card_detail_modal()
    elif event is InputEventScreenTouch and not event.pressed:
        _hide_card_detail_modal()


func _on_card_modal_panel_input(_event: InputEvent) -> void:
    if card_modal_panel != null:
        card_modal_panel.accept_event()


func _build_card_detail_modal() -> void:
    card_modal_overlay = Control.new()
    card_modal_overlay.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    card_modal_overlay.mouse_filter = Control.MOUSE_FILTER_PASS
    card_modal_overlay.visible = false
    card_modal_overlay.z_index = 200
    add_child(card_modal_overlay)

    var backdrop := ColorRect.new()
    backdrop.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    backdrop.color = Color(0.0, 0.0, 0.0, 0.28)
    backdrop.mouse_filter = Control.MOUSE_FILTER_STOP
    backdrop.gui_input.connect(_on_card_modal_backdrop_input)
    card_modal_overlay.add_child(backdrop)

    card_modal_panel = PanelContainer.new()
    card_modal_panel.set_anchors_preset(Control.PRESET_CENTER)
    card_modal_panel.offset_left = -310
    card_modal_panel.offset_top = -220
    card_modal_panel.offset_right = 310
    card_modal_panel.offset_bottom = 220
    card_modal_panel.mouse_filter = Control.MOUSE_FILTER_STOP
    card_modal_panel.gui_input.connect(_on_card_modal_panel_input)
    card_modal_panel.add_theme_stylebox_override("panel", _make_box_style(Color(0.01, 0.012, 0.018, 0.94), Color(1.0, 1.0, 1.0, 1.0), 2, 0))
    card_modal_overlay.add_child(card_modal_panel)

    var margin := MarginContainer.new()
    margin.add_theme_constant_override("margin_left", 14)
    margin.add_theme_constant_override("margin_right", 14)
    margin.add_theme_constant_override("margin_top", 14)
    margin.add_theme_constant_override("margin_bottom", 14)
    card_modal_panel.add_child(margin)

    var content := HBoxContainer.new()
    content.add_theme_constant_override("separation", 18)
    margin.add_child(content)

    card_modal_image = TextureRect.new()
    card_modal_image.custom_minimum_size = Vector2(220, 344)
    card_modal_image.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
    card_modal_image.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
    card_modal_image.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
    card_modal_image.mouse_filter = Control.MOUSE_FILTER_IGNORE
    content.add_child(card_modal_image)

    var info := VBoxContainer.new()
    info.custom_minimum_size.x = 340
    info.add_theme_constant_override("separation", 10)
    content.add_child(info)

    card_modal_name_label = Label.new()
    card_modal_name_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    card_modal_name_label.add_theme_font_size_override("font_size", 22)
    card_modal_name_label.add_theme_color_override("font_color", Color(1.0, 1.0, 1.0, 1.0))
    info.add_child(card_modal_name_label)

    card_modal_meta_label = Label.new()
    card_modal_meta_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    card_modal_meta_label.add_theme_font_size_override("font_size", 12)
    card_modal_meta_label.add_theme_color_override("font_color", Color(0.72, 0.78, 0.88, 1.0))
    info.add_child(card_modal_meta_label)

    var separator := HSeparator.new()
    info.add_child(separator)

    card_modal_rules_label = Label.new()
    card_modal_rules_label.size_flags_vertical = Control.SIZE_EXPAND_FILL
    card_modal_rules_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    card_modal_rules_label.vertical_alignment = VERTICAL_ALIGNMENT_TOP
    card_modal_rules_label.add_theme_font_size_override("font_size", 14)
    card_modal_rules_label.add_theme_color_override("font_color", Color(0.90, 0.92, 0.96, 1.0))
    info.add_child(card_modal_rules_label)

    var close_hint := Label.new()
    close_hint.text = "바깥을 탭하면 닫힘"
    close_hint.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
    close_hint.add_theme_font_size_override("font_size", 11)
    close_hint.add_theme_color_override("font_color", Color(0.55, 0.60, 0.68, 1.0))
    info.add_child(close_hint)


func _build_aeon_message_overlay() -> void:
    aeon_message_overlay = Control.new()
    aeon_message_overlay.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    aeon_message_overlay.mouse_filter = Control.MOUSE_FILTER_STOP
    aeon_message_overlay.visible = false
    aeon_message_overlay.z_index = 220
    add_child(aeon_message_overlay)

    var shade := ColorRect.new()
    shade.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    shade.color = Color(0.0, 0.0, 0.0, 0.74)
    shade.mouse_filter = Control.MOUSE_FILTER_STOP
    aeon_message_overlay.add_child(shade)

    var center := CenterContainer.new()
    center.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    center.mouse_filter = Control.MOUSE_FILTER_IGNORE
    aeon_message_overlay.add_child(center)

    var panel := PanelContainer.new()
    panel.custom_minimum_size = Vector2(620, 220)
    panel.add_theme_stylebox_override("panel", _make_box_style(Color(0.06, 0.035, 0.02, 0.94), Color(0.82, 0.67, 0.40, 1.0), 2, 12))
    center.add_child(panel)

    var margin := MarginContainer.new()
    margin.add_theme_constant_override("margin_left", 24)
    margin.add_theme_constant_override("margin_right", 24)
    margin.add_theme_constant_override("margin_top", 20)
    margin.add_theme_constant_override("margin_bottom", 20)
    panel.add_child(margin)

    aeon_message_label = Label.new()
    aeon_message_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    aeon_message_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    aeon_message_label.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
    aeon_message_label.add_theme_font_size_override("font_size", 24)
    aeon_message_label.add_theme_color_override("font_color", Color(0.96, 0.92, 0.86, 1.0))
    aeon_message_label.custom_minimum_size = Vector2(560, 160)
    margin.add_child(aeon_message_label)


func _show_aeon_message(message: String, callback: Callable = Callable()) -> void:
    if aeon_message_overlay == null or aeon_message_label == null:
        if callback.is_valid():
            callback.call()
        return
    aeon_message_label.text = message
    aeon_message_overlay.visible = true
    aeon_message_overlay.move_to_front()
    _run_aeon_message_sequence(callback)


func _run_aeon_message_sequence(callback: Callable) -> void:
    await get_tree().create_timer(2.8).timeout
    if aeon_message_overlay != null:
        aeon_message_overlay.visible = false
    if callback.is_valid() and not game_over:
        callback.call()


func _viewer_player() -> int:
    if game_over:
        return -1
    if bot_enabled:
        return 0
    match phase:
        "DEFENSE":
            return 1 - current_player
        "RECYCLE_DECISION":
            return recycle_voter
        "DRAW_RESOLUTION":
            return pending_draw_player if pending_draw_player >= 0 else current_player
        "INITIATIVE_CHOICE":
            return initiative_winner if initiative_winner >= 0 else current_player
        _:
            return current_player


func _hand_should_be_visible(player: int) -> bool:
    if game_over:
        return true
    if bool(public_hand_flags[player]):
        return true
    return player == _viewer_player()


func _card_front_texture(card) -> Texture2D:
    if card == null:
        return null
    var card_id: String = str(card.get("id", ""))
    if card_id == "":
        return null
    var path: String = "res://assets/cards/%s.png" % card_id
    if ResourceLoader.exists(path):
        return load(path) as Texture2D
    return null


func _apply_card_art(button: Button, card, target_size: Vector2) -> bool:
    button.custom_minimum_size = target_size
    button.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
    button.size_flags_vertical = Control.SIZE_SHRINK_CENTER
    button.clip_text = true
    button.text_overrun_behavior = TextServer.OVERRUN_TRIM_ELLIPSIS
    button.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
    var texture := _card_front_texture(card)
    if texture == null:
        return false
    button.icon = texture
    button.expand_icon = true
    button.text = ""
    return true


func _apply_card_back_art(button: Button, target_size: Vector2) -> void:
    button.custom_minimum_size = target_size
    button.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
    button.size_flags_vertical = Control.SIZE_SHRINK_CENTER
    button.clip_text = true
    button.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
    button.icon = CARD_BACK_TEXTURE
    button.expand_icon = true
    button.text = ""


func _make_card_back_button(card_size: Vector2 = CARD_HAND_SIZE) -> Button:
    var b := Button.new()
    _apply_card_back_art(b, card_size)
    b.disabled = true
    b.focus_mode = Control.FOCUS_NONE
    b.tooltip_text = "비공개 카드"
    b.add_theme_color_override("font_disabled_color", Color(0.86, 0.88, 0.94, 1.0))
    b.add_theme_stylebox_override("disabled", _make_box_style(Color(0.055, 0.06, 0.075, 1.0), Color(0.78, 0.61, 0.18, 1.0), 1, 3, true))
    return b

func _create_hand_group(parent: VBoxContainer, title: String, player: int = -1) -> HBoxContainer:
    var panel := BattleDropZone.new()
    panel.accept_kinds = ["BATTLE_CARD"]
    panel.drop_enabled = player >= 0
    if player >= 0:
        panel.payload_dropped.connect(_on_hand_return_drop.bind(player))
    panel.custom_minimum_size = Vector2(0, 82)
    panel.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    panel.add_theme_stylebox_override("panel", _make_box_style(Color(0.065, 0.072, 0.092, 0.96), Color(0.20, 0.23, 0.29, 1.0), 1, 7))
    parent.add_child(panel)
    var v := VBoxContainer.new()
    v.add_theme_constant_override("separation", 2)
    panel.add_child(v)
    var label := Label.new()
    label.text = title
    label.horizontal_alignment = HORIZONTAL_ALIGNMENT_LEFT
    label.add_theme_font_size_override("font_size", 11)
    label.add_theme_color_override("font_color", Color(0.74, 0.79, 0.88, 1.0))
    v.add_child(label)
    var scroll := ScrollContainer.new()
    scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_AUTO
    scroll.vertical_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
    scroll.custom_minimum_size.y = 68
    v.add_child(scroll)
    var row := HBoxContainer.new()
    row.add_theme_constant_override("separation", 5)
    scroll.add_child(row)
    return row

func _make_hand_card_button(p: int, i: int, card) -> Button:
    var card_id: String = str(card["id"])
    var b = CardDragButton.new()
    b.fixed_card_size = CARD_HAND_SIZE
    b.text = _card_button_text(card)
    b.custom_minimum_size = CARD_HAND_SIZE
    b.add_theme_font_size_override("font_size", 8)
    var visual_state: String = "neutral"
    var drag_ok: bool = false
    if str(card.get("type", "")) == "ATU":
        b.tooltip_text = CardDatabase.atu_description(str(card.get("effect_id", "")))
    b.card_tapped.connect(_on_hand_card_pressed.bind(p, i))

    if phase == "ACTION":
        var can_start: bool = _can_start_attack_with(p, card) if p == current_player else false
        b.disabled = p != current_player
        if p == current_player and i == selected_attack_index:
            b.text += "\n[선택]"
            visual_state = "selected"
        elif p == current_player and _is_card_locked_for_player(p, card_id):
            b.text += "\n[데빌 잠금]"
            visual_state = "locked"
        elif p == current_player and not can_start:
            b.text += "\n[현재 사용 불가]"
            visual_state = "unavailable"
        elif p == current_player:
            visual_state = "playable"
        drag_ok = p == current_player and can_start

    elif phase == "ATTACK_BUILD":
        b.disabled = p != current_player or not _attack_build_card_is_clickable(card)
        if card_id == attack_base_id:
            b.text += "\n[기본]"
            visual_state = "submitted"
        elif card_id in attack_draft_ids:
            b.text += "\n[추가 공격]"
            visual_state = "submitted"
        elif card_id == attack_art_id:
            b.text += "\n[아트]"
            visual_state = "submitted"
        elif _card_is_selected_condition(card_id):
            b.text += "\n[조건]"
            visual_state = "selected"
        elif p == current_player and _attack_build_card_is_clickable(card):
            visual_state = "playable"
        elif p == current_player:
            visual_state = "unavailable"
        drag_ok = p == current_player and _attack_build_card_is_clickable(card)

    elif phase == "HANGED_PICK":
        b.disabled = p != current_player
        visual_state = "playable" if p == current_player else "neutral"

    elif phase == "STAR_PICK_SELF":
        b.disabled = p != current_player
        visual_state = "playable" if p == current_player else "neutral"

    elif phase == "STAR_PICK_OPP":
        b.disabled = p != 1 - current_player
        if p == current_player and card_id == star_self_id:
            b.text += "\n[교환 예정]"
            visual_state = "selected"
        elif p == 1 - current_player:
            visual_state = "playable"

    elif phase == "SUN_EXTRA":
        var can_sun_add: bool = p == current_player and _can_be_added_as_attack_card(p, card)
        b.disabled = p != current_player
        visual_state = "playable" if can_sun_add else ("unavailable" if p == current_player else "neutral")
        drag_ok = can_sun_add

    elif phase == "DEFENSE":
        var defender: int = 1 - current_player
        var can_use: bool = false
        if p == defender and not bool(defense_blocked[defender]) and not attack_package.is_empty() and not _is_card_locked_for_player(defender, card_id):
            var effect_id: String = str(card.get("effect_id", ""))
            if str(card.get("type", "")) == "ATU" and effect_id in DEFENSE_ATU_EFFECTS:
                can_use = _can_add_defense_atu(card)
                if _defense_atu_contains_card(card_id):
                    can_use = true
            else:
                can_use = _find_first_compatible_defense_target(card) >= 0
        b.disabled = p != defender

        if _draft_contains_card_id(card_id):
            b.text += "\n[일반 방어]"
            visual_state = "submitted"
        elif _defense_atu_contains_card(card_id):
            b.text += "\n[아투 방어]"
            visual_state = "submitted"
        elif p == defender and not can_use:
            b.text += "\n[현재 방어 불가]"
            visual_state = "unavailable"
        elif p == defender:
            visual_state = "playable"
        drag_ok = p == defender and can_use

    else:
        b.disabled = true

    # 사용 불가 카드도 탭하면 상세 정보는 볼 수 있다. 실제 행동 가능 여부는 핸들러/drag_enabled가 판정한다.
    b.disabled = false
    b.drag_enabled = drag_ok
    b.drag_payload = {"kind": "HAND_CARD", "player": p, "index": i, "card_id": card_id}
    b.accept_drop_kinds = ["BATTLE_CARD"]
    b.drop_callback = _on_hand_return_drop.bind(p)
    _apply_card_button_style(b, card, visual_state)
    _apply_card_art(b, card, CARD_HAND_SIZE)
    return b


func _player_has_playable_attack(player: int) -> bool:
    if player < 0 or player >= hands.size():
        return false
    for card in hands[player]:
        if _can_start_attack_with(player, card):
            return true
    return false


func _should_center_deck_action() -> bool:
    if phase == "INITIATIVE_READY":
        return true
    if phase == "ACTION" and (not bot_enabled or current_player != bot_player):
        return not _player_has_playable_attack(current_player)
    return false


func _make_center_deck_button() -> Button:
    var b := Button.new()
    b.size = CARD_DECK_SIZE
    _apply_card_back_art(b, CARD_DECK_SIZE)
    b.pressed.connect(_on_center_deck_pressed.bind(b))
    b.tooltip_text = "선공 판정 — 각자 1장 드로우" if phase == "INITIATIVE_READY" else "1장 드로우하고 턴 종료"
    _apply_deck_card_style(b, "primary" if phase == "INITIATIVE_READY" else "draw")
    return b


func _make_center_deck_widget() -> Control:
    var holder := Control.new()
    holder.custom_minimum_size = Vector2(236, 202)
    holder.size = Vector2(236, 202)

    var base_x: float = 70.0
    for offset_value in [10, 5]:
        var back := PanelContainer.new()
        back.position = Vector2(base_x + float(offset_value), float(offset_value))
        back.size = CARD_DECK_SIZE
        back.mouse_filter = Control.MOUSE_FILTER_IGNORE
        back.add_theme_stylebox_override("panel", _make_box_style(Color(0.055, 0.06, 0.075, 1.0), Color(0.64, 0.48, 0.12, 1.0), 1, 3))
        holder.add_child(back)

    center_deck_action_button = _make_center_deck_button()
    center_deck_action_button.position = Vector2(base_x, 0)
    holder.add_child(center_deck_action_button)

    var action_label := Label.new()
    action_label.position = Vector2(0, 148)
    action_label.size = Vector2(236, 48)
    action_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    action_label.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
    action_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    action_label.add_theme_font_size_override("font_size", 12)
    action_label.text = "선공 판정 — 각자 1장 드로우" if phase == "INITIATIVE_READY" else "1장 드로우하고 턴 종료"
    holder.add_child(action_label)
    return holder

func _on_center_deck_pressed(button: Button) -> void:
    if button != null and is_instance_valid(button):
        deck_draw_origin_override = button.get_global_rect().get_center()
        deck_draw_origin_uses = 2 if phase == "INITIATIVE_READY" else 1
    _on_deck_pile_pressed()


func _refresh_zone_buttons() -> void:
    if deck_pile_button != null:
        deck_pile_button.visible = not _should_center_deck_action()
        var deck_can_draw: bool = phase == "INITIATIVE_READY" or (phase == "ACTION" and (not bot_enabled or current_player != bot_player))
        deck_pile_button.disabled = not deck_can_draw
        _apply_card_back_art(deck_pile_button, CARD_DECK_SIZE)
        if phase == "INITIATIVE_READY":
            deck_pile_button.tooltip_text = "선공 판정: 각자 1장 드로우"
            _apply_deck_card_style(deck_pile_button, "primary")
        elif phase == "ACTION" and (not bot_enabled or current_player != bot_player):
            deck_pile_button.tooltip_text = "1장 드로우하고 턴 종료"
            _apply_deck_card_style(deck_pile_button, "draw")
        else:
            deck_pile_button.tooltip_text = ""
            _apply_deck_card_style(deck_pile_button)
    if discard_pile_button != null:
        discard_pile_button.custom_minimum_size = CARD_FIELD_SIZE
        if discard.is_empty():
            discard_pile_button.icon = null
            discard_pile_button.text = "묘지\n0장"
        else:
            var top_card = discard.back()
            discard_pile_button.text = "묘지 %d장\n%s" % [discard.size(), _card_name(top_card)]
            _apply_card_art(discard_pile_button, top_card, CARD_FIELD_SIZE)
        discard_pile_button.tooltip_text = "묘지 %d장 — 탭해서 전체 보기" % discard.size()
    if aeon_status_label != null:
        aeon_status_label.text = ""


func _render_battlefield() -> void:
    if battlefield_box == null:
        return
    _clear_children(battlefield_box)
    _clear_children(defense_atu_box)

    var field := VBoxContainer.new()
    field.add_theme_constant_override("separation", 8)
    field.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    field.custom_minimum_size = Vector2(398, 392)
    battlefield_box.add_child(field)

    if phase == "INITIATIVE_READY":
        var center := CenterContainer.new()
        center.size_flags_horizontal = Control.SIZE_EXPAND_FILL
        center.custom_minimum_size = Vector2(398, 392)
        field.add_child(center)
        center.add_child(_make_center_deck_widget())
        return

    if phase in ["INITIATIVE_DRAW", "INITIATIVE_CHOICE", "OPENING_DEAL"]:
        var initiative_row := HBoxContainer.new()
        initiative_row.alignment = BoxContainer.ALIGNMENT_CENTER
        initiative_row.size_flags_horizontal = Control.SIZE_EXPAND_FILL
        initiative_row.add_theme_constant_override("separation", 36)
        field.add_child(initiative_row)
        for p in range(2):
            var lane := VBoxContainer.new()
            lane.custom_minimum_size = Vector2(190, 230)
            lane.add_theme_constant_override("separation", 8)
            initiative_row.add_child(lane)

            var who := Label.new()
            who.text = "P%d%s" % [p + 1, " BOT" if bot_enabled and p == bot_player else ""]
            who.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
            who.add_theme_font_size_override("font_size", 18)
            lane.add_child(who)

            var card = initiative_cards[p]
            if card != null:
                var card_button := Button.new()
                card_button.text = _card_button_text(card) + "\n[선공 판정 공개]"
                card_button.disabled = false
                card_button.custom_minimum_size = CARD_INIT_SIZE
                card_button.tooltip_text = "탭하면 카드 설명을 본다."
                card_button.pressed.connect(_show_card_description.bind(card))
                card_button.add_theme_font_size_override("font_size", 14)
                var state := "submitted"
                if phase == "INITIATIVE_CHOICE" and p == initiative_winner:
                    state = "selected"
                _apply_card_button_style(card_button, card, state)
                _apply_card_art(card_button, card, CARD_INIT_SIZE)
                lane.add_child(card_button)
            else:
                var empty_card := _make_card_back_button()
                empty_card.text = "판정 카드\n드로우 대기"
                _apply_card_back_art(empty_card, CARD_INIT_SIZE)
                lane.add_child(empty_card)

            var result := Label.new()
            result.text = "선택권 획득" if phase == "INITIATIVE_CHOICE" and p == initiative_winner else ""
            result.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
            result.add_theme_color_override("font_color", Color(1.0, 0.82, 0.30, 1.0))
            lane.add_child(result)
        return

    if not attack_package.is_empty():
        var attacker_is_top: bool = current_player == 1
        var atu_entries: Array = []
        var normal_indices: Array = []
        for i in range(attack_package.size()):
            var entry: Dictionary = attack_package[i]
            if str(entry.get("card", {}).get("type", "")) == "ATU":
                atu_entries.append(entry)
            else:
                normal_indices.append(i)

        if attacker_is_top and not atu_entries.is_empty():
            _render_attack_atu_row(field, atu_entries, current_player)

        if not normal_indices.is_empty():
            var actual_title := Label.new()
            actual_title.text = "실제 공격층"
            actual_title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
            actual_title.add_theme_color_override("font_color", Color(0.82, 0.86, 0.94, 1.0))
            field.add_child(actual_title)
            var actual_row := HBoxContainer.new()
            actual_row.alignment = BoxContainer.ALIGNMENT_CENTER
            actual_row.size_flags_horizontal = Control.SIZE_EXPAND_FILL
            actual_row.custom_minimum_size.y = 248
            actual_row.add_theme_constant_override("separation", 12)
            field.add_child(actual_row)
            for attack_index in normal_indices:
                _render_attack_lane(actual_row, int(attack_index), attacker_is_top)
        elif atu_entries.is_empty():
            var no_attack := Label.new()
            no_attack.text = "정산 가능한 공격 카드가 없다."
            no_attack.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
            field.add_child(no_attack)

        if not attacker_is_top and not atu_entries.is_empty():
            _render_attack_atu_row(field, atu_entries, current_player)

    elif phase == "ATTACK_BUILD" and not attack_draft_ids.is_empty():
        var draft_atu: Array = []
        var draft_normal: Array = []
        for card_id in attack_draft_ids:
            var card: Variant = _find_card_in_hand_by_id(current_player, str(card_id))
            if card == null:
                continue
            if str(card.get("type", "")) == "ATU":
                draft_atu.append(card)
            else:
                draft_normal.append(card)
        var attacker_is_top_draft: bool = current_player == 1
        if attacker_is_top_draft and not draft_atu.is_empty():
            _render_draft_atu_row(field, draft_atu)
        if not draft_normal.is_empty():
            var draft_title := Label.new()
            draft_title.text = "실제 공격층 — 구성 중"
            draft_title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
            field.add_child(draft_title)
            var draft_row := HBoxContainer.new()
            draft_row.alignment = BoxContainer.ALIGNMENT_CENTER
            draft_row.size_flags_horizontal = Control.SIZE_EXPAND_FILL
            draft_row.custom_minimum_size.y = 248
            draft_row.add_theme_constant_override("separation", 10)
            field.add_child(draft_row)
            for card in draft_normal:
                var draft_button = CardDragButton.new()
                var draft_card_id: String = str(card.get("id", ""))
                draft_button.fixed_card_size = CARD_FIELD_SIZE
                draft_button.text = _card_button_text(card)
                draft_button.disabled = false
                draft_button.custom_minimum_size = CARD_FIELD_SIZE
                draft_button.tooltip_text = "탭: 카드 상세 / 손패로 드래그: 구성에서 제외"
                draft_button.card_tapped.connect(_show_card_description.bind(card))
                draft_button.drag_enabled = true
                draft_button.drag_payload = {"kind": "BATTLE_CARD", "player": current_player, "card_id": draft_card_id, "location": "ATTACK_DRAFT"}
                draft_button.accept_drop_kinds = ["HAND_CARD"]
                draft_button.drop_callback = _on_battlefield_drop
                _apply_card_button_style(draft_button, card, "selected")
                _apply_card_art(draft_button, card, CARD_FIELD_SIZE)
                draft_row.add_child(draft_button)
        if not attacker_is_top_draft and not draft_atu.is_empty():
            _render_draft_atu_row(field, draft_atu)
    else:
        if _should_center_deck_action():
            var deck_center := CenterContainer.new()
            deck_center.size_flags_horizontal = Control.SIZE_EXPAND_FILL
            deck_center.custom_minimum_size = Vector2(398, 270)
            field.add_child(deck_center)
            deck_center.add_child(_make_center_deck_widget())
        else:
            var empty := Label.new()
            empty.text = "드래그하여 카드를 올려주세요"
            empty.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
            empty.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
            empty.custom_minimum_size = Vector2(398, 392)
            empty.add_theme_font_size_override("font_size", 18)
            empty.add_theme_color_override("font_color", Color(0.52, 0.57, 0.66, 1.0))
            field.add_child(empty)

    var defense_atu_cards: Array = []
    if phase == "DEFENSE":
        for choice in defense_atu_choices:
            var c: Variant = _find_card_in_hand_by_id(1 - current_player, str(choice.get("card_id", "")))
            if c != null:
                defense_atu_cards.append(c)
    else:
        for used in defense_atu_used:
            if used.get("card", null) != null:
                defense_atu_cards.append(used["card"])
    if not defense_atu_cards.is_empty():
        var atu_title := Label.new()
        atu_title.text = "방어 아투"
        atu_title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
        atu_title.add_theme_color_override("font_color", Color(0.72, 0.84, 1.0, 1.0))
        field.add_child(atu_title)

        var defense_atu_row := HBoxContainer.new()
        defense_atu_row.alignment = BoxContainer.ALIGNMENT_CENTER
        defense_atu_row.size_flags_horizontal = Control.SIZE_EXPAND_FILL
        defense_atu_row.add_theme_constant_override("separation", 8)
        field.add_child(defense_atu_row)

        for c in defense_atu_cards:
            var chip = CardDragButton.new()
            var card_id: String = str(c.get("id", ""))
            chip.fixed_card_size = CARD_FIELD_SIZE
            chip.text = _card_button_text(c)
            chip.disabled = false
            chip.custom_minimum_size = CARD_FIELD_SIZE
            chip.tooltip_text = "탭: 카드 상세 / 손패로 드래그: 방어 아투 취소"
            chip.card_tapped.connect(_show_card_description.bind(c))
            chip.drag_enabled = phase == "DEFENSE"
            chip.drag_payload = {"kind": "BATTLE_CARD", "player": 1 - current_player, "card_id": card_id, "location": "DEFENSE_ATU"}
            chip.accept_drop_kinds = ["HAND_CARD"]
            chip.drop_callback = _on_battlefield_drop
            chip.add_theme_font_size_override("font_size", 9)
            _apply_card_button_style(chip, c, "submitted")
            _apply_card_art(chip, c, CARD_FIELD_SIZE)
            defense_atu_row.add_child(chip)


func _render_attack_atu_row(parent: VBoxContainer, entries: Array, attacker: int) -> void:
    var title := Label.new()
    title.text = "P%d 아투 효과층" % (attacker + 1)
    title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    title.add_theme_color_override("font_color", Color(0.83, 0.70, 0.96, 1.0))
    parent.add_child(title)
    var row := HBoxContainer.new()
    row.alignment = BoxContainer.ALIGNMENT_CENTER
    row.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    row.add_theme_constant_override("separation", 8)
    parent.add_child(row)
    for entry in entries:
        var card = entry.get("card", null)
        if card == null:
            continue
        var chip := Button.new()
        chip.text = _card_button_text(card)
        var resolved: int = int(entry.get("resolved_draw", 0))
        if phase == "RESOLUTION_REVIEW" and resolved > 0:
            chip.text += "\n[정산 %d장]" % resolved
        chip.disabled = false
        chip.custom_minimum_size = CARD_FIELD_SIZE
        chip.tooltip_text = "탭하면 카드 설명을 본다."
        chip.pressed.connect(_show_card_description.bind(card))
        _apply_card_button_style(chip, card, "submitted")
        _apply_card_art(chip, card, CARD_FIELD_SIZE)
        row.add_child(chip)


func _render_draft_atu_row(parent: VBoxContainer, cards: Array) -> void:
    var title := Label.new()
    title.text = "아투 효과층 — 구성 중"
    title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    title.add_theme_color_override("font_color", Color(0.83, 0.70, 0.96, 1.0))
    parent.add_child(title)
    var row := HBoxContainer.new()
    row.alignment = BoxContainer.ALIGNMENT_CENTER
    row.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    row.add_theme_constant_override("separation", 8)
    parent.add_child(row)
    for card in cards:
        var b = CardDragButton.new()
        var card_id: String = str(card.get("id", ""))
        b.fixed_card_size = CARD_FIELD_SIZE
        b.text = _card_button_text(card)
        b.disabled = false
        b.custom_minimum_size = CARD_FIELD_SIZE
        b.tooltip_text = "탭: 카드 상세 / 손패로 드래그: 구성에서 제외"
        b.card_tapped.connect(_show_card_description.bind(card))
        b.drag_enabled = true
        b.drag_payload = {"kind": "BATTLE_CARD", "player": current_player, "card_id": card_id, "location": "ATTACK_DRAFT"}
        b.accept_drop_kinds = ["HAND_CARD"]
        b.drop_callback = _on_battlefield_drop
        _apply_card_button_style(b, card, "selected")
        _apply_card_art(b, card, CARD_FIELD_SIZE)
        row.add_child(b)


func _render_attack_lane(parent: HBoxContainer, index: int, attacker_is_top: bool) -> void:
    var entry: Dictionary = attack_package[index]
    var lane := VBoxContainer.new()
    lane.custom_minimum_size = Vector2(78, 248)
    lane.add_theme_constant_override("separation", 4)
    parent.add_child(lane)

    var defense_card: Variant = entry.get("defense", null)
    if defense_card == null and phase == "DEFENSE" and defense_draft.has(index):
        defense_card = _find_card_in_hand_by_id(1 - current_player, str(defense_draft[index]))

    if not attacker_is_top:
        _render_defense_slot(lane, defense_card, index)

    var connector_top := Label.new()
    connector_top.text = "↓" if attacker_is_top else "↑"
    connector_top.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    connector_top.add_theme_color_override("font_color", Color(0.68, 0.72, 0.78, 1.0))
    if not attacker_is_top:
        lane.add_child(connector_top)

    var attack_button = CardDragButton.new()
    attack_button.fixed_card_size = CARD_FIELD_SIZE
    attack_button.text = _card_button_text(entry["card"])
    attack_button.custom_minimum_size = CARD_FIELD_SIZE
    attack_button.add_theme_font_size_override("font_size", 9)
    var attack_state: String = "selected" if phase == "DEFENSE" and index == selected_defense_target else "submitted"
    _apply_card_button_style(attack_button, entry["card"], attack_state)
    _apply_card_art(attack_button, entry["card"], CARD_FIELD_SIZE)
    attack_button.disabled = false
    attack_button.tooltip_text = "탭하면 카드 상세을 본다." if phase != "DEFENSE" else "탭: 카드 상세/방어 대상 선택"
    attack_button.card_tapped.connect(_on_battlefield_attack_card_pressed.bind(index))
    attack_button.accept_drop_kinds = ["HAND_CARD"]
    attack_button.drop_callback = _on_attack_lane_drop.bind(index)

    var attack_drop = BattleDropZone.new()
    attack_drop.drop_enabled = phase == "DEFENSE"
    attack_drop.custom_minimum_size = Vector2(74, 109)
    attack_drop.add_theme_stylebox_override("panel", _make_box_style(Color(0.03, 0.035, 0.045, 0.20), Color(0.50, 0.55, 0.66, 0.65) if phase == "DEFENSE" else Color(0.12, 0.13, 0.16, 0.0), 1, 7))
    attack_drop.payload_dropped.connect(_on_attack_lane_drop.bind(index))
    attack_drop.add_child(attack_button)
    lane.add_child(attack_drop)

    var notes: Array = []
    if index == art_target_index:
        notes.append("아트: 방어 후 잔여×2")
    if bool(entry.get("cannot_be_nullified", false)):
        notes.append("무효불가")
    if bool(entry.get("nullified", false)):
        notes.append("무효")
    if phase == "RESOLUTION_REVIEW":
        notes.append("최종 %d장" % int(entry.get("resolved_draw", 0)))
    var note_label := Label.new()
    note_label.text = _join_strings(notes, " / ") if not notes.is_empty() else ("↓" if attacker_is_top else "")
    note_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    note_label.add_theme_color_override("font_color", Color(0.88, 0.77, 0.45, 1.0) if not notes.is_empty() else Color(0.68, 0.72, 0.78, 1.0))
    lane.add_child(note_label)

    if attacker_is_top:
        _render_defense_slot(lane, defense_card, index)


func _on_battlefield_attack_card_pressed(index: int) -> void:
    if index < 0 or index >= attack_package.size():
        return
    var card = attack_package[index].get("card", null)
    if card != null:
        _show_card_description(card)
    if phase == "DEFENSE":
        _select_defense_target(index)



func _render_defense_slot(parent: VBoxContainer, defense_card, target_index: int) -> void:
    var drop_slot := BattleDropZone.new()
    drop_slot.drop_enabled = phase == "DEFENSE"
    drop_slot.custom_minimum_size = CARD_FIELD_SIZE + Vector2(4, 4)
    drop_slot.add_theme_stylebox_override("panel", _make_box_style(Color(0.03, 0.035, 0.045, 0.18), Color(0.50, 0.55, 0.66, 0.72) if phase == "DEFENSE" else Color(0.12, 0.13, 0.16, 0.0), 1, 7, true))
    drop_slot.payload_dropped.connect(_on_attack_lane_drop.bind(target_index))
    parent.add_child(drop_slot)

    if defense_card != null:
        var defense_button = CardDragButton.new()
        var defense_card_id: String = str(defense_card.get("id", ""))
        defense_button.fixed_card_size = CARD_FIELD_SIZE
        defense_button.text = _card_button_text(defense_card)
        defense_button.disabled = false
        defense_button.custom_minimum_size = CARD_FIELD_SIZE
        defense_button.add_theme_font_size_override("font_size", 9)
        defense_button.tooltip_text = "탭: 카드 상세 / 손패로 드래그: 방어 취소"
        defense_button.card_tapped.connect(_show_card_description.bind(defense_card))
        var is_draft_defense: bool = phase == "DEFENSE" and defense_draft.has(target_index) and str(defense_draft[target_index]) == defense_card_id
        defense_button.drag_enabled = is_draft_defense
        defense_button.drag_payload = {"kind": "BATTLE_CARD", "player": 1 - current_player, "card_id": defense_card_id, "location": "DEFENSE_DRAFT", "target_index": target_index}
        defense_button.accept_drop_kinds = ["HAND_CARD"]
        defense_button.drop_callback = _on_attack_lane_drop.bind(target_index)
        _apply_card_button_style(defense_button, defense_card, "submitted")
        _apply_card_art(defense_button, defense_card, CARD_FIELD_SIZE)
        drop_slot.add_child(defense_button)
    else:
        var slot := Button.new()
        slot.text = "방어 카드를\n올려주세요"
        slot.disabled = true
        slot.custom_minimum_size = CARD_FIELD_SIZE
        slot.add_theme_color_override("font_disabled_color", Color(0.62, 0.66, 0.72, 1.0))
        slot.add_theme_stylebox_override("disabled", _make_box_style(Color(0.07, 0.08, 0.10, 1.0), Color(0.27, 0.29, 0.34, 1.0), 1, 7, true))
        drop_slot.add_child(slot)


func _animate_pentacle_transfer(player: int, amount: int) -> void:
    if animation_layer == null or pentacle_pile_button == null or hand_panels[player] == null or amount <= 0:
        return

    var coin := PanelContainer.new()
    coin.custom_minimum_size = Vector2(62, 34)
    coin.size = Vector2(62, 34)
    coin.mouse_filter = Control.MOUSE_FILTER_IGNORE
    coin.add_theme_stylebox_override("panel", _make_box_style(Color(0.30, 0.21, 0.045, 0.98), Color(1.0, 0.80, 0.18, 1.0), 2, 17))
    var label := Label.new()
    label.text = "◆" if amount == 1 else "◆ ×%d" % amount
    label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    label.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
    label.add_theme_font_size_override("font_size", 15)
    label.add_theme_color_override("font_color", Color(1.0, 0.90, 0.48, 1.0))
    coin.add_child(label)
    animation_layer.add_child(coin)

    var layer_origin: Vector2 = animation_layer.get_global_rect().position
    var from_pos: Vector2 = hand_panels[player].get_global_rect().get_center() - layer_origin - coin.size * 0.5
    var to_pos: Vector2 = pentacle_pile_button.get_global_rect().get_center() - layer_origin - coin.size * 0.5
    coin.position = from_pos
    coin.scale = Vector2(0.78, 0.78)
    coin.modulate = Color(1, 1, 1, 0.0)

    var tween := create_tween()
    tween.tween_property(coin, "modulate", Color(1, 1, 1, 1), 0.06)
    tween.parallel().tween_property(coin, "scale", Vector2(1.0, 1.0), 0.10)
    tween.tween_property(coin, "position", to_pos, 0.36).set_trans(Tween.TRANS_CUBIC).set_ease(Tween.EASE_IN_OUT)
    tween.parallel().tween_property(coin, "rotation", 0.18, 0.36)
    tween.tween_property(coin, "scale", Vector2(0.72, 0.72), 0.08)
    tween.parallel().tween_property(coin, "modulate", Color(1, 1, 1, 0), 0.08)
    tween.tween_callback(coin.queue_free)


func _animate_card_transfer(from_control: Control, to_control: Control, card, sequence: int = 0, face_up: bool = true, suffix: String = "", from_global_override: Vector2 = Vector2(-1, -1)) -> void:
    if animation_layer == null or from_control == null or to_control == null:
        return
    if not is_instance_valid(from_control) or not is_instance_valid(to_control):
        return

    var flyer := PanelContainer.new()
    flyer.custom_minimum_size = CARD_FLYER_SIZE
    flyer.size = CARD_FLYER_SIZE
    flyer.mouse_filter = Control.MOUSE_FILTER_IGNORE
    var border := Color(0.70, 0.74, 0.84, 1.0)
    var bg := Color(0.10, 0.12, 0.18, 0.98)
    if card != null and face_up:
        var suit: String = str(card.get("suit", ""))
        bg = _card_base_color(card).darkened(0.18)
        border = _card_base_color(card).lightened(0.28) if suit != "" or str(card.get("type", "")) == "ATU" else border
    flyer.add_theme_stylebox_override("panel", _make_box_style(bg, border, 2, 7))

    var flyer_texture: Texture2D = null
    if card != null and face_up:
        flyer_texture = _card_front_texture(card)
    elif not face_up:
        flyer_texture = CARD_BACK_TEXTURE

    if flyer_texture != null:
        var texture_rect := TextureRect.new()
        texture_rect.texture = flyer_texture
        texture_rect.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
        texture_rect.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
        texture_rect.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
        texture_rect.mouse_filter = Control.MOUSE_FILTER_IGNORE
        flyer.add_child(texture_rect)

    var label := Label.new()
    if flyer_texture != null:
        label.text = ""
    elif card != null and face_up:
        label.text = _card_name(card)
    else:
        label.text = "CARD"
    if suffix != "":
        label.text += "\n" + suffix
    label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    label.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
    label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    label.add_theme_font_size_override("font_size", 11)
    flyer.add_child(label)
    animation_layer.add_child(flyer)

    var layer_origin: Vector2 = animation_layer.get_global_rect().position
    var from_center: Vector2 = from_control.get_global_rect().get_center()
    if from_global_override.x >= 0.0 and from_global_override.y >= 0.0:
        from_center = from_global_override
    var from_pos: Vector2 = from_center - layer_origin - flyer.size * 0.5
    var to_pos: Vector2 = to_control.get_global_rect().get_center() - layer_origin - flyer.size * 0.5
    flyer.position = from_pos
    flyer.scale = Vector2(0.88, 0.88)
    flyer.modulate = Color(1, 1, 1, 0.0)

    var tween := create_tween()
    var delay: float = 0.075 * float(sequence)
    if delay > 0.0:
        tween.tween_interval(delay)
    tween.tween_property(flyer, "modulate", Color(1, 1, 1, 1), 0.05)
    tween.parallel().tween_property(flyer, "scale", Vector2(1.0, 1.0), 0.08)
    tween.tween_property(flyer, "position", to_pos, 0.38).set_trans(Tween.TRANS_CUBIC).set_ease(Tween.EASE_IN_OUT)
    tween.parallel().tween_property(flyer, "rotation", 0.05 if sequence % 2 == 0 else -0.05, 0.38)
    tween.tween_property(flyer, "scale", Vector2(0.78, 0.78), 0.07)
    tween.parallel().tween_property(flyer, "modulate", Color(1, 1, 1, 0), 0.08)
    tween.tween_callback(flyer.queue_free)


func _animate_stack_transfer(from_control: Control, to_control: Control, amount: int, label_text: String) -> void:
    if amount <= 0:
        return
    var fake := {"id": label_text, "type": "", "suit": ""}
    _animate_card_transfer(from_control, to_control, fake, 0, true, "×%d" % amount)


func _animate_draw_to_hand(player: int, card, sequence: int) -> void:
    if deck_pile_button == null or hand_panels[player] == null:
        return
    var origin := Vector2(-1, -1)
    if deck_draw_origin_uses > 0:
        origin = deck_draw_origin_override
        deck_draw_origin_uses -= 1
        if deck_draw_origin_uses <= 0:
            deck_draw_origin_override = Vector2(-1, -1)
    _animate_card_transfer(deck_pile_button, hand_panels[player], card, sequence, false, "드로우", origin)


func _refresh_ui() -> void:
    deck_label.text = "덱 %d장" % deck.size()
    if battle_title_label != null:
        var aeon_suffix: String = " (에온 제외중)" if _excluded_contains_aeon() else ""
        battle_title_label.text = "제%d 에온%s" % [recycle_count + 1, aeon_suffix]
    for p_index in range(2):
        if p_index < player_pentacle_labels.size() and player_pentacle_labels[p_index] != null:
            player_pentacle_labels[p_index].text = "◆ 펜타클 %d" % int(player_pentacles[p_index])
    if pentacle_pile_button != null:
        pentacle_pile_button.text = "%d펜타클" % shared_pentacles
    var ui_viewer: int = _viewer_player()
    var viewer_number: int = ui_viewer + 1 if ui_viewer >= 0 else current_player + 1
    phase_label.text = "%s  |  P%d 기준" % [_phase_name(), viewer_number]
    action_hint_label.text = _phase_instruction()
    attack_label.text = "선공 판정 — 덱에서 각자 1장을 드로우해 공개하고 위계를 비교한다." if phase in ["INITIATIVE_READY", "INITIATIVE_DRAW", "INITIATIVE_CHOICE", "OPENING_DEAL"] else _attack_package_text()
    _refresh_zone_buttons()
    _render_battlefield()

    for p in range(2):
        var viewer: int = _viewer_player()
        var is_active_hand: bool = viewer == p and not game_over
        var visible: bool = _hand_should_be_visible(p)
        var public_mark: String = "  [공개 중]" if bool(public_hand_flags[p]) and not game_over else ""
        var bot_mark: String = " [BOT]" if bot_enabled and p == bot_player else ""
        if p == 1 and visible:
            hand_panels[p].custom_minimum_size.y = 224
        hand_labels[p].text = "%sP%d%s 손패 — %d장%s%s" % ["▶ " if is_active_hand else "", p + 1, bot_mark, hands[p].size(), "  [조작 플레이어]" if is_active_hand else "", public_mark]
        hand_labels[p].add_theme_color_override("font_color", Color(0.72, 0.86, 1.0, 1.0) if is_active_hand else Color(0.82, 0.83, 0.87, 1.0))
        _apply_hand_panel_style(hand_panels[p], is_active_hand)
        _clear_children(hand_boxes[p])

        if not visible:
            var hidden_count: int = hands[p].size()
            var shown_count: int = mini(hidden_count, 10)
            hand_panels[p].custom_minimum_size.y = CARD_HAND_SIZE.y + 27.0

            var hidden_row := HBoxContainer.new()
            hidden_row.alignment = BoxContainer.ALIGNMENT_CENTER
            hidden_row.size_flags_horizontal = Control.SIZE_EXPAND_FILL
            hidden_row.add_theme_constant_override("separation", 4)
            hand_boxes[p].add_child(hidden_row)
            for _hidden_index in range(shown_count):
                hidden_row.add_child(_make_card_back_button(CARD_HAND_SIZE))
            continue

        var atu_row := _create_hand_group(hand_boxes[p], "상층 — 아투", p)
        var small_ace_row := _create_hand_group(hand_boxes[p], "중층 — 스몰 + 에이스", p)
        var court_row := _create_hand_group(hand_boxes[p], "하층 — 코트", p)

        for i in range(hands[p].size()):
            var card = hands[p][i]
            var b := _make_hand_card_button(p, i, card)
            match str(card.get("type", "")):
                "ATU":
                    atu_row.add_child(b)
                "COURT":
                    court_row.add_child(b)
                _:
                    small_ace_row.add_child(b)

    _clear_children(action_box)
    _clear_children(secondary_action_box)
    _schedule_bot_action_if_needed()

    if game_over:
        var restart := Button.new()
        restart.text = "새 게임"
        restart.pressed.connect(_new_game)
        action_box.add_child(restart)
        return

    if phase == "INITIATIVE_READY":
        status_label.text = "선공 판정 준비 — 양쪽 손패는 아직 0장이다. 중앙의 덱을 눌러 판정을 시작한다."
        return

    if phase == "INITIATIVE_DRAW":
        status_label.text = "선공 판정 카드를 드로우하고 공개하는 중이다."
        return

    if phase == "OPENING_DEAL":
        status_label.text = "시작 손패를 배분 중이다."
        return

    if phase in ["DEFENSE_REVEAL", "RESOLUTION_REVIEW"]:
        return

    if phase == "INITIATIVE_CHOICE":
        status_label.text = "선공 판정 완료 — P%d가 선공/후공 선택권을 얻었다." % (initiative_winner + 1)
        if bot_enabled and initiative_winner == bot_player:
            var bot_continue := Button.new()
            bot_continue.text = "판정 확인 → P2 BOT 선택 진행"
            bot_continue.tooltip_text = "공개된 두 판정 카드를 확인한 뒤 봇이 선공/후공을 선택한다."
            bot_continue.pressed.connect(_confirm_bot_initiative_choice)
            _apply_action_button_style(bot_continue, "primary")
            action_box.add_child(bot_continue)
        else:
            var first := Button.new()
            first.text = "선공 선택"
            first.pressed.connect(_choose_first.bind(initiative_winner, true))
            _apply_action_button_style(first, "primary")
            action_box.add_child(first)
            var second := Button.new()
            second.text = "후공 선택"
            second.pressed.connect(_choose_first.bind(initiative_winner, false))
            _apply_action_button_style(second, "secondary")
            action_box.add_child(second)
        return

    if phase == "ACTION":
        if _should_center_deck_action():
            status_label.text = "현재 손패에 낼 수 있는 카드가 없다. 중앙 덱을 눌러 1장 드로우하고 턴을 종료한다."
            return
        var attack_button := Button.new()
        attack_button.text = "선택한 카드로 공격 / 아투 사용"
        attack_button.disabled = selected_attack_index < 0
        attack_button.pressed.connect(_begin_attack_build)
        _apply_action_button_style(attack_button, "primary")
        action_box.add_child(attack_button)

        return

    if phase == "ATTACK_BUILD":
        var source_id: String = _unresolved_condition_source_id()
        if source_id != "":
            var source: Variant = _find_card_anywhere_for_draft(source_id)
            if source != null and str(source.get("effect_id", "")) in ["DEVIL", "UNIVERSE"] and str(condition_family.get(source_id, "")) == "":
                var ace_family := Button.new()
                ace_family.text = "에이스 계열 선택"
                ace_family.pressed.connect(_set_condition_family.bind(source_id, "ACE"))
                action_box.add_child(ace_family)
                var knight_family := Button.new()
                knight_family.text = "나이트 계열 선택"
                knight_family.pressed.connect(_set_condition_family.bind(source_id, "KNIGHT"))
                action_box.add_child(knight_family)

        if attack_art_id != "":
            for small_id in _available_small_attack_ids():
                var art_target := Button.new()
                art_target.text = "%s아트 → %s (방어 후 잔여 피해×2)" % ["● " if str(small_id) == attack_art_target_id else "", _card_name_by_id_for_build(str(small_id))]
                art_target.pressed.connect(_select_art_target.bind(str(small_id)))
                action_box.add_child(art_target)

        var confirm_build := Button.new()
        confirm_build.text = "추가 제출 확정" if attack_append_mode else "공격 패키지 확정"
        confirm_build.disabled = not _attack_build_ready()
        confirm_build.pressed.connect(_submit_attack_package)
        _apply_action_button_style(confirm_build, "confirm")
        action_box.add_child(confirm_build)

        var cancel_build := Button.new()
        cancel_build.text = "구성 취소"
        cancel_build.pressed.connect(_cancel_attack_build)
        _apply_action_button_style(cancel_build, "secondary")
        action_box.add_child(cancel_build)
        return

    if phase == "COURT_COMPLETION":
        for i in range(court_completion_options.size()):
            var option: Dictionary = court_completion_options[i]
            var complete_button := Button.new()
            complete_button.text = str(option["label"])
            complete_button.pressed.connect(_declare_court_completion.bind(i))
            action_box.add_child(complete_button)
        var skip := Button.new()
        skip.text = "궁정 완성 안 함"
        skip.pressed.connect(_skip_court_completion)
        action_box.add_child(skip)
        return

    if phase == "MOON_PICK":
        for i in range(discard.size()):
            var recover := Button.new()
            recover.text = "회수: %s" % _card_name(discard[i])
            recover.pressed.connect(_resolve_moon_pick.bind(i))
            action_box.add_child(recover)
        return

    if phase == "SUN_EXTRA":
        var skip_sun := Button.new()
        skip_sun.text = "썬 추가 사용 안 함"
        skip_sun.pressed.connect(_skip_sun_extra)
        action_box.add_child(skip_sun)
        return

    if phase == "REVEAL_CONFIRM":
        var confirm_reveal := Button.new()
        confirm_reveal.text = "확인 완료"
        confirm_reveal.pressed.connect(_confirm_revealed_hand)
        _apply_action_button_style(confirm_reveal, "confirm")
        action_box.add_child(confirm_reveal)
        return

    if phase == "DEFENSE":
        for i in range(attack_package.size()):
            if defense_draft.has(i):
                var clear_button := Button.new()
                clear_button.text = "%d번 일반방어 취소" % (i + 1)
                clear_button.pressed.connect(_clear_target_defense.bind(i))
                action_box.add_child(clear_button)

        if not defense_atu_choices.is_empty():
            var clear_atu := Button.new()
            clear_atu.text = "아투 방어 전부 취소"
            clear_atu.pressed.connect(_clear_defense_atu)
            action_box.add_child(clear_atu)
        var confirm := Button.new()
        confirm.text = "방어 패키지 확정"
        confirm.pressed.connect(_confirm_defense_package)
        _apply_action_button_style(confirm, "confirm")
        action_box.add_child(confirm)
        return

    if phase == "ADJUSTMENT_RESPONSE":
        for i in range(defense_atu_used.size()):
            var used: Dictionary = defense_atu_used[i]
            if str(used.get("effect_id", "")) in NULLIFY_ATU_EFFECTS and not bool(used.get("cancelled", false)):
                var cancel_button := Button.new()
                cancel_button.text = "어저스트먼트 → %s 취소" % _card_name(used["card"])
                cancel_button.pressed.connect(_use_adjustment_response.bind(i))
                action_box.add_child(cancel_button)
        var skip_adjust := Button.new()
        skip_adjust.text = "어저스트먼트 사용 안 함"
        skip_adjust.pressed.connect(_skip_adjustment_response)
        action_box.add_child(skip_adjust)
        return

    if phase == "RECYCLE_DECISION":
        var no_button := Button.new()
        no_button.text = "P%d: 에온 재투입 안 함" % (recycle_voter + 1)
        no_button.pressed.connect(_submit_recycle_vote.bind(recycle_voter, false))
        action_box.add_child(no_button)
        var yes_button := Button.new()
        yes_button.text = "P%d: 에온 재투입" % (recycle_voter + 1)
        yes_button.pressed.connect(_submit_recycle_vote.bind(recycle_voter, true))
        action_box.add_child(yes_button)
        return

func _schedule_bot_action_if_needed() -> void:
    if not bot_enabled or game_over or bot_action_pending:
        return

    var bot_should_act: bool = false
    match phase:
        "INITIATIVE_CHOICE":
            bot_should_act = false
        "ACTION", "ATTACK_BUILD", "COURT_COMPLETION", "HANGED_PICK", "MOON_PICK", "STAR_PICK_SELF", "STAR_PICK_OPP", "SUN_EXTRA", "ADJUSTMENT_RESPONSE", "REVEAL_CONFIRM":
            bot_should_act = current_player == bot_player
        "DEFENSE":
            bot_should_act = (1 - current_player) == bot_player
        "RECYCLE_DECISION":
            bot_should_act = recycle_voter == bot_player
        _:
            bot_should_act = false

    if bot_should_act:
        bot_action_pending = true
        call_deferred("_run_bot_action_delayed")


func _run_bot_action_delayed() -> void:
    await get_tree().create_timer(0.65).timeout
    bot_action_pending = false
    if not bot_enabled or game_over:
        return
    _bot_take_action()


func _bot_take_action() -> void:
    if game_over:
        return

    match phase:
        "ACTION":
            if current_player == bot_player:
                _bot_choose_action()
        "ATTACK_BUILD":
            if current_player == bot_player:
                _bot_finish_attack_build()
        "COURT_COMPLETION":
            if current_player == bot_player:
                if not court_completion_options.is_empty():
                    _log("P2 BOT: 궁정 완성을 선언한다.")
                    _declare_court_completion(0)
                else:
                    _skip_court_completion()
        "HANGED_PICK":
            if current_player == bot_player:
                _bot_hanged_pick()
        "MOON_PICK":
            if current_player == bot_player:
                _bot_moon_pick()
        "STAR_PICK_SELF":
            if current_player == bot_player:
                _bot_star_pick_self()
        "STAR_PICK_OPP":
            if current_player == bot_player:
                _bot_star_pick_opponent()
        "SUN_EXTRA":
            if current_player == bot_player:
                _bot_sun_extra()
        "DEFENSE":
            if (1 - current_player) == bot_player:
                _bot_build_defense()
        "ADJUSTMENT_RESPONSE":
            if current_player == bot_player:
                _bot_adjustment_response()
        "RECYCLE_DECISION":
            if recycle_voter == bot_player:
                _log("P2 BOT: 에온 재투입을 선택한다.")
                _submit_recycle_vote(bot_player, true)


func _bot_choose_action() -> void:
    var best_index: int = -1
    var best_score: int = -9999
    for i in range(hands[bot_player].size()):
        var card = hands[bot_player][i]
        if not _bot_can_start_safely(card):
            continue
        var score: int = _bot_card_score(card)
        if score > best_score:
            best_score = score
            best_index = i

    # 공격 카드가 없거나 손패가 매우 적고 의미 없는 카드뿐이면 정상 드로우한다.
    if best_index < 0:
        _log("P2 BOT: 공격 가능한 간단한 카드가 없어 1장 드로우한다.")
        _draw_and_end_turn()
        return

    var chosen = hands[bot_player][best_index]
    _log("P2 BOT: %s을 선택했다." % _card_name(chosen))
    _start_attack_draft(str(chosen.get("id", "")), false)


func _bot_can_start_safely(card) -> bool:
    if not _can_start_attack_with(bot_player, card):
        return false
    var card_type: String = str(card.get("type", ""))
    if card_type != "ATU":
        return true
    # 규칙 검증용 1차 봇은 복잡한 조건/필수 추가 제출 아투를 피한다.
    var effect_id: String = str(card.get("effect_id", ""))
    return effect_id in ["ADJUSTMENT", "HERMIT", "FORTUNE", "HANGED_MAN", "DEATH", "MOON", "STAR", "SUN"]


func _bot_card_score(card) -> int:
    var card_type: String = str(card.get("type", ""))
    if card_type == "SMALL":
        return int(card.get("number", 0)) * 10
    if card_type == "ACE":
        return 72
    if card_type == "COURT":
        return 25 + int(card.get("value", 0)) * 8
    if card_type == "ATU":
        var effect_id: String = str(card.get("effect_id", ""))
        match effect_id:
            "FORTUNE": return 60
            "HANGED_MAN": return 54
            "DEATH": return 48 if hands[bot_player].size() >= 5 else 20
            "MOON": return 46
            "SUN": return 44
            "STAR": return 40
            "HERMIT": return 36
            "ADJUSTMENT": return 30
            _: return 10
    return 0


func _bot_finish_attack_build() -> void:
    # 조건 선택이 필요한 복잡한 아투는 기본적으로 선택하지 않지만,
    # 혹시 상태가 남았다면 안전하게 구성을 취소하고 드로우로 전환한다.
    if _unresolved_condition_source_id() != "":
        _log("P2 BOT: 복잡한 조건 카드 구성을 포기한다.")
        _cancel_attack_build()
        return

    if _attack_build_ready():
        _submit_attack_package()
        return

    # 필수 추가 제출이 남은 경우 합법 카드 하나를 자동 선택한다.
    var best_index: int = -1
    var best_score: int = -9999
    for i in range(hands[bot_player].size()):
        var card = hands[bot_player][i]
        if not _attack_build_card_is_clickable(card):
            continue
        var score: int = _bot_card_score(card)
        if score > best_score:
            best_score = score
            best_index = i
    if best_index >= 0:
        _handle_attack_build_card_click(best_index)
    else:
        _log("P2 BOT: 공격 패키지를 완성할 수 없어 구성을 취소한다.")
        _cancel_attack_build()


func _bot_hanged_pick() -> void:
    if hands[bot_player].is_empty():
        _process_next_post_effect()
        return
    var worst_index: int = 0
    var worst_score: int = 999999
    for i in range(hands[bot_player].size()):
        var score: int = _bot_card_score(hands[bot_player][i])
        if score < worst_score:
            worst_score = score
            worst_index = i
    _resolve_hanged_pick(worst_index)


func _bot_moon_pick() -> void:
    if discard.is_empty():
        _process_next_post_effect()
        return
    var best_index: int = 0
    var best_score: int = -9999
    for i in range(discard.size()):
        var score: int = _bot_card_score(discard[i])
        if score > best_score:
            best_score = score
            best_index = i
    _resolve_moon_pick(best_index)


func _bot_star_pick_self() -> void:
    if hands[bot_player].is_empty():
        _process_next_post_effect()
        return
    var worst_index: int = 0
    var worst_score: int = 999999
    for i in range(hands[bot_player].size()):
        var score: int = _bot_card_score(hands[bot_player][i])
        if score < worst_score:
            worst_score = score
            worst_index = i
    star_self_id = str(hands[bot_player][worst_index].get("id", ""))
    phase = "STAR_PICK_OPP"
    status_label.text = "P2 BOT: 스타로 가져올 P1 카드를 선택 중이다."
    _refresh_ui()


func _bot_star_pick_opponent() -> void:
    var opponent: int = 1 - bot_player
    if hands[opponent].is_empty():
        _process_next_post_effect()
        return
    var best_index: int = 0
    var best_score: int = -9999
    for i in range(hands[opponent].size()):
        var score: int = _bot_card_score(hands[opponent][i])
        if score > best_score:
            best_score = score
            best_index = i
    _resolve_star_exchange(best_index)


func _bot_sun_extra() -> void:
    var best_id: String = ""
    var best_score: int = -9999
    for card in hands[bot_player]:
        if not _can_be_added_as_attack_card(bot_player, card):
            continue
        if str(card.get("type", "")) == "ATU" and not _bot_can_start_safely(card):
            continue
        var score: int = _bot_card_score(card)
        if score > best_score:
            best_score = score
            best_id = str(card.get("id", ""))
    if best_id == "":
        _skip_sun_extra()
    else:
        _log("P2 BOT: 썬의 추가 사용권을 사용한다.")
        _start_attack_draft(best_id, true)


func _bot_build_defense() -> void:
    var defender: int = bot_player
    if bool(defense_blocked[defender]):
        _confirm_defense_package()
        return

    defense_draft.clear()
    defense_atu_choices.clear()
    var used_ids: Dictionary = {}

    for attack_index in range(attack_package.size()):
        var entry: Dictionary = attack_package[attack_index]
        var raw_draw: int = _calculate_entry_draw(entry, null)
        if raw_draw <= 0:
            continue

        var best_card_id: String = ""
        var best_reduction: int = 0
        var best_after: int = raw_draw
        var best_match_penalty: int = 999
        for card in hands[defender]:
            var card_id: String = str(card.get("id", ""))
            if used_ids.has(card_id) or _is_card_locked_for_player(defender, card_id):
                continue
            if not _can_defend(entry.get("card", null), card):
                continue
            var after: int = _calculate_entry_draw(entry, card)
            var reduction: int = raw_draw - after
            if reduction <= 0:
                continue
            var match_penalty: int = 1 if _bot_is_matching_pentacle_defense(entry.get("card", null), card) else 0
            if reduction > best_reduction or (reduction == best_reduction and match_penalty < best_match_penalty) or (reduction == best_reduction and match_penalty == best_match_penalty and after < best_after):
                best_reduction = reduction
                best_after = after
                best_match_penalty = match_penalty
                best_card_id = card_id

        if best_card_id != "":
            defense_draft[attack_index] = best_card_id
            used_ids[best_card_id] = true

    _log("P2 BOT: 가능한 일반 방어를 자동 배정했다.")
    _confirm_defense_package()


func _bot_is_matching_pentacle_defense(attacker, defender) -> bool:
    if attacker == null or defender == null:
        return false
    var attack_type: String = str(attacker.get("type", ""))
    var defense_type: String = str(defender.get("type", ""))
    if attack_type == "SMALL" and defense_type == "SMALL":
        return int(attacker.get("number", -1)) == int(defender.get("number", -2))
    if attack_type == "ACE" and defense_type == "ACE":
        return true
    if attack_type == "COURT" and defense_type == "COURT":
        return str(attacker.get("court_rank", "")) == str(defender.get("court_rank", ""))
    return false


func _bot_adjustment_response() -> void:
    for i in range(defense_atu_used.size()):
        var used: Dictionary = defense_atu_used[i]
        if str(used.get("effect_id", "")) in NULLIFY_ATU_EFFECTS and not bool(used.get("cancelled", false)):
            _log("P2 BOT: 어저스트먼트로 무효 아투를 취소한다.")
            _use_adjustment_response(i)
            return
    _skip_adjustment_response()


func _attack_build_card_is_clickable(card) -> bool:
    var card_id: String = str(card["id"])
    if card_id == attack_base_id or card_id in attack_draft_ids:
        return false

    var source_id: String = _unresolved_condition_source_id()
    if source_id != "":
        var source: Variant = _find_card_anywhere_for_draft(source_id)
        if source == null:
            return false
        var effect_id: String = str(source.get("effect_id", ""))
        var family: String = str(condition_family.get(source_id, ""))
        if effect_id in ["DEVIL", "UNIVERSE"] and family == "":
            return false
        if card_id in condition_ids.get(source_id, []):
            return true
        if _is_card_locked_for_player(current_player, card_id):
            return false
        if not _card_matches_condition_family(card, family):
            return false
        if effect_id in ["DEVIL", "UNIVERSE"]:
            if card_id in attack_draft_ids or card_id == attack_art_id:
                return false
            if _condition_card_reserved_elsewhere(source_id, card_id):
                return false
        return true

    if str(card.get("effect_id", "")) == "ART":
        return not _available_small_attack_ids().is_empty()
    if card_id == attack_art_id or _card_reserved_by_condition(card_id):
        return false
    return _find_compatible_attack_token(card) >= 0 and _can_be_added_as_attack_card(current_player, card)


func _card_is_selected_condition(card_id: String) -> bool:
    for ids in condition_ids.values():
        if card_id in ids:
            return true
    return false


func _draft_contains_card_id(card_id: String) -> bool:
    for value in defense_draft.values():
        if str(value) == card_id:
            return true
    return false


func _defense_atu_contains_card(card_id: String) -> bool:
    for choice in defense_atu_choices:
        if str(choice["card_id"]) == card_id:
            return true
    return false


func _attack_package_text() -> String:
    var parts: Array = []
    for i in range(attack_package.size()):
        var entry: Dictionary = attack_package[i]
        var text: String = "%d. %s" % [i + 1, _card_name(entry["card"])]
        if phase == "DEFENSE" and i == selected_defense_target:
            text = "▶ " + text
        if i == art_target_index:
            text += " [아트: 방어 후 잔여×2]"
        if bool(entry.get("cannot_be_nullified", false)):
            text += " [무효불가]"
        if entry["defense"] != null:
            text += " / 방어: " + _card_name(entry["defense"])
        elif phase == "DEFENSE" and defense_draft.has(i):
            var draft_card = _find_card_in_hand_by_id(1 - current_player, str(defense_draft[i]))
            if draft_card != null:
                text += " / 방어 예정: " + _card_name(draft_card)
        if bool(entry.get("nullified", false)):
            text += " / 무효"
        parts.append(text)

    if phase == "ATTACK_BUILD" and not attack_draft_ids.is_empty():
        var draft_names: Array = []
        for card_id in attack_draft_ids:
            var card: Variant = _find_card_in_hand_by_id(current_player, str(card_id))
            if card != null:
                draft_names.append(_card_name(card))
        if attack_art_id != "":
            var art: Variant = _find_card_in_hand_by_id(current_player, attack_art_id)
            if art != null:
                draft_names.append(_card_name(art))
        var prefix: String = "추가 구성 중" if attack_append_mode else "공격 구성 중"
        var base_text: String = prefix + " — " + _join_strings(draft_names, " + ")
        if not parts.is_empty():
            return "사용 영역 — " + _join_strings(parts, "   |   ") + "\n" + base_text
        return base_text

    if parts.is_empty():
        return ""

    var text_result: String = "사용 영역 — " + _join_strings(parts, "   |   ")
    if phase == "DEFENSE" and not defense_atu_choices.is_empty():
        var atu_names: Array = []
        for choice in defense_atu_choices:
            var card = _find_card_in_hand_by_id(1 - current_player, str(choice["card_id"]))
            if card != null:
                atu_names.append(_card_name(card))
        if not atu_names.is_empty():
            text_result += "\n방어 아투 예정 — " + _join_strings(atu_names, ", ")
    return text_result

func _phase_instruction() -> String:
    match phase:
        "INITIATIVE_READY":
            return "진행: 양쪽 손패는 0장이다. 덱을 눌러 선공 판정용 카드 1장씩을 공개 드로우한다."
        "INITIATIVE_DRAW":
            return "진행: 선공 판정 카드가 덱에서 각 플레이어 앞으로 이동해 공개되는 중이다."
        "INITIATIVE_CHOICE":
            return "진행: 중앙에 공개된 판정 카드의 위계를 비교한다. 높은 카드를 낸 플레이어가 선공 또는 후공을 선택한다."
        "OPENING_DEAL":
            return "진행: 판정 카드를 포함해 각 플레이어의 시작 손패가 5장이 되도록 4장씩 추가 배분한다."
        "ACTION":
            if bot_enabled and current_player == bot_player:
                return "진행: P2 BOT가 행동을 선택 중이다."
            return "진행: 공격 카드를 전장으로 드래그해 사용한다. 탭 선택도 가능하다. 공격하지 않으려면 덱을 눌러 1장 드로우하고 턴을 종료한다."
        "ATTACK_BUILD":
            return "진행: 추가 카드를 전장으로 드래그해 공격 패키지를 구성한다. 필수 추가 카드와 조건을 모두 채운 뒤 확정한다."
        "COURT_COMPLETION":
            return "진행: 가능한 궁정 완성을 선언하거나 생략한다."
        "HANGED_PICK":
            return "진행: 행맨 효과로 묘지에 보낼 자신의 손패 1장을 선택한다."
        "MOON_PICK":
            return "진행: 문 효과로 묘지에서 손패로 되돌릴 카드 1장을 선택한다."
        "STAR_PICK_SELF":
            return "진행: 스타로 교환할 자신의 카드 1장을 선택한다."
        "STAR_PICK_OPP":
            return "진행: 스타로 가져올 상대의 카드 1장을 선택한다."
        "SUN_EXTRA":
            return "진행: 썬 효과로 추가 공격 카드 1장을 내거나 생략한다. 양쪽 손패 공개는 사용자의 다음 턴 종료까지 유지된다."
        "REVEAL_CONFIRM":
            return "진행: 공개된 상대 손패를 확인하고 확인 완료를 눌러 다음 단계로 진행한다."
        "DEFENSE":
            return "진행: 방어카드를 막을 공격 카드 위로 드래그한다. 탭으로 대상을 고른 뒤 방어카드를 누르는 방식도 가능하다."
        "DEFENSE_REVEAL":
            return "진행: 제출된 방어 카드와 공격 카드의 대응 관계를 확인한다. 확인 후 정산을 진행한다."
        "ADJUSTMENT_RESPONSE":
            return "진행: 공격자는 어저스트먼트로 방어자의 무효 아투 1장을 취소하거나 반응을 생략한다."
        "DRAW_RESOLUTION":
            return "진행: 드로우와 리사이클을 정산 중이다. 카드 이동 연출이 끝나면 결과 확인 단계로 넘어간다."
        "RESOLUTION_REVIEW":
            return "진행: 각 공격의 최종 드로우 수와 방어 결과를 확인한다. 확인 후 턴을 종료한다."
        "RECYCLE_DECISION":
            return "진행: 각 플레이어가 에온을 새 덱에 재투입할지 선택한다."
        "AEON_TRANSITION":
            return "진행: 에온 전환 연출이 진행 중이다."
        "GAME_OVER":
            return "게임이 종료되었다."
        _:
            return "현재 효과를 해결한다."


func _phase_name() -> String:
    match phase:
        "SETUP": return "게임 준비"
        "INITIATIVE_READY": return "선공 판정 준비"
        "INITIATIVE_DRAW": return "선공 판정 드로우"
        "INITIATIVE_CHOICE": return "선공 판정 / 선후공 선택"
        "OPENING_DEAL": return "시작 손패 배분"
        "ACTION": return "행동 선택"
        "ATTACK_BUILD": return "공격 패키지 구성"
        "COURT_COMPLETION": return "궁정 완성"
        "HANGED_PICK": return "행맨 선택"
        "MOON_PICK": return "문 회수"
        "STAR_PICK_SELF", "STAR_PICK_OPP": return "스타 교환"
        "SUN_EXTRA": return "썬 추가 사용"
        "REVEAL_CONFIRM": return "공개 확인"
        "DEFENSE": return "방어 패키지 구성"
        "DEFENSE_REVEAL": return "방어 패키지 공개"
        "ADJUSTMENT_RESPONSE": return "어저스트먼트 반응"
        "DRAW_RESOLUTION": return "드로우 정산"
        "RESOLUTION_REVIEW": return "정산 결과 확인"
        "RECYCLE_DECISION": return "에온 재투입 합의"
        "AEON_TRANSITION": return "에온 전환"
        "GAME_OVER": return "게임 종료"
        _: return phase

func _hand_text(player: int) -> String:
    var names: Array = []
    for card in hands[player]:
        names.append(_card_name(card))
    return _join_strings(names, ", ")


func _join_strings(items: Array, separator: String) -> String:
    var result: String = ""
    for i in range(items.size()):
        if i > 0:
            result += separator
        result += str(items[i])
    return result


func _finalize_pentacles(winner: int) -> void:
    if pentacle_finalized:
        return
    pentacle_finalized = true
    var loser: int = 1 - winner
    var moved_disks: int = 0
    for i in range(hands[loser].size() - 1, -1, -1):
        var card = hands[loser][i]
        if str(card.get("suit", "")) == "Disks":
            var loser_disk = hands[loser].pop_at(i)
            _animate_card_transfer(hand_panels[loser], discard_pile_button, loser_disk, moved_disks, true, "종료 정산")
            discard.append(loser_disk)
            moved_disks += 1

    var grave_disks: int = 0
    for card in discard:
        if str(card.get("suit", "")) == "Disks":
            grave_disks += 1

    if moved_disks > 0:
        _log("종료 정산: 패자 P%d의 디스크 %d장을 묘지로 이동했다." % [loser + 1, moved_disks])
    _contribute_pentacles(loser, grave_disks, "패자 디스크 정산 — 묘지 디스크 %d장" % grave_disks)
    last_pentacle_award = shared_pentacles
    player_pentacles[winner] = int(player_pentacles[winner]) + last_pentacle_award
    shared_pentacles = 0
    pentacle_contributions = [0, 0]
    _log("P%d가 공동 더미의 펜타클 %d개를 획득했다. (보유 %d)" % [winner + 1, last_pentacle_award, int(player_pentacles[winner])])


func _end_game(winner: int, reason: String) -> void:
    if game_over:
        return
    _finalize_pentacles(winner)
    game_over = true
    phase = "GAME_OVER"
    status_label.text = "%s  →  P%d 승리  |  획득 펜타클 %d  |  보유 %d" % [reason, winner + 1, last_pentacle_award, int(player_pentacles[winner])]
    _log(reason)
    _log("P%d 승리." % (winner + 1))
    _refresh_ui()


func _clear_children(node: Node) -> void:
    for child in node.get_children():
        child.queue_free()


func _log(message: String) -> void:
    log_box.append_text(message + "\n")
