class_name CardDatabase
extends RefCounted

const SUITS := ["Wands", "Cups", "Swords", "Disks"]
const COURT_RANKS := [
    {"name": "Princess", "value": 1},
    {"name": "Prince", "value": 2},
    {"name": "Queen", "value": 3},
    {"name": "Knight", "value": 4}
]

const ATU := [
    {"number": 0, "name": "The Fool", "effect_id": "FOOL"},
    {"number": 1, "name": "The Magus", "effect_id": "MAGUS"},
    {"number": 2, "name": "The Priestess", "effect_id": "PRIESTESS"},
    {"number": 3, "name": "The Empress", "effect_id": "EMPRESS"},
    {"number": 4, "name": "The Emperor", "effect_id": "EMPEROR"},
    {"number": 5, "name": "The Hierophant", "effect_id": "HIEROPHANT"},
    {"number": 6, "name": "The Lovers", "effect_id": "LOVERS"},
    {"number": 7, "name": "The Chariot", "effect_id": "CHARIOT"},
    {"number": 8, "name": "Adjustment", "effect_id": "ADJUSTMENT"},
    {"number": 9, "name": "The Hermit", "effect_id": "HERMIT"},
    {"number": 10, "name": "Fortune", "effect_id": "FORTUNE"},
    {"number": 11, "name": "Lust", "effect_id": "LUST"},
    {"number": 12, "name": "The Hanged Man", "effect_id": "HANGED_MAN"},
    {"number": 13, "name": "Death", "effect_id": "DEATH"},
    {"number": 14, "name": "Art", "effect_id": "ART"},
    {"number": 15, "name": "The Devil", "effect_id": "DEVIL"},
    {"number": 16, "name": "The Tower", "effect_id": "TOWER"},
    {"number": 17, "name": "The Star", "effect_id": "STAR"},
    {"number": 18, "name": "The Moon", "effect_id": "MOON"},
    {"number": 19, "name": "The Sun", "effect_id": "SUN"},
    {"number": 20, "name": "The Aeon", "effect_id": "AEON"},
    {"number": 21, "name": "The Universe", "effect_id": "UNIVERSE"}
]

const ATU_DESCRIPTIONS := {
    "FOOL": "반응 전용. 이번 턴의 무효 가능한 공격효과 전체를 무효화한다. 에이스/나이트 계열 조건에도 사용할 수 있다.",
    "MAGUS": "공격 시 마법계 공격 카드 2장을 반드시 추가로 낸다.",
    "PRIESTESS": "반응 전용. 이번 공격 패키지의 무효 가능한 마법계 공격을 전부 무효화한다.",
    "EMPRESS": "공격 모드: 마법계 공격 카드 1장을 추가로 낸다. 방어 모드: 마법계 공격 카드 1장을 무효화한다.",
    "EMPEROR": "공격 모드: 물리계 공격 카드 1장을 추가로 낸다. 방어 모드: 물리계 공격 카드 1장을 무효화한다.",
    "HIEROPHANT": "에이스 계열 또는 나이트 계열 카드 1장을 공개해 사용한다. 상대에게 5장 드로우를 발생시킨다.",
    "LOVERS": "반응 전용. 유니버스 이외의 최종 드로우 총량을 절반으로 줄이고 소수점은 올림한다.",
    "CHARIOT": "반응 전용. 이번 공격 패키지의 무효 가능한 스몰카드와 코트카드 공격을 전부 무효화한다. 에이스에는 적용되지 않는다.",
    "ADJUSTMENT": "공격 모드: 상대 손패 전체를 공개하고, 사용자가 확인 완료를 누를 때까지 다음 단계로 넘어가지 않는다. 반응 모드: 방어자가 사용한 무효 아투 1장의 효과를 무효화한다.",
    "HERMIT": "사용 후 다음 상대 턴에는 일반 방어와 아투 방어를 모두 사용할 수 없다. 다음 자신의 턴은 스킵한다. 그 뒤 다시 자기 턴이 오면 완전한 턴 3회를 상대 턴 없이 연속 수행한다.",
    "FORTUNE": "현재 턴에 유효 공격 카드 1장을 추가로 낼 수 있다. 현재 턴이 끝난 뒤 상대 턴 없이 자신의 새 턴을 1회 더 수행한다.",
    "LUST": "반응 전용. 이번 공격 패키지의 무효 가능한 물리계 공격을 전부 무효화한다.",
    "HANGED_MAN": "사용 후 자신의 남은 손패에서 카드 1장을 골라 묘지로 보낸다. 이 효과로 손패가 0장이 되면 즉시 승리한다.",
    "DEATH": "제출 뒤 남은 손패를 전부 버리고 같은 장수만큼 다시 드로우한다. 데스 자체 제출로 0장이 되면 즉시 승리하며, 효과 처리 중의 일시적 0장은 승리가 아니다.",
    "ART": "공격 패키지의 스몰카드 1장에 겹쳐 사용한다. 상대의 방어 정산이 끝난 뒤 그 스몰카드에 남은 드로우 수만 2배로 한다.",
    "DEVIL": "에이스 계열 2장 또는 나이트 계열 2장을 공개한다. 공개 카드는 다음 자신의 턴까지 사용할 수 없다. 상대에게 7장 드로우를 발생시키며 무효화되지 않는다.",
    "TOWER": "공격 시 물리계 공격 카드 2장을 반드시 추가로 낸다.",
    "STAR": "양 플레이어의 손패를 공개하고, 자신의 카드 1장과 상대 카드 1장을 선택해 교환한다.",
    "MOON": "묘지에 카드가 1장 이상 있을 때만 사용할 수 있다. 묘지에서 원하는 카드 1장을 손패로 회수한다. 상대의 손패 공개 효과로 문이 공개되면 공개한 플레이어의 손패로 이동하고 그 플레이어는 6장 드로우한다.",
    "SUN": "양 플레이어의 손패를 공개한 뒤 유효 공격 카드 1장을 추가로 낼 수 있다. 공개 상태는 사용자의 다음 턴 종료까지 유지된다.",
    "AEON": "마법계 공격 카드 1장과 물리계 공격 카드 1장을 반드시 추가로 낸다. 덱 리사이클에서는 별도의 종국 규칙을 가진다.",
    "UNIVERSE": "에이스 계열 3장 또는 나이트 계열 3장을 비용으로 묘지에 보내 사용한다. 상대에게 12장 드로우를 발생시키며 무효화되지 않고 러버즈로 감소하지 않는다."
}

# v0.3 호환용 핵심 아투 목록.
const V03_ATU_EFFECTS := [
    "FOOL", "MAGUS", "PRIESTESS", "EMPRESS", "EMPEROR",
    "HIEROPHANT", "LOVERS", "CHARIOT", "ADJUSTMENT",
    "FORTUNE", "LUST", "TOWER", "AEON"
]


static func make_small_deck() -> Array:
    var cards: Array = []
    for suit in SUITS:
        for number in range(2, 11):
            cards.append({
                "id": "SMALL_%s_%d" % [str(suit).to_upper(), number],
                "type": "SMALL",
                "suit": suit,
                "number": number,
                "value": number,
                "effect_id": ""
            })
    return cards


static func make_v02_deck() -> Array:
    var cards: Array = make_small_deck()

    for suit in SUITS:
        cards.append({
            "id": "ACE_%s" % str(suit).to_upper(),
            "type": "ACE",
            "suit": suit,
            "number": 1,
            "value": 1,
            "hit_draw": 7,
            "effect_id": "ACE"
        })

    for suit in SUITS:
        for rank in COURT_RANKS:
            cards.append({
                "id": "COURT_%s_%s" % [str(suit).to_upper(), str(rank["name"]).to_upper()],
                "type": "COURT",
                "suit": suit,
                "court_rank": rank["name"],
                "value": rank["value"],
                "effect_id": "COURT"
            })

    return cards


static func make_v03_deck() -> Array:
    var cards: Array = make_v02_deck()
    for atu in ATU:
        var effect_id: String = str(atu["effect_id"])
        if effect_id in V03_ATU_EFFECTS:
            cards.append({
                "id": "ATU_%02d" % int(atu["number"]),
                "type": "ATU",
                "suit": "None",
                "atu_number": atu["number"],
                "name": atu["name"],
                "value": 0,
                "effect_id": effect_id
            })
    return cards


static func make_v04_deck() -> Array:
    return make_full_deck()


static func make_full_deck() -> Array:
    var cards: Array = make_v02_deck()

    for atu in ATU:
        cards.append({
            "id": "ATU_%02d" % int(atu["number"]),
            "type": "ATU",
            "suit": "None",
            "atu_number": atu["number"],
            "name": atu["name"],
            "value": 0,
            "effect_id": atu["effect_id"]
        })

    return cards


static func physical_or_magical(card) -> String:
    if card == null:
        return "NONE"
    var suit: String = str(card.get("suit", "None"))
    if suit == "Swords" or suit == "Disks":
        return "PHYSICAL"
    if suit == "Wands" or suit == "Cups":
        return "MAGICAL"
    return "NONE"


static func atu_description(effect_id: String) -> String:
    return str(ATU_DESCRIPTIONS.get(effect_id, "설명 없음"))
